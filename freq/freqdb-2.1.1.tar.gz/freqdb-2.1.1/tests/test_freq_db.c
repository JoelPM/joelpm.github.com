#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <time.h>

#define NODEBUG

/* wrap malloc and other functions to cause test memory problems */
static size_t malloc_null_at = 0;
static size_t malloc_count = 0;

static void *
my_malloc( size_t size )
  {
    void *ret = NULL;
    malloc_count++;
    if ( malloc_count != malloc_null_at )
      {
        ret = malloc (size);
      }
    return ret;
  }

static size_t mmap_fail_at = 0;
static size_t mmap_count = 0;

static void *
my_mmap( void *addr,
         size_t len,
         int prot,
         int flags,
         int fd,
         off_t offset )
  {
    void * ret = MAP_FAILED;
    mmap_count++;
    if ( mmap_count != mmap_fail_at )
      {
        ret = mmap( addr, len, prot, flags, fd, offset );
      }
    return ret; 
  }

#define mmap my_mmap
#define malloc my_malloc

#include "../src/freq_db.c"

#undef mallac
#undef mmap

static void
test_type_key_cmp(void)
  {
    freq_type_t type1, type2;
    memset( &type1, 0, sizeof( freq_type_t ) );
    memset( &type2, 0, sizeof( freq_type_t ) );

    type1.interval_cnt = 29520;
    type1.interval_mins = 5;
    type1.interval_bits = 3;

    type2.interval_cnt = 1;
    type2.interval_mins = 90 * 24 * 60;
    type2.interval_bits = 32;

    const char *key1 = "thisisatestkey";
    const char *key2 = "thisisanothertestkey";

    int key_sz1 = strlen( key1 );
    int key_sz2 = strlen( key2 );

    // Compare different types and keys and key lengths
    int cmp_res = type_key_cmp( &type1, key1, key_sz1,
                                &type2, key2, key_sz2 );
    assert( cmp_res != 0 );

    // Compare same types and different keys and different key lengths
    cmp_res = type_key_cmp( &type1, key1, key_sz1,
                            &type1, key2, key_sz2 );
    assert( cmp_res != 0 );

    // Compare same types, same lengths, and different keys
    cmp_res = type_key_cmp( &type1, key1, key_sz1,
                            &type1, key2, key_sz1 );
    assert( cmp_res != 0 );

    // Compare same types, same lengths, and same keys
    cmp_res = type_key_cmp( &type1, key1, 7,
                            &type1, key2, 7 );
    assert( cmp_res == 0 );

    // Compare different types, same keys, and same key lenths
    cmp_res = type_key_cmp( &type1, key1, key_sz1,
                            &type2, key1, key_sz1 );
    assert( cmp_res != 0 );
  }


static void
test_idx_init(void)
  {
    freq_file_header_t file_header;
    file_header.live_cnt = 128;

    freq_db_t db;
    db.file_hdr = &file_header;

    malloc_count = 0;
    malloc_null_at = 1;

    int res = idx_init( &db );
    assert( res == FREQ_DB_SYS_ERR_MALLOC );

    res = idx_init( &db );
    assert( res == FREQ_DB_SUCCESS );
    assert( db.idx_sz == 1048576 );
    assert( db.idx_mask == 1048575 );
    free( db.idx );

    file_header.live_cnt = 1048576;
    res = idx_init( &db );
    assert( res == FREQ_DB_SUCCESS );
    assert( db.idx_sz == 2097152 );
    assert( db.idx_mask == 2097151 );
    free ( db.idx );

    /*
    file_header.live_cnt = UINT64_MAX/2;
    res = idx_init( &db );
    assert( res == FREQ_DB_SUCCESS );
    printf( "%ld\n", db.idx_sz );
    assert( db.idx_sz == UINT64_MAX/2 );
    assert( db.idx_mask == UINT64_MAX - 1  );
    */

    malloc_count = 0;
    malloc_null_at = 0;
  }


static void
test_freq_db_idx_expand(void)
  {
    char test_dir[] = "/tmp/test_freq_db_idx_expand_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;
    int result;

    // Test new file
    uint64_t prior_initial_index_capacity = INITIAL_INDEX_CAPACITY;
    INITIAL_INDEX_CAPACITY = 4096;
    fprintf( stderr, "test open new db - opening %s ", filename );
    result = freq_db_open( &db, filename, 536870912 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    uint64_t idx_sz = INITIAL_INDEX_CAPACITY;
    uint64_t idx_resize_trigger = (0.6 * (float)idx_sz) + 1;

    assert( db->idx_sz == idx_sz );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 2;
    type.interval_mins = 60;
    type.interval_bits = 8;

    char key[64];
    int key_sz;

    // Write some keys
    uint64_t i = 0;
    while ( i <= idx_resize_trigger )
      {
        assert( db->idx_sz == idx_sz );

        key_sz = snprintf( key, 64, "k%"PRIu64"_%d_%d", i++, rand(), rand() );
        //fprintf( stderr, "adding key %s ", key );
        result = freq_db_increment( db, &type, key, key_sz, 0 );
        //fprintf( stderr, "done: %d\n", result );
        if ( FREQ_DB_ERR_IDX_COLLISIONS == result )
          i--;
        else
          assert( FREQ_DB_CREATED == result );
      }

    float load_factor = db->file_hdr->live_cnt / (float)db->idx_sz;

    fprintf( stderr, "load factor: %f, index size: %ld", load_factor, db->idx_sz );

    idx_sz = idx_sz << 1;
    idx_resize_trigger = (0.6 * (float)idx_sz) + 1;
    assert( db->idx_sz == idx_sz );
 
    while ( i <= idx_resize_trigger )
      {
        assert( db->idx_sz == idx_sz );

        key_sz = snprintf( key, 64, "k%"PRIu64"_%d_%d", i++, rand(), rand() );
        //fprintf( stderr, "adding key %s ", key );
        result = freq_db_increment( db, &type, key, key_sz, 0 );
        //fprintf( stderr, "done: %d\n", result );
        if ( FREQ_DB_ERR_IDX_COLLISIONS == result )
          i--;
        else
          assert( FREQ_DB_CREATED == result );
      }

    fprintf( stderr, "index size: %ld", db->idx_sz );
    assert( db->idx_sz == idx_sz << 1 );
 
    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    INITIAL_INDEX_CAPACITY = prior_initial_index_capacity;
  }


static void
test_freq_db_open(void)
  {
    char test_dir[] = "/tmp/test_freq_db_open_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;

    // Test malloc failure
    malloc_count = 0;
    malloc_null_at = 1; 
    fprintf( stderr, "test open malloc err - opening %s ", filename );
    int result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SYS_ERR_MALLOC == result );

    // Test new file
    fprintf( stderr, "test open new db - opening %s ", filename );
    result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    // Test open existing file
    fprintf( stderr, "test open existing db - opening %s", filename );
    result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_file_expand(void)
  {
    char test_dir[] = "/tmp/test_freq_db_file_expand_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;
    int result;

    // Test new file
    fprintf( stderr, "test open new db - opening %s ", filename );
    result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    assert( db->file_sz == 1024*1024 );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 32;
    type.interval_mins = 60;
    type.interval_bits = 31;

    char key[64];
    int key_sz;
    uint64_t bytes_written = sizeof( freq_file_header_t );

    // Write some keys
    int i = 0;
    while ( bytes_written <= 1024*1024 )
      {
        assert( db->file_sz == 1024*1024 );

        key_sz = snprintf( key, 64, "test_key_%d", i++ );
        //fprintf( stderr, "adding key %s ", key );
        result = freq_db_increment( db, &type, key, key_sz, 0 );
        //fprintf( stderr, "done: %d\n", result );
        assert( FREQ_DB_CREATED == result );

        freq_record_t * record = idx_find( db, &type, key, key_sz );
        // Have to call rename mmap to my_mmap due to macro above
        freq_header_t *hdr = freq_record_header( db->my_mmap, record );
        uint64_t freq_sz = freq_get_size( hdr );
        bytes_written += freq_sz;
      }

    assert( db->file_sz == 2*1024*1024 );
 
    while ( bytes_written <= 2*1024*1024 )
      {
        assert( db->file_sz == 2*1024*1024 );

        key_sz = snprintf( key, 64, "test_key_%d", i++ );
        //fprintf( stderr, "adding key %s ", key );
        result = freq_db_increment( db, &type, key, key_sz, 0 );
        //fprintf( stderr, "done: %d\n", result );
        assert( FREQ_DB_CREATED == result );

        freq_record_t * record = idx_find( db, &type, key, key_sz );
        // Have to call rename mmap to my_mmap due to macro above
        freq_header_t *hdr = freq_record_header( db->my_mmap, record );
        uint64_t freq_sz = freq_get_size( hdr );
        bytes_written += freq_sz;
      }

    assert( db->file_sz == 3*1024*1024 );
 
    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_info(void)
  {
    char test_dir[] = "/tmp/test_freq_db_info_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;
    int result;

    // Test new file
    fprintf( stderr, "test db info - opening %s ", filename );
    result = freq_db_open( &db, filename, 524288 ); // 512BK
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    // Get info and check it
    freq_db_info_t db_info;
    fprintf( stderr, "test db info - getting info " ),
    result = freq_db_info( db, &db_info );
    fprintf( stderr, "done: %d\n", result );
    assert( db_info.active_freqs == 0 );
    assert( db_info.deleted_freqs == 0 );
    assert( db_info.increment_sz == 524288 );
    assert( db_info.disk_sz == sizeof( freq_file_header_t ) );
    assert( db_info.index_sz == INITIAL_INDEX_CAPACITY );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 2;
    type.interval_mins = 60;
    type.interval_bits = 8;

    char key[64];
    int key_sz;

    // Write some keys
    int i = 0;
    for ( i = 0; i < 100; i++ )
      {
        key_sz = snprintf( key, 64, "test_key_%d", i );
        //fprintf( stderr, "adding key %s ", key );
        result = freq_db_increment( db, &type, key, key_sz, 0 );
        //fprintf( stderr, "done: %d\n", result );
        assert( FREQ_DB_CREATED == result );
      }

    // Get info and check it
    fprintf( stderr, "test db info - getting info " ),
    result = freq_db_info( db, &db_info );
    fprintf( stderr, "done: %d\n", result );
    assert( db_info.active_freqs == 100 );
    assert( db_info.deleted_freqs == 0 );
    assert( db_info.increment_sz == 524288 );
    fprintf( stderr, "disk_sz = %"PRIu64"\n", db->file_hdr->eod );
    assert( db_info.disk_sz == 6130 );
    assert( db_info.index_sz == INITIAL_INDEX_CAPACITY );

    for ( i = 0; i < 100; i++ )
      {
        if ( i % 2 == 0 ) continue;

        key_sz = snprintf( key, 64, "test_key_%d", i );
        //fprintf( stderr, "adding key %s ", key );
        result = freq_db_delete( db, &type, key, key_sz );
        //fprintf( stderr, "done: %d\n", result );
        assert( FREQ_DB_SUCCESS == result );
      }

    // Get info and check it
    fprintf( stderr, "test db info - getting info " ),
    result = freq_db_info( db, &db_info );
    fprintf( stderr, "done: %d\n", result );
    fprintf( stderr, "active: %"PRIu64" deleted: %"PRIu64"\n", db_info.active_freqs, db_info.deleted_freqs );
    assert( db_info.active_freqs == 50 );
    assert( db_info.deleted_freqs == 50 );
    assert( db_info.increment_sz == 524288 );
    fprintf( stderr, "db_info.disk_sz = %"PRIu64"\n", db_info.disk_sz );
    assert( db_info.disk_sz == 6130 );
    assert( db_info.index_sz == INITIAL_INDEX_CAPACITY );
    
    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_delete(void)
  {
    char test_dir[] = "/tmp/test_freq_db_delete_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;

    // Open new db 
    malloc_null_at = 1; 
    fprintf( stderr, "test delete - opening %s ", filename );
    int result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 32;
    type.interval_mins = 60;
    type.interval_bits = 31;

    char key[64];
    int key_sz;

    // Write some keys
    int i = 0;
    for ( i = 0; i < 100; i++ )
      {
        key_sz = snprintf( key, 64, "test_key_%d", i );
        //fprintf( stderr, "adding key %s ", key );
        result = freq_db_increment( db, &type, key, key_sz, 0 );
        //fprintf( stderr, "done: %d\n", result );
        assert( FREQ_DB_CREATED == result );
      }

    // Delete some keys
    key_sz = snprintf( key, 64, "test_key_%d", 63 );
    fprintf( stderr, "deleting %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    key_sz = snprintf( key, 64, "test_key_%d", 14 );
    fprintf( stderr, "deleting %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    key_sz = snprintf( key, 64, "test_key_%d", 33 );
    fprintf( stderr, "deleting %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    key_sz = snprintf( key, 64, "test_key_%d", 99 );
    fprintf( stderr, "deleting %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    key_sz = snprintf( key, 64, "test_key_%d", 0 );
    fprintf( stderr, "deleting %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    key_sz = snprintf( key, 64, "test_key_%d", 67 );
    fprintf( stderr, "deleting %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    // Check that the counts are correct
    assert( 94 == db->file_hdr->live_cnt );
    assert(  6 == db->file_hdr->del_cnt  );

    // Check deleting non-existant keys
    fprintf( stderr, "deleting (non-existant) %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_NOTFOUND == result );

    key_sz = snprintf( key, 64, "test_key_%d", 100 );
    fprintf( stderr, "deleting (non-existant) %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_NOTFOUND == result );

    key_sz = snprintf( key, 64, "test_key_%d", 1000 );
    fprintf( stderr, "deleting (non-existant) %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_NOTFOUND == result );
    
    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_gc(void)
  {
    char test_dir[] = "/tmp/test_freq_db_gc_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;

    // Open new db 
    malloc_null_at = 1; 
    fprintf( stderr, "test delete - opening %s ", filename );
    int result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) ) ;
    type.interval_cnt = 32;
    type.interval_mins = 60;
    type.interval_bits = 31;

    char key[64];
    int key_sz;

    uint64_t deleted_freq_bytes = 0;
    freq_count_t count;

    // Write some keys
    int i = 0;
    for ( i = 0; i < 512; i++ )
      {
        key_sz = snprintf( key, 64, "test_key_%d", i );
        //fprintf( stderr, "adding key %s ", key );
        result = freq_db_increment( db, &type, key, key_sz, 0 );
        //fprintf( stderr, "done: %d\n", result );
        assert( FREQ_DB_CREATED == result );
      }

    // Delete a single key in the middle of the range
    key_sz = snprintf( key, 64, "test_key_%d", 255 );
    fprintf( stderr, "deleting %s ", key );
    result = freq_db_delete( db, &type, key, key_sz );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );

    // Do GC
    freq_db_gc_stats_t gc_stats;
    deleted_freq_bytes = sizeof( freq_header_t ) + 124 + key_sz;
    fprintf( stderr, "starting GC " );
    result = freq_db_gc( db, &gc_stats );
    fprintf( stderr,
             "done: %d - collected %"PRIu64" freqs for %"PRIu64" bytes (should be %"PRIu64")\n",
             result, gc_stats.collected_freqs, gc_stats.collected_bytes, deleted_freq_bytes );
    assert( FREQ_DB_SUCCESS == result );
    assert( 1 == gc_stats.collected_freqs );
    assert( deleted_freq_bytes == gc_stats.collected_bytes );

    // Make sure all non-deleted keys can be found
    for ( i = 0; i < 512; i++ )
      {
        if ( i == 255 ) continue;
        key_sz = snprintf( key, 64, "test_key_%d", i );
        result = freq_db_count( db, &type, key, key_sz, 59, 0, &count );
        assert( FREQ_DB_SUCCESS == result );
        assert( 1 == count.value );
      }

    // Delete half the keys
    uint64_t deleted_freqs = 0;
    deleted_freq_bytes = 0;
    for ( i = 0; i < 512; i ++ )
      {
        if ( i % 2 == 1 ) continue; // skip odd keys
        key_sz = snprintf( key, 64, "test_key_%d", i );
        result = freq_db_delete( db, &type, key, key_sz );
        assert( FREQ_DB_SUCCESS == result );
        deleted_freq_bytes += sizeof( freq_header_t ) + 124 + key_sz;
        deleted_freqs++;
      }

    // Do GC
    fprintf( stderr, "starting GC " );
    result = freq_db_gc( db, &gc_stats );
    fprintf( stderr,
             "done: %d - collected %"PRIu64" freqs for %"PRIu64" bytes (should be %"PRIu64")\n",
             result, gc_stats.collected_freqs, gc_stats.collected_bytes, deleted_freq_bytes );
    assert( FREQ_DB_SUCCESS == result );
    assert( deleted_freqs == gc_stats.collected_freqs );
    assert( deleted_freq_bytes == gc_stats.collected_bytes );

    // Make sure all non-deleted keys can be found
    for ( i = 0; i < 512; i++ )
      {
        if ( i == 255 || i % 2 == 0 ) continue;
        key_sz = snprintf( key, 64, "test_key_%d", i );
        //fprintf( stderr, "counting key %s ", key );
        result = freq_db_count( db, &type, key, key_sz, 59, 0, &count );
        //fprintf( stderr,
        //         "done: %d - value: %"PRIu64" last_update_min: %"PRIu64"\n",
        //         result, count.value, count.last_update_min );
        assert( FREQ_DB_SUCCESS == result );
        assert( 1 == count.value );
      }

    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_increment(void)
  {
    char test_dir[] = "/tmp/test_freq_db_increment_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;

    // Open new db 
    malloc_null_at = 1; 
    fprintf( stderr, "test increment - opening %s ", filename );
    int result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 1;
    type.interval_mins = 129600;
    type.interval_bits = 8;

    char key[64];
    int key_sz;

    // Increment key
    key_sz = snprintf( key, 64, "test_key_1" );
    fprintf( stderr, "adding key %s ", key );
    result = freq_db_increment( db, &type, key, key_sz, 0 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    // Count key
    freq_count_t count;
    fprintf( stderr, "counting key %s ", key );
    result = freq_db_count( db, &type, key, key_sz, 5, 0, &count );
    fprintf( stderr,
             "done: %d - value: %"PRIu64" last_update_min: %"PRIu64"\n",
             result, count.value, count.last_update_min );
    assert( FREQ_DB_SUCCESS == result );
    assert( 1 == count.value );

    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_get_binary(void)
  {
    char test_dir[] = "/tmp/test_freq_db_get_binary_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;

    // Open new db 
    malloc_null_at = 0; 
    fprintf( stderr, "test get_binary - opening %s ", filename );
    int result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 32;
    type.interval_mins = 60;
    type.interval_bits = 31;

    char key[] = "binary_key";
    int key_sz = strlen( key );

    result = freq_db_increment( db, &type, key, key_sz, 0 );

    char binary[1024];
    uint64_t binary_sz;

    fprintf( stderr, "attempting to get binary with too small buffer\n" );
    result = freq_db_get_binary( db, &type, key, key_sz, binary, 10, &binary_sz );
    fprintf( stderr, "buff size needed %"PRIu64", done: %d\n", binary_sz, result );

    assert( FREQ_DB_BUFF_TOO_SMALL == result );

    fprintf( stderr, "attempting to get binary with bigger buffer\n" );
    result = freq_db_get_binary( db, &type, key, key_sz, binary, 1024, &binary_sz );
    fprintf( stderr, "buff size needed %"PRIu64", done: %d\n", binary_sz, result );

    assert( FREQ_DB_SUCCESS == result );

    // Convert to header so we can check it
    freq_header_t *hdr = (freq_header_t*) binary; 
    assert( 0 == memcmp( &type, binary, sizeof(freq_type_t) ) );
    assert( key_sz == freq_get_key_sz( hdr ) );
    assert( 0 == strncmp( key, freq_get_key( hdr ), key_sz ) );

    freq_count_t count;
    freq_count( hdr, 60, 0, &count );

    fprintf( stderr, 
             "freq_count_t.value = %"PRIu64" freq_count_t.last_update_min = %"PRIu64"\n",
             count.value, count.last_update_min );

    assert( 1 == count.value );

    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_put_binary(void)
  {
    char test_dir[] = "/tmp/test_freq_db_put_binary_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;

    // Open new db 
    malloc_null_at = 0; 
    fprintf( stderr, "test put_binary - opening %s ", filename );
    int result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 32;
    type.interval_mins = 60;
    type.interval_bits = 31;

    char key[] = "binary_key";
    int key_sz = strlen( key );

    result = freq_db_increment( db, &type, key, key_sz, 0 );

    char binary[1024];
    uint64_t binary_sz;

    result = freq_db_get_binary( db, &type, key, key_sz, binary, 1024, &binary_sz );
    fprintf( stderr, "buff size needed %"PRIu64", done: %d\n", binary_sz, result );

    assert( FREQ_DB_SUCCESS == result );

    freq_count_t count;

    result = freq_db_count( db, &type, key, key_sz, 59, 0, &count );
    assert( FREQ_DB_SUCCESS == result );
    assert( 1 == count.value );

    result = freq_db_put_binary( db, binary, binary_sz, FREQ_DB_PUT_MERGE );
    assert( FREQ_DB_SUCCESS == result );

    result = freq_db_count( db, &type, key, key_sz, 59, 0, &count );
    fprintf( stderr, "merge count is %"PRIu64"\n", count.value );
    assert( FREQ_DB_SUCCESS == result );
    assert( 2 == count.value );

    result = freq_db_put_binary( db, binary, binary_sz, FREQ_DB_PUT_OVERWRITE );
    assert( FREQ_DB_SUCCESS == result );

    result = freq_db_count( db, &type, key, key_sz, 59, 0, &count );
    fprintf( stderr, "overwrite count is %"PRIu64"\n", count.value );
    assert( FREQ_DB_SUCCESS == result );
    assert( 1 == count.value );

    // Increment a few times so we can tell if the value changed
    result = freq_db_increment( db, &type, key, key_sz, 0 );
    result = freq_db_increment( db, &type, key, key_sz, 0 );

    result = freq_db_count( db, &type, key, key_sz, 59, 0, &count );
    assert( FREQ_DB_SUCCESS == result );
    assert( 3 == count.value );

    result = freq_db_put_binary( db, binary, binary_sz, FREQ_DB_PUT_DONTPUT );
    assert( FREQ_DB_SUCCESS == result );

    result = freq_db_count( db, &type, key, key_sz, 59, 0, &count );
    fprintf( stderr, "donput count is %"PRIu64"\n", count.value );
    assert( FREQ_DB_SUCCESS == result );
    assert( 3 == count.value );

    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_iter_init(void)
  {
    char test_dir[] = "/tmp/test_freq_db_iter_init_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;

    // Open new db 
    malloc_null_at = 0; 
    fprintf( stderr, "test iter_init - opening %s ", filename );
    int result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 32;
    type.interval_mins = 60;
    type.interval_bits = 31;

    char key[] = "binary_key";
    int key_sz = strlen( key );

    malloc_count = 0;
    malloc_null_at = 1;
    
    freq_db_iter_t *iter;
    result = freq_db_iter_init( db, &iter );
    assert( FREQ_DB_SYS_ERR_MALLOC == result );

    result = freq_db_iter_init( db, &iter );
    assert( FREQ_DB_ITER_EOF == result );
    result = freq_db_iter_done( &iter );
    assert( FREQ_DB_SUCCESS == result );

    result = freq_db_increment( db, &type, key, key_sz, 0 );
    assert( FREQ_DB_CREATED == result );

    result = freq_db_iter_init( db, &iter );
    assert( FREQ_DB_SUCCESS == result );
    result = freq_db_iter_done( &iter );
    assert( FREQ_DB_SUCCESS == result );

    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_iter_next(void)
  {
    char test_dir[] = "/tmp/test_freq_db_iter_next_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;

    // Open new db 
    malloc_null_at = 0; 
    fprintf( stderr, "test iter_next - opening %s ", filename );
    int result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 32;
    type.interval_mins = 60;
    type.interval_bits = 31;

    char key[] = "binary_key";
    int key_sz = strlen( key );

    freq_db_iter_t *iter;

    result = freq_db_increment( db, &type, key, key_sz, 0 );
    assert( FREQ_DB_CREATED == result );

    result = freq_db_iter_init( db, &iter );
    assert( FREQ_DB_SUCCESS == result );
    result = freq_db_iter_done( &iter );
    assert( FREQ_DB_SUCCESS == result );

    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


static void
test_freq_db_iter_done(void)
  {
    char test_dir[] = "/tmp/test_freq_db_iter_done_XXXXXX";
    mkdtemp( test_dir );

    char filename[64];
    snprintf( filename, 64, "%s/freqdb.fdb", test_dir );

    freq_db_t *db = NULL;

    // Open new db 
    malloc_null_at = 0; 
    fprintf( stderr, "test iter_done - opening %s ", filename );
    int result = freq_db_open( &db, filename, 1024 * 1024 );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_CREATED == result );

    freq_type_t type;
    memset( &type, 0, sizeof( freq_type_t ) );
    type.interval_cnt = 32;
    type.interval_mins = 60;
    type.interval_bits = 31;

    char key[] = "binary_key";
    int key_sz = strlen( key );

    freq_db_iter_t *iter;

    result = freq_db_increment( db, &type, key, key_sz, 0 );
    assert( FREQ_DB_CREATED == result );

    result = freq_db_iter_init( db, &iter );
    printf( "result = %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
    result = freq_db_iter_done( &iter );
    printf( "result = %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
    printf( "iter = %ld\n", (long)iter );
    result = freq_db_iter_done( &iter );
    printf( "result = %d\n", result );
    assert( FREQ_DB_ITER_INACTIVE == result );

    // Close db
    fprintf( stderr, "closing db " );
    result = freq_db_close( db );
    fprintf( stderr, "done: %d\n", result );
    assert( FREQ_DB_SUCCESS == result );
  }


int main(void)
  {
    test_type_key_cmp();
    test_idx_init();
    test_freq_db_idx_expand();
    test_freq_db_open();
    test_freq_db_info();
    test_freq_db_file_expand();
    test_freq_db_increment();
    test_freq_db_delete();
    test_freq_db_gc();
    test_freq_db_get_binary();
    test_freq_db_put_binary();
    test_freq_db_iter_init();
    test_freq_db_iter_next();
    test_freq_db_iter_done();
    return 0;
  }
