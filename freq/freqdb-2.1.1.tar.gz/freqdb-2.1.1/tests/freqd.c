#include <inttypes.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>

#include "freq_db.h"
#include "freq_type.h"
#include "freq_count.h"
#include "freq.h"
#include "tlog.h"

int main (void)
  {
//    const char *test_key1 = "thisisatestkey:p17014:c14142";
    const char *test_key1 = "testme";
    uint16_t key_sz1 = strlen( test_key1 );

//    const char *test_key2 = "thisisalsoatestkey:p1209:c92304";
//    uint16_t key_sz2 = strlen( test_key2 );

    const char *fname = "./test.db"; 
    freq_db_t *db = NULL;

    /* remove last run if any */
    unlink (fname);

    fprintf (stderr, "opening db...");
    int result = freq_db_open( &db, fname, 1024 * 1024 );
    fprintf (stderr, "done %d\n", result);

    freq_type_t type;
    type.interval_cnt = 1;
    type.interval_mins = 129600;
    type.interval_bits = 16;

    int i = 0;
    int good = 0;
    for ( i = 0; i < 10; i++ )
      {
        fprintf( stderr, "hi\n" );
        result = freq_db_increment( db, &type, test_key1, key_sz1, 0 );
        fprintf (stderr, "INCREMENT {%d %d %d}:%s : %d\n", type.interval_cnt, type.interval_mins, type.interval_bits, test_key1, result );
        if (result == 0)
          good++;

        fprintf (stderr, "sleep 1 seconds\n" );
        sleep (1);

//        fprintf (stderr, "INCR  %s ", test_key2 );
//        result = freq_db_increment( db, &type, test_key2, key_sz2, 0 ); 
//        fprintf (stderr, ": %d\n", result );
//
//        fprintf (stderr, "sleep 5 seconds\n");
//        sleep (4);
      }

    freq_count_t count;
    
    result = freq_db_count( db, &type, test_key1, key_sz1, 2, 0, &count );
    fprintf (stderr, "COUNT {%d %d %d}:%s value: %"PRIu64" last_update_min: %"PRIu64"\n", type.interval_cnt, type.interval_mins, type.interval_bits, test_key1, count.value, count.last_update_min);

    result = freq_db_count( db, &type, test_key1, key_sz1, 129600, 0, &count );
    fprintf (stderr, "COUNT {%d %d %d}:%s value: %"PRIu64" last_update_min: %"PRIu64"\n", type.interval_cnt, type.interval_mins, type.interval_bits, test_key1, count.value, count.last_update_min);

//    fprintf (stderr, "COUNT %s ", test_key2 );
//    count = freq_db_count( db, &type, test_key2, key_sz2, 10, 0 );
//    fprintf (stderr, ": %"PRIu64"\n", count );

    fprintf (stderr, "closing db..." );
    result = freq_db_close( db );
    fprintf (stderr, "done %d\n", result );

    return 0;
  }

