#include <stdlib.h>
#include "error.h"
#include "freq.h"
#include "freq_record.h"
#include "pthreadwrappers.h"

struct freq_record {
  off_t            hdr_offset;
  pthread_rwlock_t rwlock;
};

int
freq_record_create( freq_record_t **record,
                    off_t hdr_offset )
  {
    freq_record_t *rec = malloc( sizeof(freq_record_t) );
    if ( rec == NULL )
      {
        ERR_RET( "malloc of freq_record_t failed", NULL );
        return FREQ_DB_SYS_ERR_MALLOC;
      }

    rec->hdr_offset = hdr_offset;

    Pthread_rwlock_init( &rec->rwlock, NULL );

    *record = rec;

    return FREQ_DB_SUCCESS;
  }


void
freq_record_destroy( freq_record_t *record )
  {
    Pthread_rwlock_destroy( &record->rwlock );
    free( record );
  }


void
freq_record_readlock( freq_record_t *record )
  {
    Pthread_rwlock_rdlock( &record->rwlock );
  }


void
freq_record_writelock( freq_record_t *record )
  {
    Pthread_rwlock_wrlock( &record->rwlock );
  }


void
freq_record_unlock( freq_record_t *record )
  {
    Pthread_rwlock_unlock( &record->rwlock );
  }


void
freq_record_move_to( freq_record_t *record,
                     off_t new_hdr_offset )
  {
    record->hdr_offset = new_hdr_offset;
  }


freq_header_t *
freq_record_header( const char *base, freq_record_t *record )
  {
    return (freq_header_t*) (base + record->hdr_offset);
  }

