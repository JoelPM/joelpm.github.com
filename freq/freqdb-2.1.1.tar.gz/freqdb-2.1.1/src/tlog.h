#ifndef __TLOG_H
#define __TLOG_H

#define TLOG_DEBUG( fmt, ... ) tlog_debug( __func__, fmt, __VA_ARGS__ )
#define TLOG_TRACE( fmt, ... ) tlog_trace( __func__, fmt, __VA_ARGS__ )
#define TLOG_INFO( fmt, ... ) tlog_info( __func__, fmt, __VA_ARGS__ )

inline void
tlog_trace( const char *fnc, const char *fmt, ... );

inline void
tlog_debug( const char *fnc, const char *fmt, ... );

inline void
tlog_info( const char *fnc, const char *fmt, ... );

#endif /* __TLOG_H_ */
