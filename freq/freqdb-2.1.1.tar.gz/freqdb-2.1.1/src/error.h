#ifndef __ERROR_H
#define __ERROR_H

#define ERR_DUMP( fmt, ... ) err_dump( __func__, fmt, __VA_ARGS__ )
#define ERR_RET( fmt, ... ) err_ret( __func__, fmt, __VA_ARGS__ )
#define ERR_MSG( fmt, ... ) err_msg( __func__, fmt, __VA_ARGS__ )
#define ERR_QUIT( fmt, ... ) err_quit( __func__, fmt, __VA_ARGS__ )
#define ERR_SYS( fmt, ... ) err_sys( __func__, fmt, __VA_ARGS__ )

void
err_dump( const char *fnc, const char *fmt, ... );

void
err_ret( const char *fnc, const char *fmt, ... );

void
err_msg( const char *fnc, const char *fmt, ... );

void
err_quit( const char *fnc, const char *fmt, ... ); 

void
err_sys( const char *fnc, const char *fmt, ... );

#endif /* __ERROR_H */
