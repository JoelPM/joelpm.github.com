#ifndef __FREQ_TYPE_H
#define __FREQ_TYPE_H

#include <inttypes.h>

typedef struct freq_type {
  uint32_t interval_cnt;   // Number of intervals
  uint32_t interval_mins;  // Number of minutes per interval
  uint8_t  interval_bits;  // Number of bits per interval
} freq_type_t;

void
freq_type_init( uint32_t     interval_cnt,
                uint32_t     interval_mins,
                uint8_t      interval_bits,
                freq_type_t *type );

int
freq_type_cmp( freq_type_t *ft1, freq_type_t *ft2 );

uint8_t
freq_type_max_val_to_bits( uint64_t max_value );

#endif /* __FREQ_H */
