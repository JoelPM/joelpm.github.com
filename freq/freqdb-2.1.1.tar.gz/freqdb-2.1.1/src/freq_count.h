#ifndef __FREQ_COUNT_H
#define __FREQ_COUNT_H

#include <inttypes.h>

typedef struct freq_count {
  uint64_t value;            // Number of occurrences
  uint64_t last_update_min;  // Last time the freq was updated
} freq_count_t;

#endif /* __FREQ_COUNT_H */
