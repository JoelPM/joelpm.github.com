#ifndef __FREQ_H
#define __FREQ_H

#include <inttypes.h>
#include <stdio.h>
#include <time.h>

#include "freq_type.h"
#include "freq_count.h"

#define FREQ_DELETED -1
#define FREQ_ACTIVE   0

typedef struct freq_header {
  freq_type_t type;             // Frequency type.
  int8_t      status;           // Status of this freq.
  uint64_t    last_update_min;  // Last update of this frequency.
  uint64_t    key_hashcode;     // Hash value for this key.
  uint16_t    key_sz;           // Size of the key array.
  uint64_t    data_sz;          // Size of the data array.
} freq_header_t;

void
freq_print_header( FILE *out, freq_header_t *hdr );

freq_type_t*
freq_get_type( freq_header_t *hdr );

const char*
freq_get_key( freq_header_t *hdr );

uint16_t
freq_get_key_sz( freq_header_t *hdr );

int
freq_get_status( freq_header_t *hdr );

int
freq_set_status( freq_header_t *hdr, int status );

uint64_t
freq_get_size( freq_header_t *hdr );

uint8_t*
freq_get_data( freq_header_t *hdr );

uint64_t
freq_get_data_sz( freq_header_t *hdr );

int
freq_is_stale( freq_header_t *hdr );

int
freq_increment( freq_header_t *hdr,
                uint32_t offset_min );

int
freq_count( freq_header_t *hdr,
            uint32_t range_min, uint32_t offset_min,
            freq_count_t *count );

int
freq_merge( freq_header_t *dst_hdr,
            freq_header_t *src_hdr );

#endif /* __FREQ_H */
