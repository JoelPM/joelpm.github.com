#include <inttypes.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include "freq.h"
#include "freq_db_err.h"
#include "pthreadwrappers.h"
#include "tlog.h"

#define BYTE(t) ( (t) / 8 )
#define BIT(t) ( (t) % 8 )

#define MINUTES(t) ( (t) / 60 )

/******************************************************************************
 * Interval Functions                                                         *
 *****************************************************************************/

inline static uint32_t
interval_get_max( freq_header_t *hdr );

inline static uint32_t
interval_get_value( freq_header_t *hdr, uint8_t *data,
                    uint32_t interval_num );

inline static void
interval_set_value( freq_header_t *hdr, uint8_t *data,
                    uint32_t interval_num, uint32_t value );

inline static int
interval_clear_all_in_range( freq_header_t *hdr, uint8_t *data,
                             uint32_t start_min, uint32_t end_min );

inline static uint32_t
interval_get_max( freq_header_t *hdr )
  {
    return ( 1 << hdr->type.interval_bits ) - 1;
  }


inline static uint32_t
interval_get_value( freq_header_t *hdr, uint8_t *data,
                    uint32_t interval_num )
  {
    if ( interval_num >= hdr->type.interval_cnt ) return 0;

    uint64_t start_bit = interval_num * hdr->type.interval_bits;

    uint64_t val = 0;
    uint64_t bit;
    for ( bit = 0; bit < hdr->type.interval_bits; bit++ )
      {
        if ( data[ BYTE( start_bit + bit ) ] & ( 1 << BIT( start_bit + bit ) ) )
          val |= 1 << bit;
      }
    return val;
  }


inline static void
interval_set_value( freq_header_t *hdr, uint8_t *data,
                    uint32_t interval_num, uint32_t val )
  {
    if ( interval_num >= hdr->type.interval_cnt ) return;

    uint64_t start_bit = interval_num * hdr->type.interval_bits;

    uint64_t bit;
    for ( bit = 0; bit < hdr->type.interval_bits; bit++ )
      {
        unsigned char *c = &data[ BYTE( start_bit + bit )];

        if ( val & ( 1 << bit ) )
          *c |= 1 << BIT( start_bit + bit );
        else
          *c &= ~(1 << BIT( start_bit + bit ));
      }
  }


inline static int
interval_clear_all_in_range( freq_header_t *hdr, uint8_t *data,
                             uint32_t start_min, uint32_t end_min )
  {
    uint32_t start_intrvl = start_min / hdr->type.interval_mins + 1;
    uint32_t end_intrvl   = end_min / hdr->type.interval_mins;
    uint32_t clear_cnt    = end_intrvl - start_intrvl + 1;

//    fprintf (stderr, "start_min: %"PRIu32", end_min: %"PRIu32", "
//                     "start_intrvl: %"PRIu32", end_intrvl: %"PRIu32", "
//                     "clear_cnt: %"PRIu32"\r\n",
//                start_min, end_min, start_intrvl, end_intrvl, clear_cnt );

    if ( start_intrvl > end_intrvl ) return 0;

    // Easy case, all buckets cleared
    if ( clear_cnt >= hdr->type.interval_cnt )
      {
        memset( data, 0, hdr->data_sz );
      }
    else 
      {
        uint32_t b;
        uint32_t intrvl_idx;
        for ( b = 0; b < clear_cnt; b++ )
          {
            intrvl_idx = ( start_intrvl + b ) % hdr->type.interval_cnt;
            interval_set_value( hdr, data, intrvl_idx, 0 );
          }
      }

    return clear_cnt;
  }


/******************************************************************************
 * Freq Functions                                                             *
 *****************************************************************************/

int
freq_increment( freq_header_t *hdr,
                uint32_t offset_min )
  {
    // Check if offset_min is too far in the past
    if ( offset_min > hdr->type.interval_cnt * hdr->type.interval_mins )
      {
        return FREQ_DB_OFFSET_EXPIRED;
      }

    // Get current time
    uint32_t now_min = MINUTES( time( NULL ) );

    // Calculate time of increment
    uint32_t incr_min = now_min - offset_min;

    // Get data
    uint8_t *data = freq_get_data( hdr );

    // Zero out any buckets that have stale data
    interval_clear_all_in_range( hdr, data, hdr->last_update_min, incr_min );
 
    uint32_t intrvl_idx = ( incr_min / hdr->type.interval_mins ) 
                        % hdr->type.interval_cnt;
    uint32_t val = interval_get_value( hdr, data, intrvl_idx );

    // Update last_update_min if incr_min newer than previous last update 
    if ( incr_min > hdr->last_update_min )
      hdr->last_update_min = incr_min;

    // Bail if we're going to overflow the max value
    if ( val == interval_get_max( hdr ) )
      return FREQ_DB_OVERFLOW;

    // Store incremented value
    interval_set_value( hdr, data, intrvl_idx, val + 1 );

    return FREQ_DB_SUCCESS;
  }


int
freq_count( freq_header_t *hdr,
            uint32_t range_min, uint32_t offset_min,
            freq_count_t *count )
  {
    if ( hdr == NULL )
      {
        count->value = 0ULL;
        count->last_update_min = 0ULL;
        return FREQ_DB_NOTFOUND;
      }

    uint8_t *data = freq_get_data( hdr );

    uint32_t now_min = MINUTES( time( NULL ) );    // Current time in minutes
    uint32_t end_min = now_min - offset_min;       // End of requested range in minutes
    uint32_t start_min = end_min - range_min + 1;  // Start of requested range in minutes
    uint32_t avail_min = hdr->type.interval_cnt    // Number of minutes covered
                       * hdr->type.interval_mins;  //   by data
    uint32_t oldest_min = now_min - avail_min;     // Farthest back in time we can count

    // If we don't have the range we return 0
    if ( start_min < oldest_min ) start_min = oldest_min;

    // If part of the range is unavailable we sum over the
    // the part that is avaiable
    if ( end_min < oldest_min ) return 0;

    uint32_t end_intrvl   = end_min / hdr->type.interval_mins;    // Last bucket to sum
    uint32_t start_intrvl = start_min / hdr->type.interval_mins;  // First bucket to sum

    uint32_t sum_cnt = end_intrvl - start_intrvl;            // Number of buckets to sum
    uint32_t last_updated_intrvl = hdr->last_update_min      // Last bucket to be updated,
                                 / hdr->type.interval_mins;  //   all buckets newer than

    // Don't sum more intervals than we have (or we'll double count).
    // AFAIK, this is only an issue when you have a single interval.
    if ( sum_cnt >= hdr->type.interval_cnt ) sum_cnt = hdr->type.interval_cnt - 1;

    //TLOG_DEBUG( "start_min: %d, end_min: %d, avail_min: %d, oldest_min, %d "
    //            "start_intrvl: %d, end_intrvl: %d, sum_cnt: %d, last_updated_intrvl: %d ",
    //            start_min, end_min, avail_min, oldest_min,
    //            start_intrvl, end_intrvl, sum_cnt, last_updated_intrvl );

    uint32_t b;           // Loop variable
    uint32_t intrvl_idx;  // Index of bucket in circular array
    uint32_t intrvl_val;  // Value of current bucket
    int64_t  value = 0;   // Total count

    for ( b = 0; b <= sum_cnt; b++ )
      {
        if ( start_intrvl + b > last_updated_intrvl ) continue;  // Skip stale buckets

        intrvl_idx = ( start_intrvl + b ) % hdr->type.interval_cnt;
        intrvl_val = interval_get_value( hdr, data, intrvl_idx );

        // Bail if we're going to overflow max value allowed for int64_t
        if ( UINT64_MAX - value < intrvl_val ) return FREQ_DB_OVERFLOW;

        value += intrvl_val;
      }

    count->value = value;
    count->last_update_min = hdr->last_update_min; 
    return FREQ_DB_SUCCESS;
  }


int
freq_merge( freq_header_t *dst_hdr,
            freq_header_t *src_hdr )
  {
    const char *dst_key = freq_get_key( dst_hdr );
    const char *src_key = freq_get_key( src_hdr );

    uint8_t *dst_data = freq_get_data( dst_hdr );
    uint8_t *src_data = freq_get_data( src_hdr );

    // Make sure necessary things are the same
    if ( 0 != memcmp( dst_hdr, src_hdr, sizeof(freq_type_t) ) ||
         dst_hdr->key_hashcode != src_hdr->key_hashcode ||
         dst_hdr->key_sz != src_hdr->key_sz ||
         dst_hdr->data_sz != src_hdr->data_sz ||
         0 != memcmp( dst_key, src_key, dst_hdr->key_sz ) )
      {
        return FREQ_DB_INCOMPATIBLE;
      }

    uint32_t now_min = MINUTES( time( NULL ) );    // Current time in minutes
    uint32_t now_intrvl = now_min / src_hdr->type.interval_mins;
    uint32_t start_intrvl = now_intrvl - src_hdr->type.interval_cnt + 1;

    uint32_t src_last_updated_intrvl = src_hdr->last_update_min
                                     / src_hdr->type.interval_mins;
    uint32_t dst_last_updated_intrvl = dst_hdr->last_update_min
                                     / dst_hdr->type.interval_mins;

    uint32_t intrvl;
    uint32_t intrvl_val;
    uint32_t intrvl_idx;
    uint32_t intrvl_max = interval_get_max( dst_hdr );

    for ( intrvl = start_intrvl; intrvl <= now_intrvl; intrvl++ )
      {
        intrvl_idx = intrvl % dst_hdr->type.interval_cnt;
        intrvl_val = 0;

        if ( intrvl <= src_last_updated_intrvl )
          intrvl_val += interval_get_value( src_hdr, src_data, intrvl_idx );

        if ( intrvl <= dst_last_updated_intrvl )
          intrvl_val += interval_get_value( dst_hdr, dst_data, intrvl_idx );

        if ( intrvl_val > intrvl_max )
          intrvl_val = intrvl_max;

        interval_set_value( dst_hdr, dst_data, intrvl_idx, intrvl_val );
      }

    if ( src_hdr->last_update_min > dst_hdr->last_update_min )
      dst_hdr->last_update_min = src_hdr->last_update_min;

    return FREQ_DB_SUCCESS;
  }


freq_type_t*
freq_get_type( freq_header_t * hdr )
  {
    return (freq_type_t*)hdr;
  }


const char*
freq_get_key( freq_header_t * hdr )
  {
    return ((const char*) hdr) + sizeof(freq_header_t);
  }


uint16_t
freq_get_key_sz( freq_header_t * hdr )
  {
    return hdr->key_sz;
  }


int
freq_get_status( freq_header_t * hdr )
  {
    return hdr->status;
  }


int
freq_set_status( freq_header_t *hdr, int status )
  {
    int old_status = hdr->status;
    hdr->status = status;
    return old_status;
  }


uint64_t
freq_get_size( freq_header_t *hdr )
  {
    return sizeof(freq_header_t) + hdr->key_sz + freq_get_data_sz( hdr ); //hdr->data_sz;
  }


uint8_t*
freq_get_data( freq_header_t *hdr )
  {
    return (uint8_t*)(((char*)hdr) + sizeof(freq_header_t) + hdr->key_sz);
  }


uint64_t
freq_get_data_sz( freq_header_t *hdr )
  {
    uint64_t bits = hdr->type.interval_cnt * hdr->type.interval_bits;
    uint64_t bytes = bits / 8;
    if ( bits % 8 != 0 ) bytes++;
    return bytes;
  }


int
freq_is_stale( freq_header_t *hdr )
  {
    uint32_t now_min = MINUTES( time( NULL ) );
    uint32_t intrvl_mins = hdr->type.interval_cnt
                         * hdr->type.interval_mins;

    return ( now_min - intrvl_mins > hdr->last_update_min ) ? 1 : 0;
  }


void
freq_print_header( FILE *out, freq_header_t *hdr )
  {
    fprintf (out, "header is at %p\r\n",hdr);
    fprintf( out, "freq_header_t->type.interval_cnt:  %u\r\n",  hdr->type.interval_cnt  );
    fprintf( out, "freq_header_t->type.interval_mins: %u\r\n",  hdr->type.interval_mins );
    fprintf( out, "freq_header_t->type.interval_bits: %u\r\n",  hdr->type.interval_bits );
    fprintf( out, "freq_header_t->status:             %d\r\n",  hdr->status             );
    fprintf( out, "freq_header_t->last_update_min:    %llu\r\n", (unsigned long long) hdr->last_update_min    );
    fprintf( out, "freq_header_t->key_hashcode:       %llu\r\n", (unsigned long long) hdr->key_hashcode       );
    fprintf( out, "freq_header_t->key_sz:             %u\r\n",  hdr->key_sz             );
    fprintf( out, "freq_header_t->data_sz:            %llu\r\n", (unsigned long long)hdr->data_sz            );
  }
