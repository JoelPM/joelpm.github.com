#ifndef __FREQ_DB_H
#define __FREQ_DB_H

#include "freq_db_err.h"
#include "freq_type.h"
#include "freq_count.h"

//#define DEBUG

#define FREQ_DB_PUT_MERGE      1
#define FREQ_DB_PUT_OVERWRITE  2
#define FREQ_DB_PUT_DONTPUT    3

typedef struct freq_db freq_db_t;

typedef struct freq_db_iter freq_db_iter_t;

typedef struct freq_db_info {
  uint64_t active_freqs;
  uint64_t deleted_freqs;
  uint64_t increment_sz;
  uint64_t disk_sz;
  uint64_t index_sz;
} freq_db_info_t;

typedef struct freq_db_gc_stats {
  uint64_t collected_freqs;
  uint64_t collected_bytes;
} freq_db_gc_stats_t;

int
freq_db_open( freq_db_t **db,
              const char *filename,
              int64_t incr_sz );

int freq_db_info( freq_db_t *db,
                  freq_db_info_t *db_info );

int
freq_db_sync( freq_db_t *db );

int
freq_db_gc( freq_db_t *db,
            freq_db_gc_stats_t *gc_stats );

int
freq_db_close( freq_db_t *db );

int
freq_db_increment( freq_db_t *db,
                   freq_type_t *type,
                   const char *key, uint16_t key_sz,
                   uint32_t offset_minutes );

int
freq_db_count( freq_db_t *db,
               freq_type_t *type,
               const char *key, uint16_t key_sz,
               uint32_t minutes, uint32_t offset_minutes,
               freq_count_t *count ); 

int
freq_db_delete( freq_db_t *db,
                freq_type_t *type,
                const char *key, uint16_t key_sz );

int
freq_db_get_binary( freq_db_t *db,
                    freq_type_t *type,
                    const char *key, uint16_t key_sz,
                    char *binary_buff, uint64_t binary_buff_sz,
                    uint64_t *binary_sz );

int freq_db_put_binary( freq_db_t *db,
                        const char *binary, uint64_t binary_sz,
                        int op_if_present );

int
freq_db_iter_init( freq_db_t *db, 
                   freq_db_iter_t **iter );

int
freq_db_iter_next( freq_db_iter_t *iter );

int
freq_db_iter_done( freq_db_iter_t **iter );

int
freq_db_iter_read( freq_db_iter_t *iter,
                   freq_type_t *type,
                   char *key_buff, uint16_t key_buff_sz,
                   uint16_t *key_sz );

#endif
