#include <string.h>

#include "freq_type.h"

void
freq_type_init( uint32_t interval_cnt,
                uint32_t interval_mins,
                uint8_t  interval_bits,
                freq_type_t *type )
  {
    type->interval_cnt = interval_cnt;
    type->interval_mins = interval_mins;
    type->interval_bits = interval_bits;
  }

int
freq_type_cmp( freq_type_t *type1, freq_type_t *type2 )
  {
    if ( type1 == type2 ) return 0;
    return memcmp( type1, type2, sizeof(freq_type_t) );
  }


uint8_t
freq_type_max_val_to_bits( uint64_t max_value )
  {
    uint8_t bits = 1;
    while ( (uint64_t)(2 << ( bits - 1 )) < max_value ) bits++;
    return bits;
  }
