#ifndef __PTHREADWRAPPERS_H
#define __PTHREADWRAPPERS_H

#include <pthread.h>

void Pthread_mutex_init( pthread_mutex_t *, const pthread_mutexattr_t * );
void Pthread_mutex_lock( pthread_mutex_t * );
void Pthread_mutex_unlock( pthread_mutex_t * );

void Pthread_rwlock_init( pthread_rwlock_t *, const pthread_rwlockattr_t * );
void Pthread_rwlock_destroy( pthread_rwlock_t * );
void Pthread_rwlock_rdlock( pthread_rwlock_t * );
void Pthread_rwlock_wrlock( pthread_rwlock_t * );
void Pthread_rwlock_unlock( pthread_rwlock_t * );

#endif /* __PTHREADWRAPPERS_H */
