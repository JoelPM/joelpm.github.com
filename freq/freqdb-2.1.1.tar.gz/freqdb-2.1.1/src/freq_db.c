#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include "freq_db.h"
#include "freq_record.h"
#include "error.h"
#include "pthreadwrappers.h"
#include "lookup3.h"
#include "tlog.h"

#define IDX_MAX_INSERT_ATTEMPTS 100

#define BLOCK_SIZE 512

#define DEBUG
//#define TRACE

// 1 << 22 
//static uint64_t INITIAL_INDEX_CAPACITY = 4194304;
// 1 << 20
//static uint64_t INITIAL_INDEX_CAPACITY = 1048576;
// 1 << 19
//static uint64_t INITIAL_INDEX_CAPACITY = 524288;
// 1 << 17
static uint64_t INITIAL_INDEX_CAPACITY = 131072;
// 1 << 15
//static uint64_t INITIAL_INDEX_CAPACITY = 32768;
// 1 << 13
//static uint64_t INITIAL_INDEX_CAPACITY = 8192;

typedef struct freq_file_header {
  uint32_t version;   /* Version of the stored data. */
  uint64_t live_cnt;  /* Number of active Freqs. */
  uint64_t del_cnt;   /* Number of deleted Freqs. */
  off_t    eod;       /* End of data. */
  uint64_t incr_sz;   /* Size of blocks to grow file. */
} freq_file_header_t;

struct freq_db {
  char                *file_name;
  uint64_t             file_sz;
  int                  file_fd;
  pthread_mutex_t      file_lock;

  pthread_rwlock_t     iter_rwlock;
  pthread_rwlock_t     hdr_rwlock;
  pthread_rwlock_t     mmap_rwlock;
  union {
    char               *mmap;
    freq_file_header_t *file_hdr;
  };

  pthread_rwlock_t     idx_rwlock;
  uint64_t             idx_sz;
  uint64_t             idx_mask;
  freq_record_t        **idx;
};

struct freq_db_iter {
  freq_db_t  *db;
  int        state;
  off_t      offset;
};

static unsigned char block[BLOCK_SIZE];

/******************************************************************************
 * Key Functions                                                              *
 *****************************************************************************/

static uint64_t
type_key_hash( freq_type_t *type, const char * key, uint16_t key_sz );

static int
type_key_cmp( freq_type_t *type1, const char *key1, uint16_t key1_sz,
              freq_type_t *type2, const char *key2, uint16_t key2_sz );

/******************************************************************************
 * Iterator Functions                                                         *
 *****************************************************************************/

static void
iter_readlock( freq_db_t *fdb );

static void
iter_writelock( freq_db_t *fdb );

static void
iter_unlock( freq_db_t *fdb );


/******************************************************************************
 * Index Functions                                                            *
 *****************************************************************************/

static int
idx_init( freq_db_t *db );

static void
idx_destroy( freq_db_t *db );

static int 
idx_expand( freq_db_t *fdb );

static int
idx_insert( freq_db_t *db, freq_record_t *record );

static freq_record_t*
idx_find( freq_db_t *db,
          freq_type_t *type,
          const char *key, uint16_t key_sz );

static int
idx_remove( freq_db_t *db,
            freq_type_t *type,
            const char *key, uint16_t key_sz,
            freq_record_t **deleted_record );

static void
idx_readlock( freq_db_t *fdb );

static void
idx_writelock( freq_db_t *fdb );

static void
idx_unlock( freq_db_t *fdb );


/******************************************************************************
 * File Functions                                                             *
 *****************************************************************************/

#ifdef DEBUG
static void
file_print_header( FILE* out, freq_file_header_t *file_hdr );
#endif

static off_t
file_length( int fd );

static int
file_init( int fd, uint64_t incr_size );

static int
file_expand( freq_db_t *db );

static int
file_append( freq_db_t *db,
             freq_type_t *type,
             const char *key, uint16_t key_sz,
             freq_record_t **record );

static void
file_lock( freq_db_t *db );

static void
file_unlock( freq_db_t *db );


/******************************************************************************
 * hdr Functions                                                             *
 *****************************************************************************/

// Reads are dirty for now
static void
hdr_readlock( freq_db_t *db );

static void
hdr_writelock( freq_db_t *db );

static void
hdr_unlock( freq_db_t *db );


/******************************************************************************
 * mmap Functions                                                             *
 *****************************************************************************/

static void
mmap_readlock( freq_db_t *db );

static void
mmap_writelock( freq_db_t *db );

static void
mmap_unlock( freq_db_t *db );


/******************************************************************************
 * File Functions                                                             *
 *****************************************************************************/

static int64_t
db_index_file( freq_db_t *db );

static int
db_insert( freq_db_t *db,
           freq_type_t *type,
           const char *key, uint16_t key_sz,
           freq_record_t **record );

/******************************************************************************
 * Key Functions                                                              *
 *****************************************************************************/

static uint64_t
type_key_hash( freq_type_t *type, const char *key, uint16_t key_sz )
  {
    uint32_t upper = 0, lower = 0;

    // First hash the type
    hashlittle2( type, sizeof(freq_type_t), &lower, &upper );

    // Now add the hash of the key
    hashlittle2( key, key_sz, &lower, &upper );

    // Now combine the two 32bit values for a single 64 bit hash
    uint64_t hash = lower + (((uint64_t)upper)<<32);

    return hash;
  }

static int
type_key_cmp( freq_type_t *type1, const char *key1, uint16_t key1_sz,
              freq_type_t *type2, const char *key2, uint16_t key2_sz )
  {
    if ( type1 == NULL || type2 == NULL ) return -1;
    if ( key1 == NULL || key2 == NULL ) return -1;
    if ( key1_sz < key2_sz ) return -1;
    if ( key1_sz > key2_sz ) return 1;
    int type_cmp = freq_type_cmp( type1, type2 );
    if ( type_cmp != 0 ) return type_cmp;
    return strncmp( key1, key2, key1_sz );
  }

/******************************************************************************
 * Iterator Functions                                                         *
 *****************************************************************************/

static void
iter_readlock( freq_db_t *db )
  {
    Pthread_rwlock_rdlock( &db->iter_rwlock );
  }


static void
iter_writelock( freq_db_t *db )
  {
    Pthread_rwlock_wrlock( &db->iter_rwlock );
  }


static void
iter_unlock( freq_db_t *db )
  {
    Pthread_rwlock_unlock( &db->iter_rwlock );
  }

/******************************************************************************
 * Index Functions                                                            *
 *****************************************************************************/

static int
idx_init( freq_db_t *db )
  {
    TLOG_TRACE( "%s", db->file_name );

    uint64_t init_sz = db->file_hdr->live_cnt;
    uint64_t capacity = INITIAL_INDEX_CAPACITY;
    while ( capacity < 2*init_sz ) capacity = capacity << 1;

    db->idx = (freq_record_t**)malloc( capacity * sizeof(freq_record_t*) );
    if ( db->idx == NULL )
      {
        ERR_RET( "malloc of %ld bytes for index failed",
                 capacity * sizeof(freq_record_t*) );
        return FREQ_DB_SYS_ERR_MALLOC;
      }

    memset( db->idx, 0, capacity * sizeof(freq_record_t*) );

    // Set size and mask
    db->idx_sz = capacity;
    db->idx_mask = capacity - 1;

    TLOG_TRACE( "count: %ld capacity: %ld mask: %ld", init_sz, db->idx_sz, db->idx_mask );
    return FREQ_DB_SUCCESS;
  }


static void
idx_destroy( freq_db_t *db )
  {
    TLOG_TRACE( "%s", db->file_name );

    uint64_t i;
    for ( i = 0; i < db->idx_sz; i++ )
      {
        freq_record_t *rec = db->idx[ i ];
        if ( rec != NULL ) free( rec );
      }

    free( db->idx );
    db->idx_sz = 0;
    db->idx_mask = 0;

    TLOG_TRACE( "done", NULL );
  }


static int
idx_expand( freq_db_t *db )
  {
    TLOG_TRACE( "current size: %"PRIu64, db->idx_sz );

    uint64_t new_idx_sz = db->idx_sz << 1;

    uint64_t byte_sz = new_idx_sz * sizeof(freq_record_t*);
    freq_record_t **new_idx = malloc( byte_sz );
    if ( new_idx == NULL )
      {
        ERR_RET( "malloc of %"PRIu64" bytes for expanded index failed", byte_sz );
        return FREQ_DB_SYS_ERR_MALLOC;
      }

    memset( new_idx, 0, byte_sz );

    freq_record_t **old_idx = db->idx;
    uint64_t old_idx_sz = db->idx_sz;

    db->idx = new_idx;
    db->idx_sz = new_idx_sz;
    db->idx_mask = new_idx_sz - 1;

    uint64_t i;
    for ( i = 0; i < old_idx_sz; i++ )
      {
        if ( old_idx[ i ] != NULL )
          {
            idx_insert( db, old_idx[ i ] );
          }
      }

    free( old_idx );

    TLOG_INFO( "%s - new capacity: %ld mask: %ld",
               db->file_name, new_idx_sz, new_idx_sz-1 );

    TLOG_TRACE( "new size %"PRIu64": %d", FREQ_DB_SUCCESS );
    return FREQ_DB_SUCCESS;
  }


static int
idx_insert( freq_db_t *db, freq_record_t *record )
  {
    freq_record_readlock( record );
    freq_header_t *hdr = freq_record_header( db->mmap, record );
    uint64_t idx = hdr->key_hashcode & db->idx_mask;
    freq_record_unlock( record );

    uint8_t attempts = 0;
    while ( db->idx[ idx ] != NULL )
      {
//        freq_record_t *col = db->idx[ idx ];
//        freq_header_t *col_hdr = freq_record_header( db->mmap, col );
//        TLOG_DEBUG( "[%ld] %s (hc: %ld | %ld) collides with %s (hc: %ld | %ld)",
//                    idx,
//                    freq_get_key( freq_record_header( db->mmap, record ) ),
//                    hdr->key_hashcode, hdr->key_hashcode & db->idx_mask,
//                    freq_get_key( freq_record_header( db->mmap, col ) ),
//                    col_hdr->key_hashcode, col_hdr->key_hashcode & db->idx_mask );

        idx = ( idx + 1 ) & db->idx_mask;
        if ( attempts++ == IDX_MAX_INSERT_ATTEMPTS )
          {
            ERR_RET( "%d collisions occurred while attempting to insert key "
                     "%s with hashcode %ld and idx mask %ld - not inserting.",
                     IDX_MAX_INSERT_ATTEMPTS,
                     freq_get_key( freq_record_header( db->mmap, record ) ),
                     hdr->key_hashcode, db->idx_mask );
            return FREQ_DB_ERR_IDX_COLLISIONS;
          }
      }

    db->idx[ idx ] = record;
    return FREQ_DB_SUCCESS;
  }


static freq_record_t*
idx_find( freq_db_t *db,
          freq_type_t *type,
          const char *key, uint16_t key_sz )
  {
    uint64_t hashcode = type_key_hash( type, key, key_sz );
    uint64_t idx = hashcode & db->idx_mask;

    uint8_t attempts = 0;
    while ( attempts++ < IDX_MAX_INSERT_ATTEMPTS )
      {
        if ( db->idx[ idx ] != NULL )
          {
            freq_record_t *rec = db->idx[ idx ];
            mmap_readlock( db );
            freq_record_readlock( rec );
            freq_header_t *rec_hdr = freq_record_header( db->mmap, rec );
            const char *rec_key = freq_get_key( rec_hdr );


            if ( type_key_cmp( type, key, key_sz,
                               &rec_hdr->type, rec_key, rec_hdr->key_sz ) == 0 )
              {
                freq_record_unlock( rec );
                mmap_unlock( db );
                return rec;
              }

            freq_record_unlock( rec );
            mmap_unlock( db );
          }

        // Look at the next array index, wrapping if necessary
        idx = ( idx + 1 ) & db->idx_mask;
      }

    // Not found in IDX_MAX_INSERT_ATTEMPTS, must not exist
    return NULL;
  }


static int
idx_remove( freq_db_t *db,
            freq_type_t *type,
            const char *key, uint16_t key_sz,
            freq_record_t **record )
  {
    TLOG_TRACE( "%*s", key_sz, key );
    uint64_t hashcode = type_key_hash( type, key, key_sz );
    uint64_t idx = hashcode & db->idx_mask;

    uint8_t attempts = 0;
    freq_record_t *rec = NULL;
    while ( attempts++ < IDX_MAX_INSERT_ATTEMPTS )
      {
        rec = db->idx[ idx ];
        if ( rec != NULL )
          {
            mmap_readlock( db );
            freq_record_readlock( rec );
            freq_header_t *rec_hdr = freq_record_header( db->mmap, db->idx[ idx ] );
            const char *rec_key = freq_get_key( rec_hdr );
            int cmp = type_key_cmp( type, key, key_sz,
                                    &rec_hdr->type, rec_key, rec_hdr->key_sz );
            freq_record_unlock( rec ); 
            mmap_unlock( db );

            if ( cmp == 0 )
              {
                *record = rec;
                db->idx[ idx ] = NULL;
                TLOG_TRACE( "%d", FREQ_DB_SUCCESS );
                return FREQ_DB_SUCCESS;
              }
          }

        // Look at the next array index, wrapping if necessary
        idx = ( idx + 1 ) & db->idx_mask;
      }

    // Not found in IDX_MAX_INSERT_ATTEMPTS, must not exist
    TLOG_TRACE( "%d", FREQ_DB_NOTFOUND );
    return FREQ_DB_NOTFOUND;
  }


static void
idx_readlock( freq_db_t *db )
  {
    Pthread_rwlock_rdlock( &db->idx_rwlock );
  }


static void
idx_writelock( freq_db_t *db )
  {
    Pthread_rwlock_wrlock( &db->idx_rwlock );
  }


static void
idx_unlock( freq_db_t *db )
  {
    Pthread_rwlock_unlock( &db->idx_rwlock );
  }


/******************************************************************************
 * File Functions                                                             *
 *****************************************************************************/

#ifdef DEBUG
static void
file_print_header( FILE* out, freq_file_header_t *file_hdr )
  {
    fprintf( out, "freq_file_header->version:  %d\r\n",        file_hdr->version  );
    fprintf( out, "freq_file_header->live_cnt: %"PRIu64"\r\n", file_hdr->live_cnt );
    fprintf( out, "freq_file_header->del_cnt:  %"PRIu64"\r\n", file_hdr->del_cnt  );
    fprintf( out, "freq_file_header->eod:      %"PRIu64"\r\n", (uint64_t)file_hdr->eod      );
  }
#endif

static off_t
file_length( int fd )
  {
    off_t orig_offset = lseek( fd, 0, SEEK_CUR );
    if ( orig_offset == -1 )
      ERR_RET( "unable to get current file offset", NULL );

    TLOG_DEBUG( "orig_offset: %ld", orig_offset );
 
    off_t end_offset = lseek( fd, 0, SEEK_END );

    TLOG_DEBUG( "filelength: %ld", end_offset );

    off_t off;
    if ( orig_offset >= 0 )
      if ( ( off = lseek( fd, orig_offset, SEEK_SET ) ) != orig_offset )
        ERR_RET( "unable to restore original file offset (%ld instead of %ld)",
                 off, orig_offset );

    return end_offset;
  }


static int
file_init( int fd, uint64_t incr_size )
  {
    int trnc_res = ftruncate( fd, incr_size );
    if ( trnc_res != 0 )
      {
        ERR_RET( "ftruncate to %ld failed", incr_size );
        return FREQ_DB_SYS_ERR_FTRUNCATE;
      }

    size_t file_hdr_sz = sizeof(freq_file_header_t);

    freq_file_header_t file_hdr;
    memset( &file_hdr, 0, sizeof( file_hdr ) );
    file_hdr.version = 0;
    file_hdr.live_cnt = 0;
    file_hdr.del_cnt = 0;
    file_hdr.eod = file_hdr_sz;
    file_hdr.incr_sz = incr_size;

    ssize_t write_sz = write( fd, &file_hdr, file_hdr_sz );
    if ( write_sz == -1 )
      {
        ERR_RET( "write of freq_file_header_t failed", NULL );
        return FREQ_DB_SYS_ERR_WRITE;
      }
    else if ( (size_t)write_sz != file_hdr_sz )
      {
        ERR_RET( "write of freq_file_header_t incomplete " 
                 " (%ld of %ld bytes)", write_sz, file_hdr_sz );
        return FREQ_DB_SYS_ERR_WRITE;
      }

    return FREQ_DB_SUCCESS;
  }


static int
file_expand( freq_db_t *db )
  {
    TLOG_DEBUG( "beginning file_expand", NULL );
    struct timeval xpnd_start, xpnd_end;
    gettimeofday( &xpnd_start, NULL );

    uint64_t file_old_sz = db->file_sz;
    uint64_t file_new_sz = file_old_sz + db->file_hdr->incr_sz;

    // Increase the file size
    int rsz_res = ftruncate( db->file_fd, file_new_sz );

    if ( rsz_res == -1 )
      {
        ERR_RET( "attempt to expand DB file from %ld to %ld bytes failed",
                 file_old_sz, file_new_sz );
        return FREQ_DB_SYS_ERR_FTRUNCATE;
      }

    // lock mmap for writing
    mmap_writelock( db );

    // Sync mmap before unmapping
    int sync_res = msync( db->mmap, file_old_sz, MS_SYNC );

    if ( sync_res != 0 )
      ERR_RET( "%s - syncing file to disk failed - data may be lost", db->file_name );

    // Remap file so new range is covered
    int unmap_res = munmap( db->mmap, file_old_sz );
    if ( unmap_res != 0 )
      ERR_RET( "%s - munmap failed (ignored)", db->file_name );

    // Set new file size
    db->file_sz = file_new_sz;

    // Memory map the expanded file
    db->mmap = mmap( (caddr_t)0,
                          db->file_sz,
                          PROT_READ | PROT_WRITE | PROT_EXEC,
                          MAP_SHARED,
                          db->file_fd, 
                          0 );
    int saved_err = errno;
    TLOG_DEBUG( "mmap completed: %s", strerror( saved_err ) );

    // Unlock mmap
    mmap_unlock( db );

    if ( db->mmap == MAP_FAILED )
      {
        TLOG_DEBUG( "mmap failed, halting", NULL );
        ERR_QUIT( "mmap failed, halting", NULL );
      }

    gettimeofday( &xpnd_end, NULL );

    uint64_t xpnd_start_millis = ((uint64_t)xpnd_start.tv_sec) * ((uint64_t)1000)
                               + ((uint64_t)(xpnd_start.tv_usec/1000));
    uint64_t xpnd_end_millis = ((uint64_t)xpnd_end.tv_sec) * ((uint64_t)1000)
                             + ((uint64_t)(xpnd_end.tv_usec/1000));
    uint64_t xpnd_millis = xpnd_end_millis - xpnd_start_millis;

    TLOG_INFO( "%s - file expand took %"PRIu64"ms",
               db->file_name, xpnd_millis );

    TLOG_TRACE( "%d", FREQ_DB_SUCCESS );
    return FREQ_DB_SUCCESS;
  }


static int
file_append( freq_db_t *db,
             freq_type_t *type,
             const char *key, uint16_t key_sz,
             freq_record_t **record )
  {
    TLOG_TRACE( "%*s", key_sz, key );

    int res;
    freq_header_t hdr;
    memset( &hdr, 0, sizeof( freq_header_t ) );

    // Initialize the header 
    memcpy( &hdr, type, sizeof(freq_type_t) );
    hdr.status = FREQ_ACTIVE;
    hdr.key_sz = key_sz;
    hdr.data_sz = freq_get_data_sz( &hdr );
    hdr.key_hashcode = type_key_hash( type, key, key_sz );
    hdr.last_update_min = 0;

    uint64_t freq_sz = sizeof(freq_header_t) + hdr.key_sz + hdr.data_sz;

    off_t hdr_offset  = lseek( db->file_fd, 0, SEEK_CUR );
    off_t key_offset  = hdr_offset + sizeof(freq_header_t);
    off_t data_offset = key_offset + hdr.key_sz;

    // Sanity check
    if ( hdr_offset != db->file_hdr->eod )
      {
        TLOG_DEBUG( "current file offset is %d but should be %d",
                    hdr_offset, db->file_hdr->eod );
      }

    uint64_t file_free_sz = db->file_sz - db->file_hdr->eod;

    // DEBUG
    int resize_cnt = 0;

    // Grow the file until it's large enough to accomodate this
    // frequency.
    // TODO(joel): looping is inefficient, but it's unlikely that
    //             more than one resize would be required, unless
    //             you've got your incr_sz too small for the types
    //             of frequencies you're interested in storing.
    while ( file_free_sz < freq_sz )
      {
        res = file_expand( db );
        if ( res != FREQ_DB_SUCCESS )
          {
            ERR_RET( "%s - file_expand failed: %d", db->file_name, res );
            return res;
          }

        file_free_sz = db->file_sz - db->file_hdr->eod;
        resize_cnt++;
      }

    ssize_t write_sz;

    // Write freq_header_t
    write_sz = write( db->file_fd, &hdr, sizeof(freq_header_t) );
    if ( write_sz == -1 )
      {
        ERR_RET( "%s - write of freq_header_t failed: %d",
                 db->file_name, FREQ_DB_SYS_ERR_WRITE );
        return FREQ_DB_SYS_ERR_WRITE;
      }
    else if ( write_sz != sizeof(freq_header_t) )
      {
        ERR_RET( "%s - incomplete freq_header_t written (%ld of %ld bytes): %d",
                 db->file_name, write_sz, sizeof(freq_header_t), FREQ_DB_SYS_ERR_WRITE );
        return FREQ_DB_SYS_ERR_WRITE;
      }

    off_t _key_offset = lseek( db->file_fd, 0, SEEK_CUR );
    //TLOG_DEBUG( "writing key at offset %"PRIu64, _key_offset );
    (void)_key_offset;

    // Write key
    write_sz = write( db->file_fd, key, key_sz );
    if ( write_sz == -1 )
      {
        ERR_RET( "%s - write of key failed: %d",
                 db->file_name, FREQ_DB_SYS_ERR_WRITE );
        return FREQ_DB_SYS_ERR_WRITE;
      }
    else if ( write_sz != key_sz )
      {
        ERR_RET( "%s - incomplete key written (%ld of %ld bytes): %d",
                 write_sz, key_sz, FREQ_DB_SYS_ERR_WRITE );
        return FREQ_DB_SYS_ERR_WRITE;
      }

    // Write zeros for the data array
    uint64_t data_written = 0;
    while ( data_written < hdr.data_sz )
      {
        uint64_t to_write_sz = hdr.data_sz - data_written;
        if ( to_write_sz > BLOCK_SIZE )
          to_write_sz = BLOCK_SIZE;

        write_sz = write( db->file_fd, block, to_write_sz );
        if ( write_sz == -1 )
          {
            ERR_RET( "%s - write of data failed: %d",
                     db->file_name, FREQ_DB_SYS_ERR_WRITE );
            return FREQ_DB_SYS_ERR_WRITE;
          }
        else if ( write_sz != (ssize_t)to_write_sz )
          {
            ERR_RET( "%s - incomplete data written (%ld of %ld bytes): %d",
                     write_sz, to_write_sz );
            return FREQ_DB_SYS_ERR_WRITE;
          }

        data_written += write_sz;
      }

    // Update the file header
    db->file_hdr->eod = hdr_offset + freq_sz;

    // Another sanity check - C makes me paranoid
    off_t eod = lseek( db->file_fd, 0, SEEK_CUR );
    if ( eod != (off_t)( hdr_offset + freq_sz ) )
      {
        TLOG_DEBUG( "inconsistent eod calcs - lseek: %ld, hdr_offset + freq_sz: %ld",
                    eod, hdr_offset + freq_sz );
      }

    // Create the record for this freq
    res = freq_record_create( record, hdr_offset );
    if ( res != FREQ_DB_SUCCESS ) return res;

    //TLOG_DEBUG( "hdr_offset: %ld, data_offset: %ld", hdr_offset, data_offset );
    (void)data_offset;

    return FREQ_DB_SUCCESS;
  }


static void
file_lock( freq_db_t *db )
  {
    Pthread_mutex_lock( &db->file_lock );
  }


static void
file_unlock( freq_db_t *db )
  {
    Pthread_mutex_unlock( &db->file_lock );
  }


/******************************************************************************
 * hdr Functions                                                             *
 *****************************************************************************/

// Reads are dirty for now
static void
hdr_readlock( freq_db_t *db )
  {
    Pthread_rwlock_rdlock( &db->hdr_rwlock );
  }

static void
hdr_writelock( freq_db_t *db )
  {
    Pthread_rwlock_wrlock( &db->hdr_rwlock );
  }

static void
hdr_unlock( freq_db_t *db )
  {
    Pthread_rwlock_unlock( &db->hdr_rwlock );
  }


/******************************************************************************
 * mmap Functions                                                             *
 *****************************************************************************/

static void
mmap_readlock( freq_db_t *db )
  {
    Pthread_rwlock_rdlock( &db->mmap_rwlock );
  }

static void
mmap_writelock( freq_db_t *db )
  {
    Pthread_rwlock_wrlock( &db->mmap_rwlock );
  }

static void
mmap_unlock( freq_db_t *db )
  {
    Pthread_rwlock_unlock( &db->mmap_rwlock );
  }


/******************************************************************************
 * DB Functions (Private)                                                     *
 *****************************************************************************/

static int64_t
db_index_file( freq_db_t *db )
  {
    int res;

    uint64_t freqs_active_cnt = 0;
    uint64_t freqs_deleted_cnt = 0;

    off_t hdr_offset;   // File offset of freq_header_t
    off_t key_offset;   // File offset of key
    off_t data_offset;  // File offset of data
    off_t data_end;     // End of data (not end of file)
    off_t file_offset;  // Current offset in file

    ssize_t read_sz;
    freq_header_t hdr;
    freq_record_t *record;

    // First freq_header_t starts after file header
    hdr_offset = sizeof(freq_file_header_t);

    // Find out where data ends
    data_end = db->file_hdr->eod;

    // Iterate through file finding freqs
    while ( hdr_offset < data_end )
      {
        // Seek to the next header
        file_offset = lseek( db->file_fd, hdr_offset, SEEK_SET );
        if ( file_offset == -1 )
          {
            ERR_RET( "%s - header: lseek to %ld failed: %d",
                     db->file_name, hdr_offset, FREQ_DB_SYS_ERR_LSEEK );
            return FREQ_DB_SYS_ERR_LSEEK;
          }
        else if ( file_offset != hdr_offset )
          {
            ERR_RET( "%s - header: lseek to %ld returned %ld instead: %d",
                     db->file_name, hdr_offset, file_offset, FREQ_DB_SYS_ERR_LSEEK );
            return FREQ_DB_SYS_ERR_LSEEK;
          }

        // Read header so we can get key and data size
        read_sz = read( db->file_fd, &hdr, sizeof(freq_header_t) );
        if ( read_sz == -1 )
          {
            ERR_RET( "%s - header: read failed: %d",
                     db->file_name, FREQ_DB_SYS_ERR_READ );
            return FREQ_DB_SYS_ERR_READ;
          }
        else if ( read_sz != sizeof(freq_header_t) )
          {
            ERR_RET( "%s - header: read incomplete (%ld instead of %ld): %d",
                     db->file_name, read_sz, sizeof(freq_header_t), FREQ_DB_SYS_ERR_LSEEK );
            return FREQ_DB_SYS_ERR_READ;
          }

        key_offset = hdr_offset + sizeof(freq_header_t);
        data_offset = key_offset + hdr.key_sz;

        if ( freq_get_status( &hdr ) == FREQ_ACTIVE )
          {
            // Create record containing freq offsets
            res = freq_record_create( &record, hdr_offset );
            if ( res != FREQ_DB_SUCCESS )
              {
                ERR_RET( "%s - freq_record_create failed: %d",
                         db->file_name, res );
                return res;
              }

            // Store record in index
            res = idx_insert( db, record );
            if ( res != FREQ_DB_SUCCESS )
              {
                ERR_RET( "%s - idx_insert failed: %d",
                         db->file_name, res );
                return res;
              }

            freqs_active_cnt++;
          }
        else
          {
            freqs_deleted_cnt++;
          }

        hdr_offset = data_offset + hdr.data_sz;
      }

    // Sanity check
    if ( freqs_active_cnt != db->file_hdr->live_cnt )
      {
        TLOG_DEBUG( "%s - counted %ld active freqs but file header says %ld (fixing)",
                    db->file_name, freqs_active_cnt, db->file_hdr->live_cnt );
        db->file_hdr->live_cnt = freqs_active_cnt;
      }

    if ( freqs_deleted_cnt != db->file_hdr->del_cnt )
      {
        TLOG_DEBUG( "%s - counted %ld deleted freqs but file header says %ld (fixing)",
                    db->file_name, freqs_deleted_cnt, db->file_hdr->del_cnt );
        db->file_hdr->del_cnt = freqs_deleted_cnt;
      }

    return FREQ_DB_SUCCESS;
  }


static int
db_insert( freq_db_t *db,
           freq_type_t *type,
           const char *key, uint16_t key_sz,
           freq_record_t **record )
  {
    TLOG_TRACE( "%*s", key_sz, key );
    int res;
    file_lock( db );

    // Check if record was written before we acquired write lock
    idx_readlock( db );
    freq_record_t *rec = idx_find( db, type, key, key_sz );
    idx_unlock( db );

    if ( rec != NULL )
      {
        *record = rec;
        file_unlock( db );
        TLOG_TRACE( "record already inserted: %d", FREQ_DB_SUCCESS );
        return FREQ_DB_SUCCESS;
      }

    res = file_append( db, type, key, key_sz, record );
    if ( res != FREQ_DB_SUCCESS )
      {
        file_unlock( db );
        ERR_RET( "file_append failed: %d", res );
        return res;
      }

    // Acquire locks
		idx_writelock( db );
    mmap_readlock( db );

    int live_cnt = db->file_hdr->live_cnt;

    float idx_load_factor = live_cnt / (float)db->idx_sz;
    if ( idx_load_factor > 0.60 )
      {
        TLOG_INFO( "index load factor is %f, expanding index", idx_load_factor );
        res = idx_expand( db );

        if ( res != FREQ_DB_SUCCESS )
          {
            mmap_unlock( db );
            idx_unlock( db );
            file_unlock( db );
            ERR_RET( "idx_expand failed: %d", res );
            return res;
          }
      }

    res = idx_insert( db, *record );
    if ( res != FREQ_DB_SUCCESS )
      {
        mmap_unlock( db );
        idx_unlock( db );
        file_unlock( db );
        ERR_RET( "idx_insert failed: %d", res );
        return res;
      }

    mmap_unlock( db );
    idx_unlock( db );
    file_unlock( db );

    mmap_readlock( db );
    hdr_writelock( db );
    db->file_hdr->live_cnt++;
    hdr_unlock( db );
    mmap_unlock( db );
    TLOG_TRACE( "%d", FREQ_DB_SUCCESS );
    return FREQ_DB_SUCCESS;
  }

/******************************************************************************
 * DB Functions                                                               *
 *****************************************************************************/

int
freq_db_open( freq_db_t **fdb_ptrptr,
              const char * filename,
              int64_t incr_sz )
  {
    TLOG_TRACE( "filename: %s, incr_sz %"PRId64, filename, incr_sz );
    int new_file = 0;
    int res;

    // Allocate the structure for our db
    freq_db_t * fdb = malloc( sizeof(freq_db_t) );
    if ( fdb == NULL )
      {
        ERR_RET( "malloc of freq_db_t failed: %d", FREQ_DB_SYS_ERR_MALLOC );
        return FREQ_DB_SYS_ERR_MALLOC;
      }

    size_t filename_sz = strlen(filename);
    fdb->file_name = (char*)malloc( strlen(filename)+1 ); // hacky
    fdb->file_name[filename_sz] = '\0';
    memcpy( fdb->file_name, filename, filename_sz );
    Pthread_mutex_init( &fdb->file_lock, NULL );
    Pthread_rwlock_init( &fdb->iter_rwlock, NULL );
    Pthread_rwlock_init( &fdb->hdr_rwlock, NULL );
    Pthread_rwlock_init( &fdb->mmap_rwlock, NULL );
    Pthread_rwlock_init( &fdb->idx_rwlock, NULL );

    // Try to open file for reading and if that fails try to create it
    fdb->file_fd = open( filename, O_RDWR | O_EXCL );

    if ( fdb->file_fd == -1 )
      {
        fdb->file_fd = open( filename,
                             O_CREAT | O_RDWR | O_EXCL,
                             S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH );

        if ( fdb->file_fd == -1 )
          {
            ERR_RET( "could not create file: %d", FREQ_DB_SYS_ERR_OPEN );
            return FREQ_DB_SYS_ERR_OPEN;
          }

        int initialized = file_init( fdb->file_fd, incr_sz );
        if ( initialized != FREQ_DB_SUCCESS )
          {
            ERR_RET( "could not initialize file: %d", initialized );
            return initialized;
          }

        // Track that this is a new file
        new_file = 1;
      }

    // Get current file size
    fdb->file_sz = file_length( fdb->file_fd );

    // Memory map the file
    fdb->mmap = mmap( (caddr_t)0,
                      fdb->file_sz,
                      PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_SHARED,
                      fdb->file_fd,
                      0 );

    if ( fdb->mmap == MAP_FAILED )
      {
        ERR_RET( "mmap failed: %d", FREQ_DB_SYS_ERR_MMAP );
        return FREQ_DB_SYS_ERR_MMAP;
      }

#ifdef DEBUG
    file_print_header( stdout, fdb->file_hdr );
#endif

    res = idx_init( fdb );
    if ( res != FREQ_DB_SUCCESS )
      {
        ERR_RET( "idx_init failed: %d", res );
        return res;
      }

    res = db_index_file( fdb );
    if ( res != FREQ_DB_SUCCESS )
      {
        ERR_RET( "db_index_file failed: %d", res );
        return res;
      }

    *fdb_ptrptr = fdb;

    res = (new_file == 1) ? FREQ_DB_CREATED : FREQ_DB_SUCCESS;

    TLOG_TRACE( "%d", res );
    return res;
  }


int
freq_db_info( freq_db_t *db,
              freq_db_info_t *info )
  {
    TLOG_TRACE( "filename : %s", db->file_name );

    // zero out info struct
    memset( info, 0, sizeof(freq_db_info_t) );

    mmap_readlock( db );
    hdr_readlock( db );
    file_lock( db );

    info->active_freqs = db->file_hdr->live_cnt;
    info->deleted_freqs = db->file_hdr->del_cnt;
    info->increment_sz = db->file_hdr->incr_sz;
    info->disk_sz = db->file_hdr->eod;
    info->index_sz = db->idx_sz;

    file_unlock( db );
    hdr_unlock( db );
    mmap_unlock( db );

    return FREQ_DB_SUCCESS;
  }


int
freq_db_sync( freq_db_t *db )
  {
    TLOG_TRACE( "filename: %s", db->file_name );
    mmap_readlock( db );

    // Sync the file to disk
    int result = msync( db->mmap, db->file_sz, MS_SYNC | MS_INVALIDATE );
    if ( result == -1 )
      {
        mmap_unlock( db );
        ERR_RET( "msync failed: %d", result );
        return FREQ_DB_SYS_ERR_MSYNC;
      }

    mmap_unlock( db );

    TLOG_TRACE( "0", NULL );
    return FREQ_DB_SUCCESS;
  }


int
freq_db_gc( freq_db_t *db, freq_db_gc_stats_t *stats )
  {
    TLOG_TRACE( "%s - gc starting", db->file_name );
    TLOG_DEBUG( "%s - gc starting", db->file_name );
    TLOG_INFO( "%s - gc starting", db->file_name );

    // Get the iterator write lock
    TLOG_DEBUG( "%s - iter_writelock start", db->file_name );
    iter_writelock( db );
    TLOG_DEBUG( "%s - iter_writelock acquired", db->file_name );

    // Zero out stats memory
    memset( stats, 0, sizeof(freq_db_gc_stats_t) );
    stats->collected_freqs = 0;
    stats->collected_bytes = 0;

    off_t file_eod;        // End of data in the file
    freq_header_t* hdr;    // Pointer to current freq
    uint64_t freq_sz;      // Size of current freq
    off_t freq_offset;     // Offset of current freq 
    off_t free_offset;     // Offset of free space
    off_t last_offset = 0; // Offset of last freq

    // First freq starts after file header
    freq_offset = sizeof(freq_file_header_t);

    // No garbage to start with
    free_offset = -1;

    // Acquire readlock on the mmap region. Technically we do write to it,
    // but we lock at the freq level for any moves that occur.
    TLOG_DEBUG( "%s - mmap_readlock start", db->file_name );
    mmap_readlock( db );
    TLOG_DEBUG( "%s - mmap_readlock acquired", db->file_name );

    // Acquire file lock to check if we're at the end (this will block
    // other appends, which is what we want).
    TLOG_DEBUG( "file_lock start", NULL );
    file_lock( db );
    TLOG_DEBUG( "file_lock acquired", NULL );

    TLOG_DEBUG( "hdr_readlock start",  NULL );
    hdr_readlock( db );
    TLOG_DEBUG( "hdr_readlock acquired", NULL );

    TLOG_DEBUG( "%s - freq_offset: %ld db->file_hdr->eod: %ld\n",
                db->file_name, freq_offset, db->file_hdr->eod );

    file_eod = db->file_hdr->eod;

    while ( freq_offset < db->file_hdr->eod )
      {
        // Unlock the header
        hdr_unlock( db );
        TLOG_DEBUG( "hdr_readlock released", NULL );

        // Unlock the file so appends can continue
        file_unlock( db );
        TLOG_DEBUG( "file_lock released", NULL );

        // Get pointer to freq
        hdr = (freq_header_t*) (db->mmap + freq_offset);

        // Get size of freq
        freq_sz = freq_get_size( hdr );

        

        // DEBUG: freqs greater than 1MB are fish
        if ( freq_sz > 1048576 )
          {
            TLOG_INFO( "suspiciously large freq (%"PRIu64" bytes) "
                       "mins: %d bits: %d key: %*s: key_sz: %d "
                       "file offset: %"PRIu64" file end: %"PRIu64,
                       freq_sz,
                       ((freq_type_t*)hdr)->interval_cnt,
                       ((freq_type_t*)hdr)->interval_mins,
                       ((freq_type_t*)hdr)->interval_bits,
                       freq_get_key_sz( hdr ),
                       freq_get_key( hdr ),
                       freq_get_key_sz( hdr ),
                       freq_offset, file_eod );
          }

        // If it's stale, delete it
        if ( freq_is_stale( hdr ) )
          {
            TLOG_DEBUG( "delete stale freq start: %s", freq_get_key( hdr ) );
            freq_db_delete( db,
                            (freq_type_t*) hdr,
                            freq_get_key( hdr ),
                            freq_get_key_sz( hdr ) );
            TLOG_DEBUG( "delete stale freq completed", NULL );
          }

        // If deleted, do collection
        if ( freq_get_status( hdr ) == FREQ_DELETED )
          {
            // Increment stats
            stats->collected_freqs += 1;
            stats->collected_bytes += freq_sz;

            // Update compaction pointer if this is first freq collected
            if ( free_offset == -1 )
              {
                free_offset = freq_offset;
                TLOG_DEBUG( "free_offset set to %"PRIu64, freq_offset );
              }
          }
        else
          {
            last_offset = freq_offset;

            // Check if we need to compact this freq
            if ( free_offset >= 0 )
              {
                // Get the record so we can update it
                idx_readlock( db );
                freq_record_t *rec = idx_find( db,
                                               (freq_type_t*) hdr,
                                               freq_get_key( hdr ),
                                               freq_get_key_sz( hdr ) );
                idx_unlock( db );

                // If we didn't find the record we assume it's not in use
                // and collect it
                if ( rec == NULL )
                  {
                    TLOG_INFO( "unindexed freq collected cnt: %d "
                               "mins: %d bits: %d key: %*s: key_sz: %d "
                               "file offset: %ld file end: %ld",
                               ((freq_type_t*)hdr)->interval_cnt,
                               ((freq_type_t*)hdr)->interval_mins,
                               ((freq_type_t*)hdr)->interval_bits,
                               freq_get_key_sz( hdr ),
                               freq_get_key( hdr ),
                               freq_get_key_sz( hdr ),
                               freq_offset, db->file_hdr->eod );

                    stats->collected_freqs += 1;
                    stats->collected_bytes += freq_sz;

                    // Update compaction pointer if this is first freq collected
                    if ( free_offset == -1 )
                      {
                        free_offset = freq_offset;
                        TLOG_DEBUG( "free_offset set to %ld", freq_offset );
                      }
                  }
                else
                  { 
                    TLOG_DEBUG( "freq move starting", NULL );
                    TLOG_INFO( "freq move starting (from %"PRIu64
                               " to %"PRIu64")", freq_offset, free_offset );

                    // Lock the record so we can move it
                    freq_record_writelock( rec );
    
                    // Move the data around
                    uint64_t free_sz = freq_offset - free_offset;
                    if ( free_sz > freq_sz )
                      {
                        memcpy( db->mmap + free_offset,
                                db->mmap + freq_offset,
                                freq_sz );
                      }
                    else
                      {
                        memmove( db->mmap + free_offset,
                                 db->mmap + freq_offset,
                                 freq_sz );
                      }
    
                    // Update record
                    freq_record_move_to( rec, free_offset );

                    last_offset = free_offset;
    
                    // Unlock the record
                    freq_record_unlock( rec );

                    // Update free offset
                    free_offset += freq_sz;
    
                    TLOG_DEBUG( "freq move done", NULL );
                  }
              }
          }

        // Increment pointer to location of next freq
        freq_offset += freq_sz;

        // Acquire file lock for the check if we're at the end
        TLOG_DEBUG( "file_lock starting", NULL );
        file_lock( db );
        TLOG_DEBUG( "file_lock acquired", NULL );

        TLOG_DEBUG( "hdr_readlock start",  NULL );
        hdr_readlock( db );
        TLOG_DEBUG( "hdr_readlock acquired", NULL );

        TLOG_DEBUG( "last_offset: %"PRIu64" freq_offset: %"PRIu64
                    " db->file_hdr->eod: %"PRIu64,
                    last_offset, freq_offset, db->file_hdr->eod );
      }

    // When loop exits we're at the end of the data and we have
    // the file lock. Now update EOD if we compacted.
    if ( free_offset > 0 )
      {
        db->file_hdr->eod = free_offset;
        db->file_hdr->del_cnt -= stats->collected_freqs;
        lseek( db->file_fd, free_offset, SEEK_SET );
        TLOG_DEBUG( "file_hdr stats updated", NULL );
      }

    TLOG_INFO( "gc stats: freqs: %"PRIu64" bytes: %"PRIu64,
               stats->collected_freqs, stats->collected_bytes );

    // Release locks
    hdr_unlock( db );
    TLOG_DEBUG( "hdr_readlock released", NULL );
    file_unlock( db );
    TLOG_DEBUG( "file_lock released", NULL );
    mmap_unlock( db );
    TLOG_DEBUG( "mmap_readlock released", NULL );
    iter_unlock( db );
    TLOG_DEBUG( "iter_lock released", NULL );

    TLOG_DEBUG( "%d", FREQ_DB_SUCCESS );
    TLOG_TRACE( "%d", FREQ_DB_SUCCESS );
    return FREQ_DB_SUCCESS;
  }


int
freq_db_close( freq_db_t *db )
  {
    TLOG_TRACE( "%s", db->file_name );

    // Acquire all locks so no one else tries to access this guy
    file_lock( db );
    mmap_writelock( db );
    idx_writelock( db );

    // Sync the file to disk
    int result = msync( db->mmap, db->file_sz, MS_SYNC | MS_INVALIDATE );
    if ( result == -1 )
      ERR_RET( "%s - msync failed: %d", db->file_name, result );

    result = munmap( db->mmap, db->file_sz );
    if ( result == -1 )
      ERR_RET( "%s - munmap failed: %d", db->file_name, result );

    result = close( db->file_fd );
    if ( result == -1 )
      ERR_RET( "%s - close failed: %d", db->file_name, result );

    // Destroy the index
    idx_destroy( db );

    file_unlock( db );
    mmap_unlock( db );
    idx_unlock( db );

    pthread_rwlock_destroy( &db->idx_rwlock );
    pthread_rwlock_destroy( &db->mmap_rwlock );
    pthread_mutex_destroy( &db->file_lock );

    TLOG_TRACE( "%s - %d", db->file_name, result );

    free( db->file_name );
    free( db );

    return result;
  }


int
freq_db_increment( freq_db_t *db,
                   freq_type_t *type,
                   const char *key,
                   uint16_t key_sz,
                   uint32_t offset_minutes )
  {
    TLOG_TRACE( "%s - cnt: %d mins: %d bits: %d key: %*s: key_sz: %d offset_mins: %d",
                db->file_name,
                type->interval_cnt, type->interval_mins, type->interval_bits,
                key_sz, key, key_sz,
                offset_minutes );

    // Make sure the type is valid
    if ( type->interval_cnt == 0  ||
         type->interval_mins == 0 ||
         type->interval_bits == 0 )
      {
        TLOG_TRACE( "invalid type: %d", FREQ_DB_INVALID_TYPE );
        return FREQ_DB_INVALID_TYPE;
      }

    // Make sure the key is valid
    if ( key_sz == 0 || key == NULL )
      {
        TLOG_TRACE( "empty key: %d", FREQ_DB_EMPTY_KEY );
        return FREQ_DB_EMPTY_KEY;
      }

    int new_record = 0;
    int res;

    idx_readlock( db );
    freq_record_t * record = idx_find( db, type, key, key_sz );
    idx_unlock( db );

    if ( record == NULL )
      {
        res = db_insert( db, type, key, key_sz, &record );
        if ( res != FREQ_DB_SUCCESS )
          {
            ERR_RET( "db_insert failed: %d", res );
            return res;
          }
        new_record = 1;
      }

    mmap_readlock( db );
    freq_header_t *hdr = freq_record_header( db->mmap, record );

    freq_record_writelock( record );
    res = freq_increment( hdr, offset_minutes );
    freq_record_unlock( record );
    mmap_unlock( db );

    if ( new_record == 1 && res == FREQ_DB_SUCCESS ) res = FREQ_DB_CREATED;

    TLOG_TRACE( "%d", res );
    return res;
  }


int
freq_db_count( freq_db_t *db,
               freq_type_t *type,
               const char *key, uint16_t key_sz,
               uint32_t minutes, uint32_t offset_minutes,
               freq_count_t *count )
  {
    TLOG_TRACE( "%s - cnt: %d mins: %d bits: %d key: %*s: key_sz: %d "
                "mins: %d offset_mins: %d",
                db->file_name,
                type->interval_cnt, type->interval_mins, type->interval_bits,
                key_sz, key, key_sz,
                minutes, offset_minutes );

    idx_readlock( db );
    freq_record_t * record = idx_find( db, type, key, key_sz );
    idx_unlock( db );

    if ( record == NULL )
      {
        TLOG_TRACE( "not found: %d", FREQ_DB_NOTFOUND );
        return FREQ_DB_NOTFOUND;
      }

    mmap_readlock( db );
    freq_header_t *hdr = freq_record_header( db->mmap, record );

    freq_record_readlock( record );
    int res = freq_count( hdr, minutes, offset_minutes, count );
    freq_record_unlock( record );
    mmap_unlock( db );

    TLOG_TRACE( "%d", res );
    return res;
  }


int
freq_db_delete( freq_db_t *db,
                freq_type_t *type,
                const char *key, uint16_t key_sz )
  {
    TLOG_TRACE( "%s - cnt: %d mins: %d bits: %d key: %*s: key_sz: %d "
                "mins: %d offset_mins: %d",
                db->file_name,
                type->interval_cnt, type->interval_mins, type->interval_bits,
                key_sz, key, key_sz );

    freq_record_t *record = NULL;

    // Lock the index and try to remove the entry from it
    idx_writelock( db );
    idx_remove( db, type, key, key_sz, &record );
    idx_unlock( db );

    // If the record wasn't found we're done
    if ( record == NULL )
      {
        TLOG_TRACE( "not found: %d", FREQ_DB_NOTFOUND );
        return FREQ_DB_NOTFOUND;
      }

    // Lock the record and mark it as deleted
    freq_record_writelock( record );
    mmap_readlock( db );
    freq_header_t *hdr = freq_record_header( db->mmap, record );
    freq_set_status( hdr, FREQ_DELETED );
    mmap_unlock( db );
    freq_record_unlock( record );

    // Lock the mmap and update the file header
    mmap_readlock( db );
    hdr_writelock( db );
    db->file_hdr->live_cnt--;
    db->file_hdr->del_cnt++;
    hdr_unlock( db );
    mmap_unlock( db );

    // Free the memory allocated for the record
    freq_record_destroy( record );

    TLOG_TRACE( "%d", FREQ_DB_SUCCESS );
    return FREQ_DB_SUCCESS;
  }

int
freq_db_get_binary( freq_db_t *db,
                    freq_type_t *type,
                    const char *key, uint16_t key_sz,
                    char *binary_buff, uint64_t binary_buff_sz,
                    uint64_t *binary_sz )
  {
    idx_readlock( db );
    freq_record_t *record = idx_find( db, type, key, key_sz );
    idx_unlock( db );

    if ( record == NULL ) return FREQ_DB_NOTFOUND;

    mmap_readlock( db );
    freq_record_readlock( record );
    freq_header_t *hdr = freq_record_header( db->mmap, record );

    // Get the size of the binary representation
    *binary_sz = freq_get_size( hdr );

    int res;
    if ( *binary_sz > binary_buff_sz )
      {
        res = FREQ_DB_BUFF_TOO_SMALL;
      }
    else
      {
        memcpy( binary_buff, (char*)hdr, *binary_sz );
        res = FREQ_DB_SUCCESS;
      }

    freq_record_unlock( record );
    mmap_unlock( db );

    return res;
  }

int
freq_db_put_binary( freq_db_t *db,
                    const char *binary, uint64_t binary_sz,
                    int op_if_present )
  {
    // Make sure op_if_present is valid
    if ( op_if_present != FREQ_DB_PUT_MERGE &&
         op_if_present != FREQ_DB_PUT_OVERWRITE &&
         op_if_present != FREQ_DB_PUT_DONTPUT )
      {
        return FREQ_DB_INVALID_OP;
      } 

    freq_header_t *hdr = (freq_header_t*)binary;

    freq_type_t *type = (freq_type_t*)hdr;
    const char *key = freq_get_key( hdr );
    uint16_t key_sz = freq_get_key_sz( hdr );
    uint64_t freq_sz = freq_get_size( hdr );

    if ( freq_sz != binary_sz )
      {
        return FREQ_DB_INVALID_BINARY;
      }

    idx_readlock( db );
    freq_record_t *record = idx_find( db, type, key, key_sz );
    idx_unlock( db );

    // Easy case - don't do anything
    if ( record != NULL && FREQ_DB_PUT_DONTPUT == op_if_present )
      {
        return FREQ_DB_SUCCESS;
      }

    int res;
    int new = 0;

    if ( record == NULL )
      {
        res = db_insert( db, type, key, key_sz, &record );
        if ( res != FREQ_DB_SUCCESS ) return res;
        new = 1;
      }

    freq_record_writelock( record );
    mmap_readlock( db );
    freq_header_t *prev_hdr = freq_record_header( db->mmap, record );

    // Do merge or copy over new data
    if ( !new && FREQ_DB_PUT_MERGE == op_if_present )
      {
        res = freq_merge( prev_hdr, hdr );
      }
    else
      {
        // sanity check
        assert( freq_get_size( prev_hdr ) == binary_sz );

        memcpy( prev_hdr, hdr, binary_sz );
        res = FREQ_DB_SUCCESS;
      }

    mmap_unlock( db );
    freq_record_unlock( record );

    return res;
  }

int
freq_db_iter_init( freq_db_t *db,
                   freq_db_iter_t **iter_ptrptr )
  {
    int res = FREQ_DB_SUCCESS;

    TLOG_DEBUG( "iter_init started", NULL );

    // Allocate the structure for our db
    freq_db_iter_t * iter = malloc( sizeof(freq_db_iter_t) );
    if ( iter == NULL )
      {
        ERR_RET( "malloc of freq_db_iter_t failed", NULL );
        return FREQ_DB_SYS_ERR_MALLOC;
      }

    // Zero out the iter struct
    memset( iter, 0, sizeof(freq_db_iter_t) );

    // Get a read lock for iterating
    iter_readlock( db );
    iter->db     = db;
    iter->state  = FREQ_DB_ITER_ACTIVE;
    iter->offset = sizeof(freq_file_header_t);  // First freq is after the file header

    // Lock the file and check EOF
    file_lock( iter->db );
    hdr_readlock( iter->db );
    if ( iter->offset == iter->db->file_hdr->eod ) res = FREQ_DB_ITER_EOF;
    hdr_unlock( iter->db );
    file_unlock( iter->db );

    // If not EOF, find first valid freq
    if ( res != FREQ_DB_ITER_EOF )
      {
        // Lock mmap region so we can read header info
        mmap_readlock( iter->db );
        freq_header_t *hdr = (freq_header_t*) (iter->db->mmap + iter->offset);

        // If the current freq is deleted or stale, move to the next
        if ( freq_is_stale( hdr ) || freq_get_status( hdr ) == FREQ_DELETED )
          {
            mmap_unlock( iter->db );
            res = freq_db_iter_next( iter );
          }
        else
          {
            mmap_unlock( iter->db );
          }
      }

    *iter_ptrptr = iter;

    return res;
  }

int
freq_db_iter_next( freq_db_iter_t *iter )
  {
    if ( iter == NULL ) return FREQ_DB_ITER_INACTIVE;
    if ( iter->state != FREQ_DB_ITER_ACTIVE) return iter->state;

    // Lock mmap region so we can read header info
    mmap_readlock( iter->db );

    freq_header_t *hdr;
    uint64_t freq_sz;

    int res = FREQ_DB_SUCCESS;
    while ( 1 )
      {
        // Get ptr to current freq
        hdr = (freq_header_t*) (iter->db->mmap + iter->offset);

        // Get size of current freq
        freq_sz = freq_get_size( hdr );

        // Move offset to next freq
        iter->offset += freq_sz;

        // Lock file and check EOF
        file_lock( iter->db );
        hdr_readlock( iter->db );
        if ( iter->offset == iter->db->file_hdr->eod ) res = FREQ_DB_ITER_EOF;
        hdr_unlock( iter->db );
        file_unlock( iter->db );
        if ( res != FREQ_DB_SUCCESS ) break;

        // Get ptr to next freq
        hdr = (freq_header_t*) (iter->db->mmap + iter->offset);

        // If the current freq is not deleted or stale, we're done
        if ( !freq_is_stale( hdr ) && freq_get_status( hdr ) != FREQ_DELETED )
          {
            break;
          }
      }

    mmap_unlock( iter->db );

    return res;
  }

int
freq_db_iter_done( freq_db_iter_t **iter )
  {
    if ( *iter == NULL ) return FREQ_DB_ITER_INACTIVE;

    iter_unlock( (*iter)->db );

    free( *iter );
    *iter = NULL;

    return FREQ_DB_SUCCESS;
  }

int
freq_db_iter_read( freq_db_iter_t *iter,
                   freq_type_t *type,
                   char *key_buff, uint16_t key_buff_sz,
                   uint16_t *key_sz )
  {
    if ( iter == NULL ) return FREQ_DB_ITER_INACTIVE;
    if ( iter->state != FREQ_DB_ITER_ACTIVE ) return iter->state;

    mmap_readlock( iter->db );

    freq_header_t *hdr = (freq_header_t*) (iter->db->mmap + iter->offset);

    // Copy the freq_type
    memcpy( type, hdr, sizeof(freq_type_t ));

    // Set the key size
    *key_sz = freq_get_key_sz( hdr );

    // Check if the buffer can hold the key and copy if so
    int res;
    if ( *key_sz >= key_buff_sz )
      {
        res = FREQ_DB_BUFF_TOO_SMALL;
      }
    else
      {
        const char * key = freq_get_key( hdr );
        memcpy( key_buff, key, *key_sz );
        key_buff[*key_sz] = '\0';
        res = FREQ_DB_SUCCESS;
      }

    mmap_unlock( iter->db );
    return res;
  }

