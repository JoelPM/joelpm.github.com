#include <inttypes.h>
#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <time.h>
#include "error.h"

/* Set nonzero by daemon_init() */
int daemon_proc;

#define MAXLINE 2047

static void
err_exec( int errnoflag, int level,
          const char *fnc, const char *fmt, va_list ap );

void
err_dump( const char *fnc, const char *fmt, ... )
  {
    va_list ap;

    va_start(ap, fmt);
    err_exec(1, LOG_ERR, fnc, fmt, ap);
    va_end(ap);

    abort();  // Dump core and exit
  }

void
err_ret( const char *fnc, const char *fmt, ... )
  {
    va_list ap;

    va_start(ap, fmt);
    err_exec(0, LOG_INFO, fnc, fmt, ap);
    va_end(ap);
  }

void
err_msg( const char *fnc, const char *fmt, ... )
  {
    va_list ap;

    va_start(ap, fmt);
    err_exec(0, LOG_INFO, fnc, fmt, ap);
    va_end(ap);
  }

void
err_quit( const char *fnc, const char *fmt, ... )
  {
    va_list ap;

    va_start(ap, fmt);
    err_exec(0, LOG_ERR, fnc, fmt, ap);
    va_end(ap);
    exit(1);
  }

void
err_sys( const char *fnc, const char *fmt, ... )
  {
    va_list ap;

    va_start(ap, fmt);
    err_exec(1, LOG_ERR, fnc, fmt, ap);
    va_end(ap);
    exit(1);
  }

static void
err_exec( int errnoflag, int level, 
          const char *fnc, const char *fmt, va_list ap )
  {
    int errno_save;
    char buf[MAXLINE + 1];

    errno_save = errno;

    time_t now = time( NULL );
    size_t n = strftime( buf,
                         MAXLINE,
                         "%m/%d/%Y %H:%M:%S ",
                         localtime(&now) );

    pthread_t tid = pthread_self();
    n += snprintf( buf + n, MAXLINE - n, "[%"PRIu64"] %s: ", (uint64_t)tid, fnc );
 
    n += vsnprintf( buf + n, MAXLINE, fmt, ap );

    if ( errnoflag )
      snprintf( buf + n, MAXLINE - n, ": %s", strerror(errno_save) );
 
    strcat( buf, "\n" );

    fflush( stdout );
    fputs( buf, stderr );
    fflush( stderr );

    if ( daemon_proc )
      {
        syslog( level, "%s", buf );
      }

    return;
  }
