#include <errno.h>
#include "pthreadwrappers.h"
#include "error.h"

void Pthread_mutex_init( pthread_mutex_t *mptr, const pthread_mutexattr_t *attrptr )
  {
    int n;
    if ( ( n = pthread_mutex_init(mptr, attrptr) ) == 0) return;

    errno = n;
    err_sys( __func__, "pthread_mutex_init error" );
  }


void Pthread_mutex_lock( pthread_mutex_t *mptr )
  {
    int n;
    if ( ( n = pthread_mutex_lock(mptr) ) == 0 ) return;

    errno = n;
    err_sys( __func__, "pthread_mutex_lock error" );
  }


void Pthread_mutex_unlock( pthread_mutex_t *mptr )
  {
    int n;
    if ( ( n = pthread_mutex_unlock(mptr) ) == 0 ) return;

    errno = n;
    err_sys( __func__, "pthread_mutex_unlock error" );
  }

void Pthread_rwlock_init( pthread_rwlock_t *lptr, const pthread_rwlockattr_t * attrptr )
  {
    int n;
    if ( ( n = pthread_rwlock_init( lptr, attrptr ) ) == 0 ) return;

    errno = n;
    err_sys( __func__, "pthread_rwlock_init error" );
  }

void Pthread_rwlock_destroy( pthread_rwlock_t *lptr )
  {
    int n;
    if ( ( n = pthread_rwlock_destroy( lptr ) ) == 0 ) return;

    errno = n;
    err_sys( __func__, "pthread_rwlock_destroy error" );
  }

void Pthread_rwlock_rdlock( pthread_rwlock_t *lptr )
  {
    int n;
    if ( ( n = pthread_rwlock_rdlock( lptr ) ) == 0) return;

    errno = n;
    err_sys( __func__, "pthread_rwlock_rdlock error" );
  }

void Pthread_rwlock_wrlock( pthread_rwlock_t *lptr )
  {
    int n;
    if ( ( n = pthread_rwlock_wrlock( lptr ) ) == 0 ) return;

    errno = n;
    err_sys( __func__, "pthread_rwlock_wrlock error" );
  }

void Pthread_rwlock_unlock( pthread_rwlock_t *lptr )
  {
    int n;
    if ( ( n = pthread_rwlock_unlock( lptr ) ) == 0 ) return;

    errno = n;
    err_sys( __func__, "pthread_rwlock_unlock error" );
  }
