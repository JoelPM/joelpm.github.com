#ifndef __FREQ_RECORD_H
#define __FREQ_RECORD_H

#include <sys/types.h>
#include <freq.h>

#include "freq_db_err.h"

typedef struct freq_record freq_record_t;

int
freq_record_create( freq_record_t **record,
                    off_t hdr_offset );

void
freq_record_destroy( freq_record_t* record );

void
freq_record_readlock( freq_record_t* record );

void
freq_record_writelock( freq_record_t* record );

void
freq_record_unlock( freq_record_t* record );

void
freq_record_move_to( freq_record_t* record,
                     off_t new_hdr_offset );

freq_header_t *
freq_record_header( const char *base, freq_record_t *record );

#endif /* __FREQ_RECORD_H */
