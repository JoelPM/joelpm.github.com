#ifndef __FREQ_DB_ERR_H
#define __FREQ_DB_ERR_H

#define FREQ_DB_ERR_IDX_COLLISIONS -20

#define FREQ_DB_EMPTY_KEY          -18
#define FREQ_DB_INVALID_BINARY     -17
#define FREQ_DB_INCOMPATIBLE       -16
#define FREQ_DB_INVALID_OP         -15
#define FREQ_DB_BUFF_TOO_SMALL     -14
#define FREQ_DB_INVALID_TYPE       -13
#define FREQ_DB_OFFSET_EXPIRED     -12
#define FREQ_DB_OVERFLOW           -11
#define FREQ_DB_NOTFOUND           -10

#define FREQ_DB_SYS_ERR_CLOSE       -9
#define FREQ_DB_SYS_ERR_OPEN        -8
#define FREQ_DB_SYS_ERR_FTRUNCATE   -7
#define FREQ_DB_SYS_ERR_LSEEK       -6
#define FREQ_DB_SYS_ERR_READ        -5
#define FREQ_DB_SYS_ERR_WRITE       -4
#define FREQ_DB_SYS_ERR_MSYNC       -3
#define FREQ_DB_SYS_ERR_MMAP        -2
#define FREQ_DB_SYS_ERR_MALLOC      -1

#define FREQ_DB_SUCCESS              0

#define FREQ_DB_CREATED              1

#define FREQ_DB_ITER_ACTIVE          2
#define FREQ_DB_ITER_INACTIVE        3
#define FREQ_DB_ITER_EOF             4

#endif /* __FREQ_DB_ERR_H */
