#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include "freq_db.h"
#include "freq.h"		
#include "record_index.h"
#include "error.h"
#include "pthreadwrappers.h"
#include "lookup3.h"
#include "tlog.h"

#define VERSION_NUM 0                  // hdr->version number supported
                                       // check done in db_open..

#define BLOCK_SIZE 512

#define DEBUG
#define SCRUB_ON_OPEN                  // cleans incomplete freqs upon db_open
#define MAX_IDX_LOAD 0.8               // collisions not as expensive now
#define MIN_IDX_LOAD 0.2               // protect against pathological hashing
 
/******************************************************************************
 * IMPLEMENTATION NOTES:
 *  Lock Policy:  locks should be acquired in the following order
 *    1)  file_lock
 *    2)  idx_readlock, idx_writelock
 *    3)  mmap_readlock, mmap_writelock
 *    4)  record_readlock, record_writelock
 *    5)  hdr_readlock, hdr_writelock
 *****************************************************************************/

static uint64_t INITIAL_INDEX_CAPACITY = 131072;

typedef struct freq_file_header {
  uint32_t version;   /* Version of the stored data. */
  uint64_t live_cnt;  /* Number of active Freqs. */
  uint64_t del_cnt;   /* Number of deleted Freqs. */
  off_t    eod;       /* End of data. */
  uint64_t unused;    /* Size of blocks to grow file. */
} freq_file_header_t;

struct freq_db {
  char                *file_name;
  uint64_t             incr_sz;             /* size in bytes to grow file */
  uint64_t             file_sz;
  int                  file_fd;
  pthread_mutex_t      file_lock;

  pthread_rwlock_t     iter_rwlock;
  pthread_rwlock_t     hdr_rwlock;
  pthread_rwlock_t     mmap_rwlock;
  union {
    char               *mmap;
    freq_file_header_t *file_hdr;
  };

  pthread_rwlock_t     idx_rwlock;
  index_t              *index;
};

struct freq_db_iter {
  freq_db_t  *db;
  int        state;
  off_t      offset;
};

/******************************************************************************
 * Iterator Functions                                                         *
 *****************************************************************************/

static void
iter_readlock( freq_db_t *fdb );

static void
iter_writelock( freq_db_t *fdb );

static void
iter_unlock( freq_db_t *fdb );


/******************************************************************************
 * Index Functions                                                            *
 *****************************************************************************/

static void
idx_readlock( freq_db_t *fdb );

static void
idx_writelock( freq_db_t *fdb );

static void
idx_unlock( freq_db_t *fdb );

/******************************************************************************
 * File Functions                                                             *
 *****************************************************************************/

#ifdef DEBUG
static void
file_print_header( FILE* out, freq_file_header_t *file_hdr );
#endif

static off_t
file_length( int fd );

static int
file_init( int fd, uint64_t incr_size );

static int
file_expand( freq_db_t *db );

static int
file_append( freq_db_t *db,
             freq_type_t *type,
             const char *key, uint16_t key_sz,
             off_t *hdr_offset );

static void
file_lock( freq_db_t *db );

static void
file_unlock( freq_db_t *db );


/******************************************************************************
 * hdr Functions                                                             *
 *****************************************************************************/

// Reads are dirty for now
static void
hdr_readlock( freq_db_t *db );

static void
hdr_writelock( freq_db_t *db );

static void
hdr_unlock( freq_db_t *db );


/******************************************************************************
 * mmap Functions                                                             *
 *****************************************************************************/

static void
mmap_readlock( freq_db_t *db );

static void
mmap_writelock( freq_db_t *db );

static void
mmap_unlock( freq_db_t *db );


/******************************************************************************
 * File Functions                                                             *
 *****************************************************************************/

static int64_t
db_index_file( freq_db_t *db );

static int
db_insert( freq_db_t *db,
           freq_type_t *type,
           const char *key, uint16_t key_sz );

/******************************************************************************
 * Iterator Functions                                                         *
 *****************************************************************************/

static void
iter_readlock( freq_db_t *db )
  {
    Pthread_rwlock_rdlock( &db->iter_rwlock );
  }


static void
iter_writelock( freq_db_t *db )
  {
    Pthread_rwlock_wrlock( &db->iter_rwlock );
  }


static void
iter_unlock( freq_db_t *db )
  {
    Pthread_rwlock_unlock( &db->iter_rwlock );
  }

/******************************************************************************
 * Index Functions                                                            *
 *****************************************************************************/
static void
idx_readlock( freq_db_t *db )
  {
    Pthread_rwlock_rdlock( &db->idx_rwlock );
  }


static void
idx_writelock( freq_db_t *db )
  {
    Pthread_rwlock_wrlock( &db->idx_rwlock );
  }


static void
idx_unlock( freq_db_t *db )
  {
    Pthread_rwlock_unlock( &db->idx_rwlock );
  }

/******************************************************************************
 * File Functions                                                             *
 *****************************************************************************/

#ifdef DEBUG
static void
file_print_header( FILE* out, freq_file_header_t *file_hdr )
  {
    fprintf( out, "freq_file_header->version:  %d\r\n",        file_hdr->version  );
    fprintf( out, "freq_file_header->live_cnt: %"PRIu64"\r\n", file_hdr->live_cnt );
    fprintf( out, "freq_file_header->del_cnt:  %"PRIu64"\r\n", file_hdr->del_cnt  );
    fprintf( out, "freq_file_header->eod:      %"PRIu64"\r\n", (uint64_t)file_hdr->eod      );
  }
#endif

static off_t
file_length( int fd )
{
  off_t end_offset; 
  struct stat stats;
  int retCode = fstat( fd, &stats );
  
  if ( retCode == 0 ) {
    end_offset = stats.st_size;
  } else {                                     // do it old way with lseek
    TLOG_INFO("WARNING: fstat failed: %u", retCode);
 
    off_t orig_offset = lseek( fd, 0, SEEK_CUR );
    if ( orig_offset == -1 ) {
      ERR_RET( "unable to get current file offset", NULL );
    }

    TLOG_DEBUG( "orig_offset: %ld", orig_offset );
 
    end_offset = lseek( fd, 0, SEEK_END );

    TLOG_DEBUG( "filelength: %ld", end_offset );

    off_t off;
    if ( orig_offset >= 0 ) {
      if ( ( off = lseek( fd, orig_offset, SEEK_SET ) ) != orig_offset ) {
        ERR_RET( "unable to restore original file offset (%ld instead of %ld)",
                 off, orig_offset );
      }
    }
  }   
   
  return end_offset;
}


static int
file_init( int fd, uint64_t incr_size )
  {
    int trnc_res = ftruncate( fd, incr_size );
    if ( trnc_res != 0 )
      {
        ERR_RET( "ftruncate to %ld failed", incr_size );
        return FREQ_DB_SYS_ERR_FTRUNCATE;
      }

    size_t file_hdr_sz = sizeof(freq_file_header_t);

    freq_file_header_t file_hdr;
    memset( &file_hdr, 0, sizeof( file_hdr ) );
    file_hdr.version = VERSION_NUM;
    file_hdr.live_cnt = 0;
    file_hdr.del_cnt = 0;
    file_hdr.eod = file_hdr_sz;
    file_hdr.unused = 0;

    ssize_t write_sz = write( fd, &file_hdr, file_hdr_sz );
    if ( write_sz == -1 )
      {
        ERR_RET( "write of freq_file_header_t failed", NULL );
        return FREQ_DB_SYS_ERR_WRITE;
      }
    else if ( (size_t)write_sz != file_hdr_sz )
      {
        ERR_RET( "write of freq_file_header_t incomplete " 
                 " (%ld of %ld bytes)", write_sz, file_hdr_sz );
        return FREQ_DB_SYS_ERR_WRITE;
      }

    return FREQ_DB_SUCCESS;
  }


static int
file_expand( freq_db_t *db )
  {
    TLOG_DEBUG( "beginning file_expand", NULL );
    struct timeval xpnd_start, xpnd_end;
    gettimeofday( &xpnd_start, NULL );

    uint64_t file_old_sz = db->file_sz;
    uint64_t file_new_sz = file_old_sz + db->incr_sz;

    // Increase the file size
    int rsz_res = ftruncate( db->file_fd, file_new_sz );

    if ( rsz_res == -1 )
      {
        ERR_RET( "attempt to expand DB file from %ld to %ld bytes failed",
                 file_old_sz, file_new_sz );
        return FREQ_DB_SYS_ERR_FTRUNCATE;
      }

    // lock mmap for writing
    mmap_writelock( db );

    // Sync mmap before unmapping
    int sync_res = msync( db->mmap, file_old_sz, MS_SYNC );

    if ( sync_res != 0 )
      ERR_RET( "%s - syncing file to disk failed - data may be lost", db->file_name );

    // Remap file so new range is covered
    int unmap_res = munmap( db->mmap, file_old_sz );
    if ( unmap_res != 0 )
      ERR_RET( "%s - munmap failed (ignored)", db->file_name );

    // Set new file size
    db->file_sz = file_new_sz;

    // Memory map the expanded file
    db->mmap = mmap( (caddr_t)0,
                          db->file_sz,
                          PROT_READ | PROT_WRITE | PROT_EXEC,
                          MAP_SHARED,
                          db->file_fd, 
                          0 );
    int saved_err = errno;
    TLOG_DEBUG( "mmap completed: %s", strerror( saved_err ) );

    // Unlock mmap
    mmap_unlock( db );

    if ( db->mmap == MAP_FAILED )
      {
        TLOG_DEBUG( "mmap failed, halting", NULL );
        ERR_QUIT( "mmap failed, halting", NULL );
      }

    gettimeofday( &xpnd_end, NULL );

    uint64_t xpnd_start_millis = ((uint64_t)xpnd_start.tv_sec) * ((uint64_t)1000)
                               + ((uint64_t)(xpnd_start.tv_usec/1000));
    uint64_t xpnd_end_millis = ((uint64_t)xpnd_end.tv_sec) * ((uint64_t)1000)
                             + ((uint64_t)(xpnd_end.tv_usec/1000));
    uint64_t xpnd_millis = xpnd_end_millis - xpnd_start_millis;

    TLOG_INFO( "%s - file expand took %"PRIu64"ms and grew %lu bytes",	
               db->file_name, xpnd_millis, db->incr_sz);

    TLOG_TRACE( "%d", FREQ_DB_SUCCESS );
    return FREQ_DB_SUCCESS;
  }

/******************************************************************************
 * FILE_APPEND 
 *  INPUTS: db - pointer to db struct
 *          type - the type infor for freq you're inserting (appending)
 *          key - the key of the freq you're inserting (appending)
 *          key_sz - num chars (not including null term) for key
 *          return_hdr_offset* - pointer to place to put offset on return
 *  OUTPUT: FREQ_DB_SUCCESS or FREQ_DB_NOT_FOUND 
 *  SIDE EFFECTS: the file offset is written to address of return_hdr_offset* 
 *  LOCKS:  assumes file_lock and idx_writelock acquired 
 *****************************************************************************/
static int
file_append( freq_db_t *db,
             freq_type_t *type,
             const char *key, uint16_t key_sz,
             off_t *return_hdr_offset )
  {
    TLOG_TRACE( "%*s", key_sz, key );

    int res;
    freq_header_t hdr;
    memset( &hdr, 0, sizeof( freq_header_t ) );

    // Initialize the header 
    memcpy( &hdr, type, sizeof(freq_type_t) );
    hdr.status = FREQ_ACTIVE;
    hdr.key_sz = key_sz;
    hdr.data_sz = freq_get_data_sz( &hdr );
    hdr.key_hashcode = type_key_hash( type, key, key_sz );
    hdr.last_update_min = MINUTES( time( NULL ) );    // time of creation

    uint64_t freq_sz = sizeof(freq_header_t) + hdr.key_sz + hdr.data_sz;

    off_t hdr_offset  = db->file_hdr->eod;;
    off_t key_offset  = hdr_offset + sizeof(freq_header_t);
    off_t data_offset = key_offset + hdr.key_sz;

    uint64_t file_free_sz = db->file_sz - db->file_hdr->eod;

    // DEBUG
    int resize_cnt = 0;

    // Grow the file until it's large enough to accomodate this
    // frequency.
    // TODO(joel): looping is inefficient, but it's unlikely that
    //             more than one resize would be required, unless
    //             you've got your incr_sz too small for the types
    //             of frequencies you're interested in storing.
    while ( file_free_sz < freq_sz ) {
        res = file_expand( db );
        if ( res != FREQ_DB_SUCCESS ) {
            ERR_RET( "%s - file_expand failed: %d", db->file_name, res );
            return res;
        }

        file_free_sz = db->file_sz - db->file_hdr->eod;
        resize_cnt++;
    }

    // Write freq_header_t
    memcpy( db->mmap + hdr_offset, &hdr, sizeof( freq_header_t ));

    // Write key
    memcpy( db->mmap + key_offset, key, key_sz );

    // Write zeros for the data array
    memset( db->mmap + data_offset, 0, hdr.data_sz );

    // Update the file header
    db->file_hdr->eod = hdr_offset + freq_sz;

    //TLOG_DEBUG( "hdr_offset: %ld, data_offset: %ld", hdr_offset, data_offset );
    (void)data_offset;

    *return_hdr_offset = hdr_offset;

    return FREQ_DB_SUCCESS;
  }


static void
file_lock( freq_db_t *db )
  {
    Pthread_mutex_lock( &db->file_lock );
  }


static void
file_unlock( freq_db_t *db )
  {
    Pthread_mutex_unlock( &db->file_lock );
  }


/******************************************************************************
 * hdr Functions                                                             *
 *****************************************************************************/

// Reads are dirty for now
static void
hdr_readlock( freq_db_t *db )
  {
    Pthread_rwlock_rdlock( &db->hdr_rwlock );
  }

static void
hdr_writelock( freq_db_t *db )
  {
    Pthread_rwlock_wrlock( &db->hdr_rwlock );
  }

static void
hdr_unlock( freq_db_t *db )
  {
    Pthread_rwlock_unlock( &db->hdr_rwlock );
  }


/******************************************************************************
 * mmap Functions                                                             *
 *****************************************************************************/

static void
mmap_readlock( freq_db_t *db )
  {
    Pthread_rwlock_rdlock( &db->mmap_rwlock );
  }

static void
mmap_writelock( freq_db_t *db )
  {
    Pthread_rwlock_wrlock( &db->mmap_rwlock );
  }

static void
mmap_unlock( freq_db_t *db )
  {
    Pthread_rwlock_unlock( &db->mmap_rwlock );
  }


/******************************************************************************
 * DB Functions (Private)                                                     *
 *****************************************************************************/

static int64_t
db_index_file( freq_db_t *db )
  {
    int res;
    
    float idx_load_factor;             // what fraction of idx capacity is used
    uint64_t freqs_active_cnt = 0;
    uint64_t freqs_deleted_cnt = 0;

    off_t hdr_offset = 0;              // File offset of freq_header_t
    off_t prev_hdr_offset = 0;         // previous header offset
    off_t key_offset = 0;              // File offset of key
    off_t end_of_key = 0;              // offset for end of key
    off_t data_end = 0;                // End of data (not end of file)
    off_t mmap_end = 0;                // length of file

    freq_header_t *hdr;                // pointer to current freq_header

    // First freq_header_t starts after file header
    hdr_offset = sizeof(freq_file_header_t);

    // Find out where data ends and mmap (file) ends
    data_end = db->file_hdr->eod;
    mmap_end = db->file_sz;            // file size is also size of mmap
 
    if ( data_end > mmap_end ) {       // there's some data corruption..
        TLOG_INFO("%s - WARNING: file_hdr->eod (%"PRIu64") larger than file "
                "size (%"PRIu64"). Clipping.", 
                db->file_name, data_end, mmap_end);
        data_end = db->file_hdr->eod = mmap_end;   // clip to EOF (end of mmap)
    }                                  // we check later to make sure last 
                                       // freq is legit.. so ok to clip now

    // Iterate through file finding freqs
    while ( hdr_offset < data_end ) {
        hdr = (freq_header_t *)(db->mmap + hdr_offset);
        key_offset = hdr_offset + sizeof(freq_header_t);

        // prevent seg fault: check that entire header on mmap
        if ( key_offset > data_end ) { // entire header not in data region
            TLOG_INFO( "%s - WARNING: end of freq header past EOD.  Removing.", 
                       db->file_name );
            data_end = db->file_hdr->eod = hdr_offset;
            break;
        }

#ifdef SCRUB_ON_OPEN
        // Here, we look for freqs who's key/data were overwritten.  We do this
        // by grabbing the key, hashing it, and matching it to the stored 
        // hash key.  If they don't match, this may be because of a prior issue
        // where appends after opening an existing db would be appended just 
        // after the last freqs header, instead of after the last freqs data

        end_of_key = key_offset + hdr->key_sz;
 
        // check that entire key on mmap or we'll seg fault..
        if ( end_of_key > data_end ) {     // we got problems..
            TLOG_INFO( "%s - WARNING: end of key (%"PRIu64") past EOD "
                       "(%"PRIu64").  Removing.",db->file_name, end_of_key,
                       data_end );
            data_end = db->file_hdr->eod = hdr_offset;
            break;
        } 
 
        if (hdr->key_sz != 0 && hdr->data_sz != 0) {    //if not already fixed
            uint64_t hashcode = type_key_hash( (freq_type_t*)&hdr->type, 
                                               (char *)(db->mmap + key_offset), 
                                               hdr->key_sz );
            // if the hashed key and stored hashcode don't match, then bad data  
            if (hashcode != hdr->key_hashcode) {
                TLOG_INFO("%s - WARNING: freq %"PRIu64" key/hashcode mismatch",
                           db->file_name, freqs_active_cnt + freqs_deleted_cnt);
                // mark as deleted and make sizes zero because we think the next
                // header follows immediately after this header
                hdr->key_sz = 0;
                hdr->data_sz = 0;
                freq_type_init( 0, 0, 0, (freq_type_t*)&hdr->type );
                freq_set_status( hdr, FREQ_DELETED);
            } 
        }
#endif

        if ( freq_get_status( hdr ) == FREQ_ACTIVE ) { 
            res = index_insert( db->index, hdr_offset, hdr->key_hashcode );

            // just in case there are too many collisions, expand...
            if ( res == FREQ_DB_ERR_IDX_COLLISIONS ) {
                idx_load_factor = index_get_load_factor( db->index );
               
                // but look for pathological hashing... 
                if ( idx_load_factor > MIN_IDX_LOAD ) {
                    TLOG_INFO( "%s - Expanding index "
                               "due to collisions. Load %f",
                               db->file_name, idx_load_factor );
                    res = index_expand( db->index );
                    res = index_insert(db->index,hdr_offset, hdr->key_hashcode);
                } else {          // we're not above min load. Something wrong
                    TLOG_INFO( "%s - WARNING: cannot expand.  Load factor too"
                               " small: %f", db->file_name, idx_load_factor);
                }
            }

            if ( res != FREQ_DB_SUCCESS ) {
                ERR_RET( "%s - idx_insert failed: %d",
                         db->file_name, res );
                return res;
            }

            freqs_active_cnt++;
        } else {
            freqs_deleted_cnt++;
        }

        prev_hdr_offset = hdr_offset;
        hdr_offset = key_offset + hdr->key_sz + hdr->data_sz;
    }
  
    // hdr_offset should be at EOD now.  If not, we have a problem..
    if ( hdr_offset != data_end ) {
        TLOG_INFO( "%s - WARNING: end of freq: %lu past EOD: %lu. Fixing\n",
                    db->file_name, hdr_offset, data_end);
        // the last freq pushed us past EOD.  We'll delete it 
        hdr_offset = data_end = db->file_hdr->eod = prev_hdr_offset;
    }
   
    // Sanity check
    if ( freqs_active_cnt != db->file_hdr->live_cnt ) {
        TLOG_INFO( "%s - counted %"PRIu64" active freqs but file header says "
                   "%"PRIu64" (fixing)", db->file_name, freqs_active_cnt,
                   db->file_hdr->live_cnt );
        db->file_hdr->live_cnt = freqs_active_cnt;
    }

    if ( freqs_deleted_cnt != db->file_hdr->del_cnt ) {
        TLOG_INFO( "%s - counted %"PRIu64" deleted freqs but file header says "
                   "%"PRIu64" (fixing)", db->file_name, freqs_deleted_cnt,
                   db->file_hdr->del_cnt );
        db->file_hdr->del_cnt = freqs_deleted_cnt;
    }

    return FREQ_DB_SUCCESS;
  }


static int
db_insert( freq_db_t *db,
           freq_type_t *type,
           const char *key, uint16_t key_sz )
  {
    TLOG_TRACE( "%*s", key_sz, key );
    int res;                           // place to store return codes
    float idx_load_factor;             // what fraction of idx capacity is used
    record_portal_t recordPortal;
    off_t freq_hdr_offset;

    file_lock( db );

    // Check if record was written before we acquired write lock
    idx_readlock( db );
    mmap_readlock( db );
    res  = index_find( db->index, db->mmap, type, key, key_sz, &recordPortal );
    mmap_unlock( db );
    idx_unlock( db );

    if ( res == FREQ_DB_SUCCESS )
      {
        file_unlock( db );
        TLOG_TRACE( "record already inserted: %d", FREQ_DB_SUCCESS );
        return FREQ_DB_SUCCESS;
      }

    idx_writelock( db );

    res = file_append( db, type, key, key_sz, &freq_hdr_offset );
    if ( res != FREQ_DB_SUCCESS )
      {
        idx_unlock( db );
        file_unlock( db );
        ERR_RET( "file_append failed: %d", res );
        return res;
      }

    mmap_readlock( db );

    freq_header_t *fhp = (freq_header_t*)(db->mmap + freq_hdr_offset);
    uint64_t hashcode = fhp->key_hashcode;
 
    idx_load_factor = index_get_load_factor( db->index );
  
    // check if index already too full 
    if ( idx_load_factor > MAX_IDX_LOAD ) 
      {
        TLOG_INFO( "index load factor is %1.2f.  Expanding..",idx_load_factor );
        // if so, expand it
        res = index_expand( db->index );
        
        if ( res != FREQ_DB_SUCCESS ) 
          {
            mmap_unlock( db );
            idx_unlock( db );
            file_unlock( db );
            ERR_RET( " idx_insert failed: %d", res);
            return res;
          }
      }
    
    res = index_insert( db->index, freq_hdr_offset, hashcode);
 
    // check if insert failed due to collisions 
    if ( res == FREQ_DB_ERR_IDX_COLLISIONS ) 
      {
        // if so, expand it.. only if we're abve MIN_LOAD
        if ( idx_load_factor > MIN_IDX_LOAD ) 
          {
            TLOG_INFO( "Expanding due to collisions.  Load %f",
                       idx_load_factor );
            res = index_expand( db->index );
            res = index_insert( db->index, freq_hdr_offset, hashcode);
          }
        else                      // we're not above min load. Something wrong
          {
            TLOG_INFO( "WARNING: cannot expand.  Load factor too small: %f",
                       idx_load_factor);
          }
      } 

    TLOG_TRACE("offset %"PRIu64"\n",freq_hdr_offset);
    if ( res != FREQ_DB_SUCCESS ) 
      {
        mmap_unlock( db );
        idx_unlock( db );
        file_unlock( db );
        ERR_RET( "idx_insert failed: %d", res );
        return res;
      } 
    
    mmap_unlock( db );
    idx_unlock( db );
    file_unlock( db );

    mmap_readlock( db );
    hdr_writelock( db );
    db->file_hdr->live_cnt++;
    hdr_unlock( db );
    mmap_unlock( db );
    TLOG_TRACE( "%d", FREQ_DB_SUCCESS );

    return FREQ_DB_SUCCESS;
  }

/******************************************************************************
 * DB Functions                                                               *
 *****************************************************************************/

int
freq_db_open( freq_db_t **fdb_ptrptr,
              const char * filename,
              int64_t incr_sz )
  {
    TLOG_TRACE( "filename: %s, incr_sz %"PRId64, filename, incr_sz );
    int new_file = 0;
    int res;

    // Allocate the structure for our db
    freq_db_t * fdb = malloc( sizeof(freq_db_t) );
    if ( fdb == NULL )
      {
        ERR_RET( "malloc of freq_db_t failed: %d", FREQ_DB_SYS_ERR_MALLOC );
        return FREQ_DB_SYS_ERR_MALLOC;
      }

    size_t filename_sz = strlen( filename );
    fdb->file_name = (char*)malloc( filename_sz + 1 ); // hacky
   
    if ( fdb->file_name == NULL ) 
      {
        ERR_RET( "malloc of filename failed: %d", FREQ_DB_SYS_ERR_MALLOC );
        return FREQ_DB_SYS_ERR_MALLOC;
      }
 
    fdb->file_name[filename_sz] = '\0';
    memcpy( fdb->file_name, filename, filename_sz );
 
    // fill in increment size
    fdb->incr_sz = incr_sz;

    // Try to open file for reading and if that fails try to create it
    fdb->file_fd = open( filename, O_RDWR | O_EXCL );

    if ( fdb->file_fd == -1 )
      {
        fdb->file_fd = open( filename,
                             O_CREAT | O_RDWR | O_EXCL,
                             S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH );

        if ( fdb->file_fd == -1 )
          {
            ERR_RET( "could not create file: %d", FREQ_DB_SYS_ERR_OPEN );
            return FREQ_DB_SYS_ERR_OPEN;
          }

        int initialized = file_init( fdb->file_fd, incr_sz );
        if ( initialized != FREQ_DB_SUCCESS )
          {
            ERR_RET( "could not initialize file: %d", initialized );
            return initialized;
          }

        // Track that this is a new file
        new_file = 1;
      }

    // Get current file size
    fdb->file_sz = file_length( fdb->file_fd );

    // init the locks
    Pthread_mutex_init( &fdb->file_lock, NULL );
    Pthread_rwlock_init( &fdb->iter_rwlock, NULL );
    Pthread_rwlock_init( &fdb->hdr_rwlock, NULL );
    Pthread_rwlock_init( &fdb->mmap_rwlock, NULL );
    Pthread_rwlock_init( &fdb->idx_rwlock, NULL );

    // Memory map the file
    fdb->mmap = mmap( (caddr_t)0,
                      fdb->file_sz,
                      PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_SHARED,
                      fdb->file_fd,
                      0 );

    if ( fdb->mmap == MAP_FAILED )
      {
        ERR_RET( "mmap failed: %d", FREQ_DB_SYS_ERR_MMAP );
        return FREQ_DB_SYS_ERR_MMAP;
      }
 
    // do a little error checking
    if ( fdb->file_hdr->eod > (off_t)fdb->file_sz )
      {
        TLOG_INFO( "%s - WARNING: eod %"PRIu64" greater than filesize "
                   "%"PRIu64" - fixing", fdb->file_name, fdb->file_hdr->eod, 
                   fdb->file_sz );
        fdb->file_hdr->eod = (off_t) fdb->file_sz;
      }

    // ensure version number is supported.  If not, attempt opening anyway.
    if ( fdb->file_hdr->version != VERSION_NUM ) 
      {
        TLOG_INFO( "%s - WARNING: db version %u does not match supported "
                   "version %u.  Attempting to open", fdb->file_name, 
                   fdb->file_hdr->version, VERSION_NUM );
      }

#ifdef DEBUG
    fprintf( stdout, "%s\n", fdb->file_name );
    file_print_header( stdout, fdb->file_hdr );
#endif
    res = index_init( &fdb->index, 
                      fdb->file_hdr->live_cnt, 
                      INITIAL_INDEX_CAPACITY );
    if ( res != FREQ_DB_SUCCESS ) {
      ERR_RET( "index_init failed: %d", res );
      return res;
    }

    res = db_index_file( fdb );
    if ( res != FREQ_DB_SUCCESS )
      {
        ERR_RET( "db_index_file failed: %d", res );
        return res;
      }

    *fdb_ptrptr = fdb;

    res = (new_file == 1) ? FREQ_DB_CREATED : FREQ_DB_SUCCESS;

    TLOG_TRACE( "%d", res );
    return res;
  }


int
freq_db_info( freq_db_t *db,
              freq_db_info_t *info )
  {
    TLOG_TRACE( "filename : %s", db->file_name );

    // zero out info struct
    memset( info, 0, sizeof(freq_db_info_t) );

    file_lock( db );
    idx_readlock ( db );
    mmap_readlock( db );
    hdr_readlock( db );

    info->active_freqs = db->file_hdr->live_cnt;
    info->deleted_freqs = db->file_hdr->del_cnt;
    info->increment_sz = db->incr_sz;
    info->disk_sz = db->file_hdr->eod;
    info->index_sz = index_get_capacity( db->index );

    hdr_unlock( db );
    mmap_unlock( db );
    idx_unlock( db );
    file_unlock( db );

    return FREQ_DB_SUCCESS;
  }


int
freq_db_sync( freq_db_t *db )
  {
    TLOG_TRACE( "filename: %s", db->file_name );
    mmap_readlock( db );

    // Sync the file to disk
    int result = msync( db->mmap, db->file_sz, MS_SYNC | MS_INVALIDATE );
    if ( result == -1 )
      {
        mmap_unlock( db );
        ERR_RET( "msync failed: %d", result );
        return FREQ_DB_SYS_ERR_MSYNC;
      }

    mmap_unlock( db );

    TLOG_TRACE( "0", NULL );
    return FREQ_DB_SUCCESS;
  }


int
freq_db_gc( freq_db_t *db, freq_db_gc_stats_t *stats )
  {
    TLOG_TRACE( "%s - gc starting", db->file_name );
    TLOG_DEBUG( "%s - gc starting", db->file_name );
    TLOG_INFO( "%s - gc starting", db->file_name );  

    // Get the iterator write lock
    TLOG_DEBUG( "%s - iter_writelock start", db->file_name );
    iter_writelock( db );
    TLOG_DEBUG( "%s - iter_writelock acquired", db->file_name );

    // Zero out stats memory
    memset( stats, 0, sizeof(freq_db_gc_stats_t) );
    stats->collected_freqs = 0;
    stats->collected_bytes = 0;

    freq_header_t* hdr;    // Pointer to current freq
    uint64_t freq_sz;      // Size of current freq
    off_t freq_offset;     // Offset of current freq 
    off_t free_offset;     // Offset of free space
    off_t last_offset = 0; // Offset of last freq
    record_portal_t recordPortal;     
    int res;               // place to store return codes

    // First freq starts after file header
    freq_offset = sizeof(freq_file_header_t);

    // No garbage to start with
    free_offset = -1;

    // Acquire file lock to check if we're at the end (this will block
    // other appends, which is what we want).
    TLOG_DEBUG( "file_lock start", NULL );
    file_lock( db );
    TLOG_DEBUG( "file_lock acquired", NULL );

    // Acquire readlock on the mmap region. Technically we do write to it,
    // but we lock at the freq level for any moves that occur.
    TLOG_DEBUG( "%s - mmap_readlock start", db->file_name );
    mmap_readlock( db );
    TLOG_DEBUG( "%s - mmap_readlock acquired", db->file_name );

    TLOG_DEBUG( "hdr_readlock start",  NULL );
    hdr_readlock( db );
    TLOG_DEBUG( "hdr_readlock acquired", NULL );

    TLOG_DEBUG( "%s - freq_offset: %ld db->file_hdr->eod: %ld\n",
                db->file_name, freq_offset, db->file_hdr->eod );

    while ( freq_offset < db->file_hdr->eod )
      {
        // Unlock the header
        hdr_unlock( db );
        TLOG_DEBUG( "hdr_readlock released", NULL );

        // Get pointer to freq
        hdr = (freq_header_t*) (db->mmap + freq_offset);

        // Get size of freq
        freq_sz = sizeof(freq_header_t) + hdr->key_sz + hdr->data_sz;

        // DEBUG: freqs greater than 1MB are fish
        if ( freq_sz > 1048576 )
          {
            TLOG_INFO( "suspiciously large freq (%"PRIu64" bytes) "
                       "cnt: %d mins: %d bits: %d key: %*s key_sz: %u "
                       "file offset: %"PRIu64" file end: %"PRIu64,
                       freq_sz,
                       ((freq_type_t*)hdr)->interval_cnt,
                       ((freq_type_t*)hdr)->interval_mins,
                       ((freq_type_t*)hdr)->interval_bits,
                       freq_get_key_sz( hdr ),
                       freq_get_key( hdr ),
                       freq_get_key_sz( hdr ),
                       freq_offset, db->file_hdr->eod );
          }

        // If it's stale, delete it
        if ( freq_is_stale( hdr ) )
          {
            TLOG_DEBUG( "delete stale freq start: %s", freq_get_key( hdr ) );
            freq_db_delete( db,
                            (freq_type_t*) hdr,
                            freq_get_key( hdr ),
                            freq_get_key_sz( hdr ) );
            TLOG_DEBUG( "delete stale freq completed", NULL );
          }

        // If deleted, do collection
        if ( freq_get_status( hdr ) == FREQ_DELETED )
          {
            // Increment stats
            stats->collected_freqs += 1;
            stats->collected_bytes += freq_sz;

            // Update compaction pointer if this is first freq collected
            if ( free_offset == -1 )
              {
                free_offset = freq_offset;
                TLOG_DEBUG( "free_offset set to %"PRIu64"", freq_offset );
              }
          }
        else
          {
            last_offset = freq_offset;

            // Check if we need to compact this freq
            if ( free_offset >= 0 )
              {
                // Get the record so we can update it
                idx_readlock( db );
                mmap_readlock( db );
                res = index_find( db->index, db->mmap, (freq_type_t*) hdr, 
                                  freq_get_key( hdr ), freq_get_key_sz( hdr ),
                                  &recordPortal );
                mmap_unlock( db );

                // If we didn't find the record we assume it's not in use
                // and collect it
                if ( res != FREQ_DB_SUCCESS )
                  {
                    idx_unlock( db );
                    TLOG_INFO( "unindexed freq collected -  cnt: %d "
                               "mins: %d bits: %d key: %*s: key_sz: %u "
                               "file offset: %"PRIu64" file end: %"PRIu64"",
                               ((freq_type_t*)hdr)->interval_cnt,
                               ((freq_type_t*)hdr)->interval_mins,
                               ((freq_type_t*)hdr)->interval_bits,
                               freq_get_key_sz( hdr ),
                               freq_get_key( hdr ),
                               freq_get_key_sz( hdr ),
                               freq_offset, db->file_hdr->eod );

                    stats->collected_freqs += 1;
                    stats->collected_bytes += freq_sz;

                    // Update compaction pointer if this is first freq collected
                    if ( free_offset == -1 )
                      {
                        free_offset = freq_offset;
                        TLOG_DEBUG( "free_offset set to %ld", freq_offset );
                      }
                  }
                else
                  { 
                    TLOG_DEBUG( "freq move starting", NULL );
                    TLOG_TRACE( "freq move starting (from %"PRIu64  
                                " to %"PRIu64")", freq_offset, free_offset ); 

                    // Lock the record so we can move it
                    record_writelock( &recordPortal );
                    idx_unlock( db );	
    
                    // Move the data around
                    uint64_t free_sz = freq_offset - free_offset;
                    if ( free_sz > freq_sz )
                      {
                        memcpy( db->mmap + free_offset,
                                db->mmap + freq_offset,
                                freq_sz );
                      }
                    else
                      {
                        memmove( db->mmap + free_offset,
                                 db->mmap + freq_offset,
                                 freq_sz );
                      }
    
                    // Update record
                    record_move_to( &recordPortal, free_offset);

                    last_offset = free_offset;
    
                    // Unlock the record
                    record_unlock( &recordPortal );

                    // Update free offset
                    free_offset += freq_sz;
    
                    TLOG_DEBUG( "freq move done", NULL );
                  }
              }
          }
   
        mmap_unlock( db );

        // Unlock the file so appends can continue
        TLOG_DEBUG( "file_lock released", NULL );
        file_unlock( db ); 	// may get a file_append or file_expand here

        // Increment pointer to location of next freq
        freq_offset += freq_sz;

        // Acquire file lock for the check if we're at the end
        TLOG_DEBUG( "file_lock starting", NULL );
        file_lock( db );
        TLOG_DEBUG( "file_lock acquired", NULL );
   
        TLOG_DEBUG( "mmap_readlock starting", NULL );
        mmap_readlock( db );
        TLOG_DEBUG( "mmap_readlock acquired", NULL );

        TLOG_DEBUG( "hdr_readlock start",  NULL );
        hdr_readlock( db );
        TLOG_DEBUG( "hdr_readlock acquired", NULL );

        TLOG_DEBUG( "last_offset: %"PRIu64" freq_offset: %"PRIu64
                    " db->file_hdr->eod: %"PRIu64,
                    last_offset, freq_offset, db->file_hdr->eod );
      }

    // When loop exits we're at the end of the data and we have
    // the file lock. Now update EOD if we compacted.
    if ( free_offset > 0 )
      {
        db->file_hdr->eod = free_offset;
        db->file_hdr->del_cnt -= stats->collected_freqs;
        lseek( db->file_fd, free_offset, SEEK_SET );
        TLOG_DEBUG( "file_hdr stats updated", NULL );
      }

    TLOG_INFO( "gc stats: freqs: %"PRIu64" bytes: %"PRIu64,
               stats->collected_freqs, stats->collected_bytes );

    // Release locks
    hdr_unlock( db );
    TLOG_DEBUG( "hdr_readlock released", NULL );
    mmap_unlock( db );
    TLOG_DEBUG( "mmap_readlock released", NULL );
    file_unlock( db );
    TLOG_DEBUG( "file_lock released", NULL );
    iter_unlock( db );
    TLOG_DEBUG( "iter_lock released", NULL );

    TLOG_DEBUG( "%d", FREQ_DB_SUCCESS );
    TLOG_TRACE( "%d", FREQ_DB_SUCCESS );
    return FREQ_DB_SUCCESS;
  }


int
freq_db_close( freq_db_t *db )
  {
    TLOG_TRACE( "%s", db->file_name );
#ifdef DEBUG
    file_print_header( stdout, db->file_hdr );
#endif

    // Acquire all locks so no one else tries to access this guy
    file_lock( db );
    idx_writelock( db );
    mmap_writelock( db );

    // Sync the file to disk
    int result = msync( db->mmap, db->file_sz, MS_SYNC | MS_INVALIDATE );
    if ( result == -1 )
      ERR_RET( "%s - msync failed: %d", db->file_name, FREQ_DB_SYS_ERR_MSYNC );

    result = munmap( db->mmap, db->file_sz );
    if ( result == -1 )
      ERR_RET( "%s - munmap failed: %d", db->file_name, FREQ_DB_SYS_ERR_MMAP );

    result = close( db->file_fd );
    if ( result == -1 )
      ERR_RET( "%s - close failed: %d", db->file_name, FREQ_DB_SYS_ERR_CLOSE );

    // Destroy the index
    index_destroy( db->index );

    mmap_unlock( db );
    idx_unlock( db );
    file_unlock( db );

    pthread_rwlock_destroy( &db->idx_rwlock );
    pthread_rwlock_destroy( &db->mmap_rwlock );
    pthread_mutex_destroy( &db->file_lock );

    TLOG_TRACE( "%s - %d", db->file_name, result );

    free( db->file_name );
    free( db );

    return result;
  }


int
freq_db_increment( freq_db_t *db,
                   freq_type_t *type,
                   const char *key,
                   uint16_t key_sz,
                   uint32_t offset_minutes )
  {
   
    int new_record = 0;
    int res; 
    record_portal_t recordPortal;

    TLOG_TRACE( "%s - cnt: %d mins: %d bits: %d key: %*s: key_sz: %d offset_mins: %d",
                db->file_name,
                type->interval_cnt, type->interval_mins, type->interval_bits,
                key_sz, key, key_sz,
                offset_minutes );

    // Make sure the type is valid
    if ( type->interval_cnt == 0  ||
         type->interval_mins == 0 ||
         type->interval_bits == 0 )
      {
        TLOG_TRACE( "invalid type: %d", FREQ_DB_INVALID_TYPE );
        return FREQ_DB_INVALID_TYPE;
      }

    // Make sure the key is valid
    if ( key_sz == 0 || key == NULL )
      {
        TLOG_TRACE( "empty key: %d", FREQ_DB_EMPTY_KEY );
        return FREQ_DB_EMPTY_KEY;
      }

    idx_readlock( db );
    mmap_readlock( db );
    res = index_find( db->index, db->mmap, type, key, key_sz, &recordPortal);
    mmap_unlock( db );

    if ( res != FREQ_DB_SUCCESS )		
      {					
        idx_unlock( db );                 // db_insert needs idx_writelock
        res = db_insert( db, type, key, key_sz );
        if ( res != FREQ_DB_SUCCESS )
          {
            ERR_RET( "db_insert failed: %d", res );
            return res;
          }
        new_record = 1;

        // need to find again in case removed after insert by freq_db_delete.
        // also, need to get record ptr while holding idx_readlock, so we can
        // grab freq_record_writelock to protect the pointer. 
        idx_readlock( db );     
        mmap_readlock( db );
        res = index_find( db->index, db->mmap, type, key, key_sz, &recordPortal);
        mmap_unlock( db );

        if ( res != FREQ_DB_SUCCESS ) 
          {
            idx_unlock( db );
            return FREQ_DB_NOTFOUND;
          }
      }

    mmap_readlock( db );
    record_writelock( &recordPortal );
    idx_unlock( db ); 

    freq_header_t *hdr = get_record_header( &recordPortal, db->mmap ); 
    res = freq_increment( hdr, offset_minutes );

    record_unlock( &recordPortal );
    mmap_unlock( db );

    if ( new_record == 1 && res == FREQ_DB_SUCCESS ) res = FREQ_DB_CREATED;

    TLOG_TRACE( "%d", res );
    return res;
  }


int
freq_db_count( freq_db_t *db,
               freq_type_t *type,
               const char *key, uint16_t key_sz,
               uint32_t minutes, uint32_t offset_minutes,
               freq_count_t *count )
  {

    record_portal_t recordPortal;
    int res;       // place to hold return codes  

    TLOG_TRACE( "%s - cnt: %d mins: %d bits: %d key: %*s: key_sz: %d "
                "mins: %d offset_mins: %d",
                db->file_name,
                type->interval_cnt, type->interval_mins, type->interval_bits,
                key_sz, key, key_sz,
                minutes, offset_minutes );

    idx_readlock( db );
    mmap_readlock( db );
    res = index_find( db->index, db->mmap, type, key, key_sz, &recordPortal);
    mmap_unlock( db );

    if ( res != FREQ_DB_SUCCESS )
      {
        TLOG_TRACE( "not found: %d", FREQ_DB_NOTFOUND );
        idx_unlock( db );
        return FREQ_DB_NOTFOUND;
      }

    mmap_readlock( db );
    record_readlock( &recordPortal );
    idx_unlock( db ); 

    freq_header_t *hdr = get_record_header( &recordPortal, db->mmap );
 
    res = freq_count( hdr, minutes, offset_minutes, count );
    record_unlock( &recordPortal );
    mmap_unlock( db );

    TLOG_TRACE( "%d", res );
    return res;
  }


int
freq_db_delete( freq_db_t *db,
                freq_type_t *type,
                const char *key, uint16_t key_sz )
  {
    TLOG_TRACE( "%s - cnt: %d mins: %d bits: %d key: %*s: key_sz: %d "
                "mins: %d offset_mins: %d",
                db->file_name,
                type->interval_cnt, type->interval_mins, type->interval_bits,
                key_sz, key, key_sz );
    int res;
    record_portal_t recordPortal;   

    // Lock the index and try to remove the entry from it
    idx_writelock( db );
    mmap_readlock( db );
    res = index_find( db->index, db->mmap, type, key, key_sz, &recordPortal );
    mmap_unlock( db );

    if ( res == FREQ_DB_NOTFOUND ) { 
      TLOG_TRACE( "not found: %d", FREQ_DB_NOTFOUND );
      idx_unlock( db );
      return FREQ_DB_NOTFOUND;
    }

    // Lock the record and mark it as deleted
    mmap_readlock( db );
    record_writelock( &recordPortal );

    freq_header_t *hdr = get_record_header( &recordPortal, db->mmap );

    freq_set_status( hdr, FREQ_DELETED );

    record_unlock( &recordPortal );
    mmap_unlock( db );
    
    mmap_readlock( db ); 
    res = index_remove( db->index, db->mmap, type, key, key_sz );	//TODO:  don't like 
    mmap_unlock( db );
 
    if ( res != FREQ_DB_SUCCESS ) {
      TLOG_TRACE( " WARNING: remove did not find entry %d\n", res );
    }
    idx_unlock( db );

    // Lock the mmap and update the file header
    mmap_readlock( db );
    hdr_writelock( db );
    db->file_hdr->live_cnt--;
    db->file_hdr->del_cnt++;
    hdr_unlock( db );
    mmap_unlock( db );

    TLOG_TRACE( "%d", FREQ_DB_SUCCESS );
    return FREQ_DB_SUCCESS;
  }

int
freq_db_get_binary( freq_db_t *db,
                    freq_type_t *type,
                    const char *key, uint16_t key_sz,
                    char *binary_buff, uint64_t binary_buff_sz,
                    uint64_t *binary_sz )
  {
    int res; 
    record_portal_t recordPortal;

    idx_readlock( db );
    mmap_readlock( db );
    res  = index_find( db->index, db->mmap, type, key, key_sz, &recordPortal );
    mmap_unlock( db );

    if ( res != FREQ_DB_SUCCESS ) 
      { 
        idx_unlock( db );
        return FREQ_DB_NOTFOUND;
      }

    mmap_readlock( db );
    record_readlock( &recordPortal );
    idx_unlock( db ); 
 
    freq_header_t *hdr = get_record_header( &recordPortal, db->mmap ); 

    // Get the size of the binary representation
    *binary_sz = freq_get_size( hdr );

    if ( *binary_sz > binary_buff_sz )
      {
        res = FREQ_DB_BUFF_TOO_SMALL;
      }
    else
      {
        memcpy( binary_buff, (char*)hdr, *binary_sz );
        res = FREQ_DB_SUCCESS;
      }

    record_unlock( &recordPortal );
    mmap_unlock( db );

    return res;
  }

int
freq_db_put_binary( freq_db_t *db,
                    const char *binary, uint64_t binary_sz,
                    int op_if_present )
  {
    int res;
    record_portal_t recordPortal; 

    // Make sure op_if_present is valid
    if ( op_if_present != FREQ_DB_PUT_MERGE &&
         op_if_present != FREQ_DB_PUT_OVERWRITE &&
         op_if_present != FREQ_DB_PUT_DONTPUT )
      {
        return FREQ_DB_INVALID_OP;
      } 

    freq_header_t *hdr = (freq_header_t*)binary;

    freq_type_t *type = (freq_type_t*)hdr;
    const char *key = freq_get_key( hdr );
    uint16_t key_sz = freq_get_key_sz( hdr );
    uint64_t freq_sz = freq_get_size( hdr );

    if ( freq_sz != binary_sz )
      {
        return FREQ_DB_INVALID_BINARY;
      }

    idx_readlock( db );
    mmap_readlock( db );
    res  = index_find( db->index, db->mmap, type, key, key_sz, &recordPortal );
    mmap_unlock( db );

    if ( res == FREQ_DB_SUCCESS && FREQ_DB_PUT_DONTPUT == op_if_present )
      {
        idx_unlock( db );
        return FREQ_DB_SUCCESS;
      }

    int new = 0;

    if ( res != FREQ_DB_SUCCESS )
      {
        idx_unlock( db );	// db_insert needs idx_writelock
        res = db_insert( db, type, key, key_sz );
        if ( res != FREQ_DB_SUCCESS )
          {
            return res;
          }
        new = 1;
       
        // need to find again in case removed after insert by freq_db_delete.
        // also, need to get record ptr while holding idx_readlock, so we can
        // grab freq_record_writelock to protect the pointer. 
        idx_readlock( db );	
        mmap_readlock( db );
        res  = index_find( db->index, db->mmap, type, key, key_sz, &recordPortal );
        mmap_unlock( db );

        if ( res != FREQ_DB_SUCCESS ) 
          {
            idx_unlock( db );
            return FREQ_DB_NOTFOUND;
          }
      }

    mmap_readlock( db );
    record_writelock( &recordPortal );
    idx_unlock( db ); 

    freq_header_t *prev_hdr = get_record_header( &recordPortal, db->mmap );

    // Do merge or copy over new data
    if ( !new && FREQ_DB_PUT_MERGE == op_if_present ) {
        res = freq_merge( prev_hdr, hdr );
    } else {
        // sanity check
        if ( freq_get_size( prev_hdr ) == binary_sz ) {
            //assert( freq_get_size( prev_hdr ) == binary_sz );
            memcpy( prev_hdr, hdr, binary_sz );
            res = FREQ_DB_SUCCESS;
        } else {
            res = FREQ_DB_INVALID_BINARY;
        }
    }

    record_unlock( &recordPortal );
    mmap_unlock( db ); 

    return res;
  }

int
freq_db_iter_init( freq_db_t *db,
                   freq_db_iter_t **iter_ptrptr )
  {
    int res = FREQ_DB_SUCCESS;

    TLOG_DEBUG( "iter_init started", NULL );

    // Allocate the structure for our db
    freq_db_iter_t * iter = malloc( sizeof(freq_db_iter_t) );
    if ( iter == NULL )
      {
        ERR_RET( "malloc of freq_db_iter_t failed", NULL );
        return FREQ_DB_SYS_ERR_MALLOC;
      }

    // Zero out the iter struct
    memset( iter, 0, sizeof(freq_db_iter_t) );

    // Get a read lock for iterating
    iter_readlock( db );
    iter->db     = db;
    iter->state  = FREQ_DB_ITER_ACTIVE;
    iter->offset = sizeof(freq_file_header_t);  // First freq is after the file header

    // Lock the file and check EOF
    file_lock( iter->db );
    hdr_readlock( iter->db );
    if ( iter->offset == iter->db->file_hdr->eod ) res = FREQ_DB_ITER_EOF;
    hdr_unlock( iter->db );
    file_unlock( iter->db );

    // If not EOF, find first valid freq
    if ( res != FREQ_DB_ITER_EOF )
      {
        // Lock mmap region so we can read header info
        mmap_readlock( iter->db );
        freq_header_t *hdr = (freq_header_t*) (iter->db->mmap + iter->offset);

        // If the current freq is deleted or stale, move to the next
        if ( freq_is_stale( hdr ) || freq_get_status( hdr ) == FREQ_DELETED )
          {
            mmap_unlock( iter->db );
            res = freq_db_iter_next( iter );
          }
        else
          {
            mmap_unlock( iter->db );
          }
      }

    *iter_ptrptr = iter;

    return res;
  }

int
freq_db_iter_next( freq_db_iter_t *iter )
  {
    if ( iter == NULL ) return FREQ_DB_ITER_INACTIVE;
    if ( iter->state != FREQ_DB_ITER_ACTIVE) return iter->state;

    // Lock mmap region so we can read header info
    mmap_readlock( iter->db );

    freq_header_t *hdr;
    uint64_t freq_sz;

    int res = FREQ_DB_SUCCESS;
    while ( 1 )
      {
        // Get ptr to current freq
        hdr = (freq_header_t*) (iter->db->mmap + iter->offset);

        // Get size of current freq
        freq_sz = freq_get_size( hdr );

        // Move offset to next freq
        iter->offset += freq_sz;

        // Lock file and check EOF
        file_lock( iter->db );
        hdr_readlock( iter->db );
        if ( iter->offset == iter->db->file_hdr->eod ) res = FREQ_DB_ITER_EOF;
        hdr_unlock( iter->db );
        file_unlock( iter->db );
        if ( res != FREQ_DB_SUCCESS ) break;

        // Get ptr to next freq
        hdr = (freq_header_t*) (iter->db->mmap + iter->offset);

        // If the current freq is not deleted or stale, we're done
        if ( !freq_is_stale( hdr ) && freq_get_status( hdr ) != FREQ_DELETED )
          {
            break;
          }
      }

    mmap_unlock( iter->db );

    return res;
  }

int
freq_db_iter_done( freq_db_iter_t **iter )
  {
    if ( *iter == NULL ) return FREQ_DB_ITER_INACTIVE;

    iter_unlock( (*iter)->db );

    free( *iter );
    *iter = NULL;

    return FREQ_DB_SUCCESS;
  }

int
freq_db_iter_read( freq_db_iter_t *iter,
                   freq_type_t *type,
                   char *key_buff, uint16_t key_buff_sz,
                   uint16_t *key_sz )
  {
    if ( iter == NULL ) return FREQ_DB_ITER_INACTIVE;
    if ( iter->state != FREQ_DB_ITER_ACTIVE ) return iter->state;

    mmap_readlock( iter->db );

    freq_header_t *hdr = (freq_header_t*) (iter->db->mmap + iter->offset);

    // Copy the freq_type
    memcpy( type, hdr, sizeof(freq_type_t ));

    // Set the key size
    *key_sz = freq_get_key_sz( hdr );

    // Check if the buffer can hold the key and copy if so
    int res;
    if ( *key_sz >= key_buff_sz )
      {
        res = FREQ_DB_BUFF_TOO_SMALL;
      }
    else
      {
        const char * key = freq_get_key( hdr );
        memcpy( key_buff, key, *key_sz );
        key_buff[*key_sz] = '\0';
        res = FREQ_DB_SUCCESS;
      }

    mmap_unlock( iter->db );
    return res;
  }

