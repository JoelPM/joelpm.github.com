#ifndef __RECORD_INDEX_H
#define __RECORD_INDEX_H

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include "freq_db.h"
#include "freq.h"
#include "record_portal.h"
#include "error.h"
#include "pthreadwrappers.h"
#include "lookup3.h"
#include "tlog.h"

typedef struct index index_t;

/******************************************************************************
 * INDEX_INIT - allocates memory required for index data structure.  Allocates
 *           enough space for at least twice the number of active records in 
 *           the DB or the INITIAL_INDEX_CAPACITY, whichever is greater
 *  INPUTS:  index - client will get a pointer to the index_t struct.  This
 *           input from client is where we'll put that pointer for them to use 
 *  OUTPUT:  FREQ_DB_SUCCESS if successful
 *           FREQ_DB_SYS_ERR_MALLOC if unable to malloc enough memory
 *  LOCKS:   no locking required.  Assumes no other threads active, though.
 *  SIDE EFFECTS: cliet supplied pointer to index_t pointer will contain the
 *****************************************************************************/
int 
index_init( index_t **index, uint64_t live_cnt, uint64_t min_cnt );


/******************************************************************************
 * INDEX_INSERT
 *  INPUTS:  index - pointer to the index_t structure
 *           record_offset - the offset (in bytes) into the file where this 
 *           record begins
 *           hashcode - the output of type_key_hash() for this record 
 *  OUTPUT:  FREQ_DB_SUCCESS if successful
 *           FREQ_DB_ERR_IDX_COLLISIONS if no slot avail. Need index_expand
 *  LOCKS:   Assumes idx_writelock has been acquired.
 *  SIDE EFFECTS: none
 *****************************************************************************/
int 
index_insert( index_t *index, off_t record_offset, uint64_t hashcode);


/******************************************************************************
 * INDEX_EXPAND - doubles the capacity of the index and re-inserts existing 
 *           entries to their new location.  Frees mem associated with old index
 *  INPUTS:  index - pointer to the index_t structure
 *  OUTPUT:  FREQ_DB_SUCCESS 
 *           FREQ_DB_SYS_ERR_MALLOC if out of memory
 *  LOCKS:   idx_writelock - so no readers may enter (ie index_find blocked)
 *  SIDE EFFECTS: none
 *****************************************************************************/
int 
index_expand( index_t *index );


/******************************************************************************
 * INDEX_DESTROY - wipes out index data structure.  Frees all associated mem
 *  INPUTS:  index - pointer to the index_t structure
 *  OUTPUTS: none
 *  LOCKS:   must acquire file, idx_write, and mmap_write prior.  
 *  SIDE EFFECTS: none
 *****************************************************************************/
void
index_destroy( index_t *index );


/******************************************************************************
 * INDEX_FIND
 *  INPUTS:  index - pointer to the index_t structure
 *           type - the type info for the record you're looking for
 *           key - the key of the record you're looking for
 *           key_sz - num chars (not including null term) for key
 *           record - pointer to record_portal storage. Caller must pre-allocate
 *           space for a record_portal_t and pass us the pointer.
 *  OUTPUT:  FREQ_DB_SUCCESS
 *           FREQ_DB_NOT_FOUND 
 *  LOCKS:   assumes idx_readlock and mmap_readlock acquired
 *  SIDE EFFECTS:  record portal will be filled out on successful exit 
 *****************************************************************************/
int
index_find( index_t *index, const char *base, freq_type_t *type,
            const char *key, uint16_t key_sz, record_portal_t *record );


/******************************************************************************
 * INDEX_REMOVE - removes index related information about a record.  Does not
 *          remove the record itself.
 *  INPUTS: index - pointer to the index_t structure
 *          type - the type info for the record you're looking for
 *           key - the key of the record you're looking for
 *           key_sz - num chars (not including null term) for key
 *  OUTPUT: FREQ_DB_SUCCESS
 *          FREQ_DB_NOT_FOUND 
 *  LOCKS:  assumes idx_writelock and mmap_readlock acquired
 *  SIDE EFFECTS: none 
*****************************************************************************/
int
index_remove( index_t *index, const char *base, freq_type_t *type,
            const char *key, uint16_t key_sz );


/******************************************************************************
 * INDEX_GET_LOAD_FACTOR
 *  INPUTS: index - pointer to the index_t structure
 *  OUTPUT: a floating point number between 0.0 and 1.0 representing how full 
 *          the index is.  1.0 represents an index that is completely full and
 *          needs to be expanded using index_expand()
 *  LOCKS:  assumes idx_readlock acquired
 *  SIDE EFFECTS: none 
 *****************************************************************************/
float
index_get_load_factor( index_t *index );


/******************************************************************************
 * INDEX_CAPACITY - returns the number of records the index can hold.  Multiply
 *          this number by the load-factor to get the actual number held in idx
 *  INPUTS: index - pointer to the index_t structure
 *  OUTPUT: uint64_t - max number of records 
 *  LOCKS:  assumes idx_readlock acquired
 *  SIDE EFFECTS: none
 *****************************************************************************/
uint64_t
index_get_capacity( index_t *index );


/******************************************************************************
 * Key Functions                                                              *
 *****************************************************************************/
uint64_t
type_key_hash( freq_type_t *type, const char * key, uint16_t key_sz );

int
type_key_cmp( freq_type_t *type1, const char *key1, uint16_t key1_sz,
              freq_type_t *type2, const char *key2, uint16_t key2_sz );


#endif  /* __RECORD_INDEX_H */
