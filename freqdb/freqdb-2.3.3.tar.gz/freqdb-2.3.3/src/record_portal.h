#ifndef __RECORD_PORTAL_H
#define __RECORD_PORTAL_H


#include <sys/types.h>
#include "freq.h"
#include "pthreadwrappers.h"

//#include "freq_db_err.h"

typedef struct record_portal {                   //TODO: make private.
  pthread_rwlock_t *rwlockPtr;
  off_t *hdr_offset;
} record_portal_t;

/*
int
record_portal_create( record_portal_t **rp,
                    off_t *offset, pthread_rwlock_t *rwlockPtr );

void
record_portal_destroy( record_portal_t* rp );
*/

/******************************************************************************
 * RECORD_MOVE_TO - moves a record to a new location (offset), doesn't actually
 *          move the data, just the recording of the offset.
 *  INPUTS: *record_portal - a record portal for the record you want to move 
 *  OUTPUT: none 
 *  SIDE EFFECTS: none
 *  LOCKS:  have acquired record_writelock 
 *****************************************************************************/
void
record_move_to( record_portal_t *record_portal, off_t new_offset);

/******************************************************************************
 * GET_RECORD_HEADER - returns a pointer to the physical memory location where
 *           the record resides.  
 *  INPUTS:  *record_portal - a record portal pointer for desired record 
 *  OUTPUT:  pointer to physical mem location of record header 
 *  SIDE EFFECTS:  none 
 *  LOCKS:   acquire mmap lock and record lock for as long as the record header
 *           is in use.  This keeps the mmap from moving physical mem locations
 *           and the record from being written to by another thread. 
 *****************************************************************************/
freq_header_t *
get_record_header( record_portal_t *record_portal, const char *base );

/******************************************************************************
 * RECORD_READLOCK 
 *  INPUTS:  *record_portal - a record portal pointer for desired record 
 *  OUTPUT:  none 
 *  SIDE EFFECTS:  record lock is locked
 *  LOCKS:   acquire index lock prior.  May release index lock after this call
 *****************************************************************************/
void
record_readlock( record_portal_t *record_portal );

void
record_writelock( record_portal_t *record_portal );

void
record_unlock( record_portal_t *record_portal );

#endif /* __RECORD_PORTAL_H */

