#include "record_index.h"

#define IDX_MAX_INSERT_ATTEMPTS 255         // collisions not as expensive now
#define IDX_LEAF_SIZE 256                   // should be 2^NBITS
#define NBITS 8

static uint64_t INIT_CAPACITY = 131072;

typedef struct indexEntry {
  uint64_t hashkey;                         // the hashkey 
  off_t    hdr_offset;                      // offset into file for record 
} indexEntry_t;

typedef struct indexLeaf {
  indexEntry_t entry[ IDX_LEAF_SIZE ];      // holds array of recordIndices 
  pthread_rwlock_t leaf_rwlock;             // controls entries on this leaf 
} indexLeaf_t;

struct index {
  indexLeaf_t  **idxLeaf;                   // array of pointers to leaf node
  uint32_t nLeafs;                          // total number of leaf nodes
  uint64_t capacity;                        // number of entries we can hold 
  uint64_t entries;                         // number of entries we have 
};

/******************************************************************************
 * FUNCTION IMPLEMENTATIONS
 *****************************************************************************/
int 
index_init( index_t **this_p, uint64_t live_cnt, uint64_t min_capacity ) 
{
    // if user sets capacity at zero, we'll use our default value
    if ( min_capacity == 0 ) {
      min_capacity = INIT_CAPACITY;
    }
    // if user does not give us the required power of two...
    if ( min_capacity & ( min_capacity - 1 )) {
      TLOG_INFO( "WARNING: user supplied min_capacity %"PRIu64""
                 "not a power of 2", min_capacity );
      min_capacity = INIT_CAPACITY;
    }

    //TLOG_TRACE( "%s", db->file_name );
    *this_p = NULL;                         // init answer 

    // allocate memory for data struct
    index_t *this = (index_t *)malloc( sizeof( index_t ));      

    if ( this == NULL ) {
      ERR_RET( "malloc of %ld bytes for index failed", sizeof( index_t ));
      return FREQ_DB_SYS_ERR_MALLOC;
    }

    // initialize the structure 
    this->nLeafs=0;
    this->idxLeaf=NULL;
    this->capacity = 0;
    this->entries = 0;

    uint64_t minInitCapacity = 2 * live_cnt;    // 2x 
    uint64_t nLeafs = min_capacity/IDX_LEAF_SIZE;
    uint64_t capacity = nLeafs * IDX_LEAF_SIZE;
    uint64_t i, j;

    // make capacity at least twice as big as what we need 
    while ( capacity < minInitCapacity ) {
      nLeafs = nLeafs << 1;
      capacity = capacity << 1;
    }

    // allocate memory for leaf array and init data elements
    this->nLeafs = nLeafs;
    this->idxLeaf = (indexLeaf_t**)malloc(nLeafs * sizeof(indexLeaf_t*));
    this->capacity = capacity;

    if ( this->idxLeaf == NULL ) {
      free( this );                         // clean up
      ERR_RET( "malloc of %ld bytes for index failed",
               nLeafs * sizeof(indexLeaf_t*));
      return FREQ_DB_SYS_ERR_MALLOC;
    }

    // allocate memory for each leaf and initialize it
    for ( i=0 ; i < nLeafs; i++ ) {
      this->idxLeaf[i] = ( indexLeaf_t* )malloc( sizeof( indexLeaf_t ));

      // if couldn't malloc, clean up and exit
      if ( this->idxLeaf[i] == NULL ) {
        for ( j = i; j > 0 ; j-- ) {
          free( this->idxLeaf[j-1] );
        }
        free( this->idxLeaf );
        free( this );
        ERR_RET( "malloc of %ld bytes for index failed", sizeof( indexLeaf_t ));
        return FREQ_DB_SYS_ERR_MALLOC;
      }
      memset( this->idxLeaf[i], ~0, sizeof( indexLeaf_t ));
      Pthread_rwlock_init( &this->idxLeaf[i]->leaf_rwlock, NULL );
    }

    TLOG_TRACE( "capacity: %"PRIu64"",this->capacity );
    *this_p = this; 
    return FREQ_DB_SUCCESS;
}

/******************************************************************************
 * INDEX_INSERT
 *****************************************************************************/
int index_insert( index_t *this, off_t freqHdrOffset, uint64_t hashcode)
{
    off_t empty = ~0;           // special value TODO: move into struct 
    uint8_t attempts = 0;
    // find which leaf node this entry should be put into
    uint64_t mask = (this->nLeafs - 1) << NBITS;          
    uint64_t leaf = (hashcode & mask) >> NBITS;    
    indexLeaf_t * leafPtr= this->idxLeaf[leaf];

    // find initial position within leaf
    uint64_t positionMask = ( 0x1 << NBITS ) - 1;     
    uint64_t position = (hashcode & positionMask);

    Pthread_rwlock_wrlock( &(leafPtr->leaf_rwlock) );      // lock this leaf

    // linear probing to find first avail slot..
    while (leafPtr->entry[position].hdr_offset != empty) {
      position = (position + 1) & positionMask;
      if ( ++attempts == IDX_MAX_INSERT_ATTEMPTS ) {
        TLOG_DEBUG( "max collisions reached: %u", IDX_MAX_INSERT_ATTEMPTS );
        Pthread_rwlock_unlock( &(leafPtr->leaf_rwlock) );  // unlock the leaf
        return FREQ_DB_ERR_IDX_COLLISIONS;
      }
    }

    // we found a spot for it.. now populate entry 
    leafPtr->entry[position].hashkey = hashcode;
    leafPtr->entry[position].hdr_offset = freqHdrOffset;

    Pthread_rwlock_unlock( &(leafPtr->leaf_rwlock) );      // unlock the leaf
    this->entries++;

    return FREQ_DB_SUCCESS;
}

/******************************************************************************
 * INDEX_EXPAND - doubles the capacity of the index and re-inserts existing 
 *  NOTES:  someone may have a pointer to data in a leaf, so a leaf writelock
 *          must be acquired 
 *****************************************************************************/
int index_expand( index_t *this )
  {
    TLOG_TRACE( "current size: %"PRIu64"", this->capacity );
    TLOG_INFO( "current size: %"PRIu64"", this->capacity );  //TODO: keep?

    off_t empty = ~0;                  // special value TODO: move into struct 
    uint32_t i,j,k;                    // counter for number of old leaf
    int res;

    index_t oldIndex = *this;      // temp place to hold the info
    this->nLeafs = oldIndex.nLeafs << 1;     // double number of leafs
    this->capacity = oldIndex.capacity << 1;
    this->idxLeaf = NULL;
    this->entries = 0;

    // malloc space for index array for leaf pointers..
    this->idxLeaf =
     (indexLeaf_t**)malloc(this->nLeafs * sizeof(indexLeaf_t*));

    if (this->idxLeaf == NULL ) {
      *this = oldIndex;            // restore state and exit
      ERR_RET( "malloc of %ld bytes for index failed",
               this->nLeafs * sizeof(indexLeaf_t*));
      return FREQ_DB_SYS_ERR_MALLOC;
    }

    // split each existing leaf into two new ones... 
    for (i=0; i < oldIndex.nLeafs; i++) {
      j = i + oldIndex.nLeafs;         // leaf splits to another nLeafs away

      // malloc two new leaf
      this->idxLeaf[i] = ( indexLeaf_t* )malloc( sizeof( indexLeaf_t ));
      this->idxLeaf[j] = ( indexLeaf_t* )malloc( sizeof( indexLeaf_t ));

      if ((this->idxLeaf[i] == NULL) || (this->idxLeaf[j] == NULL)) {
        // TODO:  figure way to die gracefully and continue instead of quitting
        ERR_QUIT( "malloc of %ld bytes for index failed", sizeof( indexLeaf_t ));
        return FREQ_DB_SYS_ERR_MALLOC;
      }

      memset( this->idxLeaf[i], ~0, sizeof( indexLeaf_t ));
      memset( this->idxLeaf[j], ~0, sizeof( indexLeaf_t ));

      Pthread_rwlock_init( &this->idxLeaf[i]->leaf_rwlock, NULL );
      Pthread_rwlock_init( &this->idxLeaf[j]->leaf_rwlock, NULL );

      // writelock old leaf to force out any readers... 
      Pthread_rwlock_wrlock( &(oldIndex.idxLeaf[i]->leaf_rwlock) );
      // move each old leaf element into new leaf
      for ( k = 0; k < IDX_LEAF_SIZE; k++ ) {
        if ( oldIndex.idxLeaf[i]->entry[k].hdr_offset != empty ) {
          res = index_insert( this, oldIndex.idxLeaf[i]->entry[k].hdr_offset,
                              oldIndex.idxLeaf[i]->entry[k].hashkey );
          if ( res != FREQ_DB_SUCCESS ) {
            // TODO:  figure way to die gracefully instead of quitting
            // though, this will never happen.
            // TODO: put err messag
           ERR_QUIT( "during expand, index_insert failed: halting %d", res);
           //          db->file_name, res );
            return res;
          }
        }
      }
      // we're done with this leaf.. so unlock and destroy lock
      Pthread_rwlock_unlock( &(oldIndex.idxLeaf[i]->leaf_rwlock) );
      Pthread_rwlock_destroy( &(oldIndex.idxLeaf[i]->leaf_rwlock) );
      free(oldIndex.idxLeaf[i]);       // free old leaf
    }

    free(oldIndex.idxLeaf);            // free old index array

    TLOG_TRACE( "new size %"PRIu64"", this->capacity );
    TLOG_INFO( "new size %"PRIu64"", this->capacity );     //TODO: keep?
    return FREQ_DB_SUCCESS;
  }


/******************************************************************************
 * INDEX_DESTROY - wipes out index data structure.  Frees all associated mem
 *****************************************************************************/
void index_destroy( index_t *this )
  {
    //TLOG_TRACE( "doing the deed on: %s", db->file_name );

    uint64_t i;

    // free each leaf 
    for ( i = 0; i < this->nLeafs; i++ ) {
      Pthread_rwlock_destroy( &this->idxLeaf[i]->leaf_rwlock );
      free(this->idxLeaf[i]);
    }

    // free leaf pointer array
    free(this->idxLeaf);
    this->idxLeaf = (indexLeaf_t **)NULL;
    this->nLeafs = 0;
    this->entries = 0;
    this->capacity = 0;

    TLOG_TRACE( "done", NULL );
  }

/******************************************************************************
 * INDEX_FIND
 *****************************************************************************/
int
index_find( index_t *this, const char *base, freq_type_t *type,
            const char *key, uint16_t key_sz, record_portal_t *freqRecord )
  {
    off_t empty = ~0;               // special value TODO: move into struct
    uint64_t hashcode = type_key_hash( type, key, key_sz );
    freq_header_t *fHdrPtr;

    uint8_t attempts = 0;
    // find which leaf node this entry should be put into
    uint64_t mask = (this->nLeafs - 1) << NBITS;
    uint64_t leaf = (hashcode & mask) >> NBITS;  
    indexLeaf_t * leafPtr= this->idxLeaf[leaf];

    // find position within leaf
    uint64_t positionMask = ( 0x1 << NBITS ) - 1;
    uint64_t position = (hashcode & positionMask);

    //mmap_readlock( db );
    Pthread_rwlock_rdlock( &(leafPtr->leaf_rwlock) );      // lock this leaf

    // linear probing. 
    while ( attempts++ < IDX_MAX_INSERT_ATTEMPTS ) {
      // if slot has something in it
      if (leafPtr->entry[position].hdr_offset != empty) {
        // check if hashcode matches
        if (leafPtr->entry[position].hashkey == hashcode) {
          // now check that the entire key matches as well
          fHdrPtr =
              (freq_header_t*)(base + leafPtr->entry[position].hdr_offset);
          const char *rec_key = freq_get_key( fHdrPtr );

          if ( type_key_cmp( type, key, key_sz,
                             &fHdrPtr->type, rec_key, fHdrPtr->key_sz ) == 0 ) {
            freqRecord->hdr_offset = &(leafPtr->entry[position].hdr_offset);
            freqRecord->rwlockPtr = &(leafPtr->leaf_rwlock);

            Pthread_rwlock_unlock( &(leafPtr->leaf_rwlock) );      // unlock
            //mmap_unlock( db );

            return FREQ_DB_SUCCESS;
          }
        }
      }
      // we either didn't match the hashcode or the key, so keep trying..
      position = (position + 1) & positionMask;
    }
    // we've run out of tries and haven't found it..
    Pthread_rwlock_unlock( &(leafPtr->leaf_rwlock) );      // unlock the leaf
    //mmap_unlock( db );

    return FREQ_DB_NOTFOUND;
  }

/******************************************************************************
 * INDEX_REMOVE
 *****************************************************************************/
int
index_remove( index_t *this, const char *base, freq_type_t *type,
            const char *key, uint16_t key_sz )
  {
    off_t empty = ~0;               // special value TODO: move into struct
    uint64_t hashcode = type_key_hash( type, key, key_sz );
    freq_header_t *fHdrPtr;
    uint8_t attempts = 0;

    // find which leaf node this entry should be put into
    uint64_t mask = (this->nLeafs - 1) << NBITS; 
    uint64_t leaf = (hashcode & mask) >> NBITS;   
    indexLeaf_t * leafPtr= this->idxLeaf[leaf];

    // find position within leaf
    uint64_t positionMask = ( 0x1 << NBITS ) - 1;
    uint64_t position = (hashcode & positionMask);

    //mmap_readlock( db );
    Pthread_rwlock_wrlock( &(leafPtr->leaf_rwlock) );      // lock this leaf

    // linear probing. 
    while ( attempts++ < IDX_MAX_INSERT_ATTEMPTS ) {
      // if slot has something in it
      if (leafPtr->entry[position].hdr_offset != empty) {
        // check if hashcode matches
        if (leafPtr->entry[position].hashkey == hashcode) {
          // now check that the entire key matches as well
          fHdrPtr =
             (freq_header_t*) (base + leafPtr->entry[position].hdr_offset);
          const char *rec_key = freq_get_key( fHdrPtr );

          if ( type_key_cmp( type, key, key_sz,
                             &fHdrPtr->type, rec_key, fHdrPtr->key_sz ) == 0 ) {
                leafPtr->entry[position].hdr_offset = empty;
                leafPtr->entry[position].hashkey = empty;

                Pthread_rwlock_unlock( &(leafPtr->leaf_rwlock) );      // unlock
                //mmap_unlock( db );
                this->entries--;
                return FREQ_DB_SUCCESS;
          }
        }
      }
      // we either didn't match the hashcode or the key, so keep trying..
      position = (position + 1) & positionMask;
    }
    // we've run out of tries and haven't found it..

    Pthread_rwlock_unlock( &(leafPtr->leaf_rwlock) );      // unlock
    //mmap_unlock( db );
    return FREQ_DB_NOTFOUND;
  }


/******************************************************************************
 *                                                              *
 *****************************************************************************/
float
index_get_load_factor( index_t *this )
{
  return ( (float)this->entries / this->capacity );
}

/******************************************************************************
 *                                                               *
 *****************************************************************************/
uint64_t
index_get_capacity( index_t *this )
{
  return (this->capacity);
}


/******************************************************************************
 * Key Functions                                                              *
 *****************************************************************************/

uint64_t
type_key_hash( freq_type_t *type, const char *key, uint16_t key_sz )
  {
    uint32_t upper = 0, lower = 0;

    // First hash the type
    hashlittle2( type, sizeof(freq_type_t), &lower, &upper );

    // Now add the hash of the key
    hashlittle2( key, key_sz, &lower, &upper );

    // Now combine the two 32bit values for a single 64 bit hash
    uint64_t hash = lower + (((uint64_t)upper)<<32);

    return hash;
  }

int
type_key_cmp( freq_type_t *type1, const char *key1, uint16_t key1_sz,
              freq_type_t *type2, const char *key2, uint16_t key2_sz )
  {
    if ( type1 == NULL || type2 == NULL ) return -1;
    if ( key1 == NULL || key2 == NULL ) return -1;
    if ( key1_sz < key2_sz ) return -1;
    if ( key1_sz > key2_sz ) return 1;
    int type_cmp = freq_type_cmp( type1, type2 );
    if ( type_cmp != 0 ) return type_cmp;
    return strncmp( key1, key2, key1_sz );
  }
