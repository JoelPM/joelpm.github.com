#include "record_portal.h"

/******************************************************************************
 * Functions 
 *****************************************************************************/
void
record_move_to( record_portal_t *record_portal, off_t new_offset)
{
  *(record_portal->hdr_offset) = new_offset;
}

freq_header_t *
get_record_header( record_portal_t *record_portal, const char *base )
{
    return (freq_header_t*) (base + *(record_portal->hdr_offset));
}

void
record_readlock( record_portal_t *record_portal )
{
  Pthread_rwlock_rdlock( record_portal->rwlockPtr );
}

void
record_writelock( record_portal_t *record_portal )
{
  Pthread_rwlock_wrlock( record_portal->rwlockPtr );
}

void
record_unlock( record_portal_t *record_portal )
{
  Pthread_rwlock_unlock( record_portal->rwlockPtr );
}

