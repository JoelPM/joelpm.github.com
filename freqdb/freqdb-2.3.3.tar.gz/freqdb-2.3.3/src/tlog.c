#include <inttypes.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <time.h>
#include "tlog.h"

//#define TRACE
//#define DEBUG

#define MAXLINE 2047

static void
do_log( const char *fnc, const char *fmt, va_list ap );

inline void
tlog_trace( const char *fnc, const char *fmt, ... )
  {
#ifdef TRACE 
    va_list ap;
    va_start( ap, fmt );
    do_log( fnc, fmt, ap );
    va_end( ap );
#else
    (void)fnc; /* appease -Wall -Werror */
    (void)fmt; /* appease -Wall -Werror */
#endif
  }

inline void
tlog_debug( const char *fnc, const char *fmt, ... )
  {
#ifdef DEBUG
    va_list ap;
    va_start( ap, fmt );
    do_log( fnc, fmt, ap );
    va_end( ap );
#else
    (void)fnc; /* appease -Wall -Werror */
    (void)fmt; /* appease -Wall -Werror */
#endif
  }

inline void
tlog_info( const char *fnc, const char *fmt, ... )
  {
    va_list ap;
    va_start( ap, fmt );
    do_log( fnc, fmt, ap );
    va_end( ap );
  }

static void
do_log( const char *fnc, const char *fmt, va_list ap )
  {
    char buf[MAXLINE + 1];

    time_t now = time( NULL );
    size_t n = strftime( buf,
                         MAXLINE,
                         "%m/%d/%Y %H:%M:%S ",
                         localtime(&now) );

    pthread_t tid = pthread_self();
    n += snprintf( buf + n, MAXLINE - n, "[%"PRIu64"] %s: ", (uint64_t)tid, fnc );

    vsnprintf( buf + n, MAXLINE - n, fmt, ap );

    strcat( buf, "\r\n" );

    fflush( stdout );
    fputs( buf, stderr );
    fflush( stderr );
  }
