#include <inttypes.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <assert.h>

#include "freq_db.h"
#include "freq_type.h"
#include "freq_count.h"
#include "freq.h"
#include "tlog.h"
 
#include "pthreadwrappers.h" 

#define NTHREADS 5
#define NFREQS 10000000                // number of freqs to create per thread
#define MAX 32                         // max string length
#define MIN 20                         // min string length
#define NKEYS 1000                     // num keys to increment 0
#define MAX_OPS 500000000

// PROTOTYPES
void *threadRunner(void *threadID); 
void *gcThreadRunner( void *in );
void gen_random(char *s, const int len);

//DATA STRUCTS
typedef struct threadInfo {
  freq_db_t *db;
  int threadID;
  pthread_mutex_t *screenLock;
  uint64_t *n_ops;                      // number of operations on DB
  pthread_mutex_t *n_ops_lock;         // lock to protext n_ops
  int *time_to_quit;                    // way to signal threads to quit
} threadInfo_t;
 
typedef struct threadReturnInfo {
  uint64_t n_insertions;
  uint64_t n_deletions;
  uint64_t n_increments; 
  uint64_t n_count_checks;
  uint64_t n_errors;
} threadReturnInfo_t;

typedef struct gcThreadInfo {
  freq_db_t *db;
  int *time_to_quit;
  pthread_mutex_t *screenLock;
} gcThreadInfo_t;

/******************************************************************************
* MAIN
******************************************************************************/
int main (void)
{
  const char *fname = "./freqserver.fdb";
  freq_db_t *db = NULL;

  pthread_mutex_t screenLock; 
  pthread_mutex_t n_ops_lock;

  threadInfo_t ti[NTHREADS];
  pthread_t thread[NTHREADS];
  
  gcThreadInfo_t gc_ti;
  pthread_t gc_thread;

  int i;
  threadReturnInfo_t *status[NTHREADS];
  int gc_status;
  int retCode;
  uint64_t n_ops = 0;                  // counter
  int time_to_quit = 0;
  uint64_t n_insertions = 0;
  uint64_t n_deletions = 0;
  uint64_t n_increments = 0;
  uint64_t n_count_checks = 0;
  uint64_t n_errors = 0;

  Pthread_mutex_init( &screenLock, NULL );
  Pthread_mutex_init( &n_ops_lock, NULL );

  srand(time(NULL));

  fprintf (stderr, "opening db...");
  retCode = freq_db_open( &db, fname, 1024 * 1024 );
  fprintf (stderr, "done %d\n", retCode);
 
  // create all the threads
  for (i = 0; i < NTHREADS; i++) {
    ti[i].db = db;
    ti[i].threadID = i;
    ti[i].screenLock = &screenLock;
    ti[i].n_ops = &n_ops;
    ti[i].n_ops_lock = &n_ops_lock;
    ti[i].time_to_quit = &time_to_quit;
    
    retCode = pthread_create(&thread[i], NULL, threadRunner, (void *)&ti[i]);
    if (retCode) {
      fprintf(stderr,"ERROR: pthread create failed \n");
      exit(retCode);
    }
  }  
  
  gc_ti.db = db; 
  gc_ti.time_to_quit = &time_to_quit;
  gc_ti.screenLock = &screenLock;

  retCode = pthread_create( &gc_thread, NULL, gcThreadRunner, (void *)&gc_ti );
  if (retCode) {
    fprintf(stderr,"ERROR: garbage collector pthread create failed \n");
    exit(retCode);
  }

  for ( i = 0; i < NTHREADS; i++ ) {
    retCode = pthread_join( thread[i], (void *) &status[i] );
  }

  time_to_quit = 1;

  retCode = pthread_join( gc_thread, (void *) &gc_status );
 
  for ( i = 0; i < NTHREADS; i++ ) {
    n_insertions += status[i]->n_insertions;
    n_deletions += status[i]->n_deletions;
    n_increments += status[i]->n_increments;
    n_count_checks += status[i]->n_count_checks;
    n_errors += status[i]->n_errors;
    free(status[i]);
  }

  fprintf(stderr,"GRAND TOTALS:\n nInsertions: %"PRIu64"\n nDeletions: %"PRIu64"\n"
                 " nIncrements: %"PRIu64"\n nCountChecks: %"PRIu64"\n nErrors: %"PRIu64"\n", 
                 n_insertions, n_deletions, n_increments, 
                 n_count_checks, n_errors);
  fprintf (stderr, "closing db..." );
  retCode = freq_db_close( db );
  fprintf (stderr, "done %d\n", retCode );

  return 0;
}

/******************************************************************************
* This thread will run the garbage collector until "time_to_quit" flag set
* in main
******************************************************************************/
void *gcThreadRunner( void *in )
{
  gcThreadInfo_t *ti = (gcThreadInfo_t *) in;    // get input into thread
  freq_db_t *db = ti->db;
  int *time_to_quit = ti->time_to_quit;

  freq_db_gc_stats_t stats;
  int retCode;
  uint64_t n_runs = 0;                           // how many time GC ran
  uint64_t n_deletions = 0;                      // how many freqs deleted
  
  Pthread_mutex_lock(ti->screenLock);
  fprintf(stderr,"GC THREAD created\n");
  Pthread_mutex_unlock(ti->screenLock);
 
  while ( *time_to_quit == 0 ) { 
    Pthread_mutex_lock(ti->screenLock);
    fprintf(stderr,"GC starting\n");
    Pthread_mutex_unlock(ti->screenLock);
    retCode = freq_db_gc( db, &stats );
    n_runs++;
    n_deletions += stats.collected_freqs;
  }

  Pthread_mutex_lock(ti->screenLock);
  fprintf(stderr,"GC finished.  Ran %"PRIu64" times.  Collected %"PRIu64" freqs\n",
          n_runs, n_deletions);
  Pthread_mutex_unlock(ti->screenLock);

  pthread_exit(NULL);
}


/******************************************************************************
* This thread will randomly create a bunch of keys to insert, increment, and
* delete.
******************************************************************************/
void *threadRunner(void *in) 
{
  threadReturnInfo_t *trip;	
  trip = (threadReturnInfo_t *)malloc(sizeof(threadReturnInfo_t));
  uint8_t len;                         // length of random string
  freq_type_t type;
  int retCode;
  char currentKey[MAX+1];              // storage for rand key generator
  currentKey[MAX] = '\0';              // ensure null terminated
  threadInfo_t *ti = (threadInfo_t *) in;  
  //float fraction = (float)NKEYS/NFREQS;   // percent of keys to keep
  uint8_t flag = 0;
  char *key[NKEYS];                    // array of pointers to keys
  uint64_t i;
  uint64_t num_stored_keys = 0;        // num we've stored off
  uint64_t num_delete_keys = 0;        // num keys we've deleted
  uint64_t key_cnt[NKEYS];             // true counts for each stored key
  uint64_t n_ops = 0;                  // num ops this thread done..
  uint64_t n_insertions = 0;
  uint64_t n_increments = 0;
  uint64_t n_deletions = 0;
  uint64_t n_count_checks = 0;
  uint64_t n_freqs = 0;                // num freqs this thread created
  uint64_t n_errors = 0;               // num errors encountered

  freq_count_t count;
  int tid = ti->threadID;
  freq_db_t *db = ti->db;

  type.interval_cnt = 1;
  type.interval_mins = 129600;
  type.interval_bits = 16;
 
  for ( i=0; i < NKEYS; i++ ) {
    key[i] = NULL;
    key_cnt[i] = 0;
  }

  Pthread_mutex_lock(ti->screenLock);
  fprintf(stderr,"TID %d created\n",tid);
  Pthread_mutex_unlock(ti->screenLock);
 
  while( n_ops < MAX_OPS) {            // do work until time_to_quit flag hits
    // also look if we have room to store a test key.  If so, store it.
    if ( n_freqs < NFREQS ) {
      // generate a random key length
      len = (uint8_t)((float)rand()*(MAX-MIN)/(float)RAND_MAX  + MIN);
      gen_random(currentKey, len);
      retCode = freq_db_increment( db, &type, currentKey, len+1, 0);
      switch ( retCode ) {
        case FREQ_DB_CREATED:
          n_insertions++;
          n_freqs++;
          // if we have room for more stored keys
          if (num_stored_keys < NKEYS) {
            // gen random number to see if we keep this one
            //flag = ((float)rand()/RAND_MAX < 2.0 * fraction);
            // if it falls in interval 0-fraction, we'll keep it.
            //if ( flag || num_stored_keys == 0) 
            for ( i=0; i < NKEYS; i++) {
              // find first open slot
              if ( key[i] == NULL ) {
                break;
              }
            }
            // go get mem to store it
            key[i] = (char*)malloc(strlen(currentKey)+1);
            if (key[i] == NULL) {
              fprintf(stderr,"TEST malloc failed\n");
            } else {
              strcpy(key[i], currentKey);
              key_cnt[i] = 1;
              num_stored_keys++;
              //fprintf(stderr,"TID %d: %32s key %lu stored \n",tid,key[i],i);
            }
          } 
          break;
        case FREQ_DB_SUCCESS:
          n_increments++;
          fprintf(stderr,"TID %d: WARNING - duplicate %32s\n",tid,currentKey);
          break;
        default:
          fprintf(stderr,"TID %d: ERROR - couldnt create %32s code: %d\n",                                         tid,currentKey, retCode);
       
      }
    }

    // Now, see if we should delete one.  
    // gen random number to see if we one
    flag = ((float)rand()/RAND_MAX < 0.3);
    // if it falls in interval 0-fraction we'll delete it.
    if (flag) {
      i = (uint64_t)( (float)NKEYS * rand() / ((float)RAND_MAX + 1.0));

      if (key[i] != NULL ) {                // there's a key there..
        // check it's value matches first... just for fun
        retCode = freq_db_count( db, &type, key[i], strlen(key[i])+1 ,2, 0, &count );
        n_count_checks++;
        if (key_cnt[i] != count.value) {
          Pthread_mutex_lock(ti->screenLock);
          fprintf(stderr,"TID %d: %32s Delete Key ERROR - count mismatch\n", tid,key[i]);
          n_errors++;
          Pthread_mutex_unlock(ti->screenLock);
        }
        
        // Now delete it..
        retCode = freq_db_delete( db, &type, key[i], strlen(key[i])+1);
        // if delete successful, update stuff
        if (retCode == FREQ_DB_SUCCESS) {
          n_deletions++;
         // fprintf(stderr,"TID %d: %32s key %lu removed\n",tid,key[i],i); //TODO:
          free( key[i] );                   // free mem
          key[i] = NULL;
          key_cnt[i] = 0;                    // make avail for new key
          n_freqs--;                        // increment/decrement counters
          num_stored_keys--;    
          num_delete_keys++;
        } else {
          Pthread_mutex_lock(ti->screenLock);
          fprintf(stderr,"TID %d: %32s key %"PRIu64" ERROR: couldnt delete\n",tid,key[i], i);
          Pthread_mutex_unlock(ti->screenLock);
          n_errors++; 
        }
      }
    }

    // now, see if we should increment one
    //flag = ((float)rand()/RAND_MAX < 3*fraction);
    
    // if it falls in interval 0-incr_fraction we'll increment it.
    if (!flag) {
      i = (uint64_t)( (float)NKEYS * rand() / ((float)RAND_MAX + 1.0));

      if ( key[i] != NULL ) {
        retCode = freq_db_increment( db, &type, key[i], strlen(key[i])+1, 0);
        if ( retCode == FREQ_DB_SUCCESS ) { 
          n_increments++;
          //fprintf(stderr,"TID %d: %32s key %lu increment\n",tid,key[i],i); //TODO:
          key_cnt[i]++;
          retCode = freq_db_count( db, &type, key[i], strlen(key[i])+1 ,2, 0, &count );
          n_count_checks++;
          Pthread_mutex_lock(ti->screenLock);
          //fprintf(stderr,"TID %d: %32s Key %lu count: true: %lu  DB: %lu\n",
          //        tid, key[i], i, key_cnt[i], count.value );
          if (key_cnt[i] != count.value) {
            fprintf(stderr,"TID %d: ERROR - count mismatch\n", tid);
            n_errors++;
          }
          Pthread_mutex_unlock(ti->screenLock);
        } else {
          Pthread_mutex_lock(ti->screenLock);
          fprintf(stderr,"TID %d: %32s key %"PRIu64" ERROR: failed increment\n",tid,key[i],i);
          Pthread_mutex_unlock(ti->screenLock);
          n_errors++;
        }
      }
    }
    n_ops = n_insertions + n_deletions + n_increments + n_count_checks;
    if ( (4 * n_ops) % MAX_OPS == 0 ) {
      Pthread_mutex_lock(ti->screenLock);
      fprintf(stderr,"TID %d: UPDATE %"PRIu64" percent complete\n",tid,(100 * n_ops)/MAX_OPS);
      Pthread_mutex_unlock(ti->screenLock);
    }
  }      
 
  for (i = 0; i < NKEYS; i++ ) {
    if (key[i] != NULL ) {
      retCode = freq_db_count( db, &type, key[i], strlen(key[i])+1 ,2, 0, &count );
      n_count_checks++;
      if (key_cnt[i] != count.value) {
        Pthread_mutex_lock(ti->screenLock);
        fprintf(stderr,"TID %d: ERROR - count mismatch\n", tid);
        Pthread_mutex_unlock(ti->screenLock);
        n_errors++;
      }
      free(key[i]);
    }
  }
  Pthread_mutex_lock(ti->screenLock);
  //fprintf(stderr,"TID %d: finished checking keys\n", tid);
  fprintf(stderr,"TID %d: EXIT nfreqs: %"PRIu64"  nInsertions: %"PRIu64"  nDeletions: %"PRIu64""
                 " nIncrements: %"PRIu64"  nCountChecks: %"PRIu64" nErrors: %"PRIu64"\n",
                 tid, n_freqs, n_insertions, n_deletions, 
                 n_increments, n_count_checks, n_errors);
  Pthread_mutex_unlock(ti->screenLock);
 

  trip->n_insertions = n_insertions;
  trip->n_deletions = n_deletions;
  trip->n_increments = n_increments;
  trip->n_count_checks = n_count_checks;
  trip->n_errors = n_errors;

  pthread_exit(trip);
}

/******************************************************************************
* gen_random
*  INPUTS:  char *s - pointer to preallocated storage for a random string
*           int len - length of string to create.  Assumes enough storage
*  OUTPUTS: none.  passed in storage is populated with random string
******************************************************************************/
void gen_random(char *s, const int len) {
  assert(len <= MAX);
  static const char alphanum[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
  int i;
  int N = sizeof(alphanum) - 1;

  for (i = 0; i < len; ++i) {
    s[i] = alphanum[(int)((double)rand()/((double)RAND_MAX + 1) * N)];
  }

  s[len] = '\0';
}

