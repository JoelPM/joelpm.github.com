#include <inttypes.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>

#include "freq_db.h"
#include "freq_type.h"
#include "freq_count.h"
#include "freq.h"
#include "tlog.h"

// This single threaded tests open, close, GC, increment, delete, and count.
// Sequence is as follows:  i
//  will open (or create) freqserver.fdb. 
//  ins keys 1&2, check cnt, rem key2, ins key2, check cnt, rem key2, close.
//  open, ins key3 and incr N times. Run GC, check cnt, close
//  open, incr Key3 N times, check cnt, close
int main (void)
{
    const char *test_key1 = "testmX";
    const char *test_key2 = "bitemX";
    const char *test_key3 = "lovemX";
    const char *fname = "./freqserver.fdb";
   
    freq_type_t type;
    type.interval_cnt = 1;
    type.interval_mins = 129600;
    type.interval_bits = 16;

    int i = 0;
    uint8_t nIncrements = 3;
  
    freq_db_gc_stats_t gcStats;
    freq_count_t count;
    
    uint16_t key_sz1 = strlen( test_key1 );
    uint16_t key_sz2 = strlen( test_key2 );
    uint16_t key_sz3 = strlen( test_key3 );
 
    freq_db_t *db = NULL;
  
    // OPEN DB
    fprintf (stderr, "\n\n\nopening db...\n");
    int result = freq_db_open( &db, fname, 1024 * 1024 );
    if ( result != FREQ_DB_SUCCESS  && result != FREQ_DB_CREATED ) {
      fprintf(stderr,"ERROR: could not open %s.  Code: %d\n",fname,result);
      exit(1);
    } else {
      fprintf (stderr, "done %d\n", result);
    }
    
    // INCREMENT keys 1 & 2
    for ( i = 0; i < nIncrements; i++ ) {
        result = freq_db_increment( db, &type, test_key1, key_sz1, 0 );
   
        if (result == FREQ_DB_SUCCESS || result == FREQ_DB_CREATED ) {
          fprintf( stderr, "SUCCESS. Incremented key 1: %s\n",test_key1 );
        } else {
          fprintf( stderr,"ERROR: increment on key 1: %s code %d\n",
                  test_key1, result );
        }

        sleep (0.1);

        result = freq_db_increment( db, &type, test_key2, key_sz2, 0 );

        if (result == FREQ_DB_SUCCESS || result == FREQ_DB_CREATED ) {
          fprintf( stderr, "SUCCESS. Incremented key 2: %s\n",test_key2 );
        } else {
          fprintf( stderr,"ERROR: increment on key 2: %s code %d\n",
                  test_key2, result );
        }

        sleep (0.1);
      }

    // COUNT keys 1 & 2 
    result = freq_db_count( db, &type, test_key1, key_sz1, 2, 0, &count );
    fprintf (stderr, "COUNT: {%d %d %d} last_update_min: %"PRIu64" %s value: "
                     "%"PRIu64"\n", type.interval_cnt, type.interval_mins,
                     type.interval_bits, count.last_update_min, 
                     test_key1, count.value);

    result = freq_db_count( db, &type, test_key2, key_sz2, 129600, 0, &count );
    fprintf (stderr, "COUNT: {%d %d %d} last_update_min: %"PRIu64" %s value: " 
                     "%"PRIu64"\n", type.interval_cnt, type.interval_mins,
                     type.interval_bits, count.last_update_min,
                     test_key2, count.value);

    // REMOVE key 2 
    result = freq_db_delete( db, &type, test_key2, key_sz2);
    if (result == FREQ_DB_SUCCESS ) {
      fprintf(stderr,"REMOVED key 2: %s\n",test_key2);
    } else { 
      fprintf(stderr,"ERROR removing key 2: %s code: %d\n", test_key2,result);
    }
   
    // INCREMENT key 2    should get in insert. 
    fprintf(stderr,"INCREMENTING key 2: %s\n", test_key2);
    result = freq_db_increment( db, &type, test_key2, key_sz2, 0 );
    if (result == FREQ_DB_SUCCESS || result == FREQ_DB_CREATED ) {
      fprintf( stderr, "SUCCESS. Incremented key 2: %s\n",test_key2 );
    } else {
      fprintf( stderr,"ERROR: increment on key 2: %s code %d\n",
              test_key2, result );
    }
    result = freq_db_count( db, &type, test_key2, key_sz2, 129600, 0, &count );
    fprintf (stderr, "COUNT: {%d %d %d} last_update_min: %"PRIu64" %s value: " 
                     "%"PRIu64"\n", type.interval_cnt, type.interval_mins,
                     type.interval_bits, count.last_update_min,
                     test_key2, count.value);
 
    // REMOVE key 2, again
    result = freq_db_delete( db, &type, test_key2, key_sz1);
    if (result == FREQ_DB_SUCCESS ) {
      fprintf(stderr,"REMOVED key 2: %s\n",test_key2);
    } else {
      fprintf(stderr,"ERROR removing key 2: %s code: %d\n", test_key2,result);
    }
 
    // CLOSE 
    fprintf (stderr, "CLOSING db..." );
    result = freq_db_close( db );
    if (result != FREQ_DB_SUCCESS) {
      fprintf(stderr,"ERROR: did not properly close  %s.  Code: %d\n",
                     fname,result);
      exit(1);
    } else {
      fprintf (stderr, "CLOSE done %d\n", result);
    }
  
    //  OPEN 
    fprintf (stderr, "\n\n\nopening db...\n");
    result = freq_db_open( &db, fname, 1024 * 1024 );
    if (result != FREQ_DB_SUCCESS) {
      fprintf(stderr,"ERROR: could not open %s.  Code: %d\n",fname,result);
      exit(1);
    } else {
      fprintf (stderr, "done %d\n", result);
    }
 
    // INCREMENT key 3 
    for ( i = 0; i < nIncrements; i++ ) {
      result = freq_db_increment( db, &type, test_key3, key_sz3, 0 );
      if (result == FREQ_DB_SUCCESS || result == FREQ_DB_CREATED ) {
        fprintf( stderr, "SUCCESS. Incremented key 3: %s\n",test_key3 );
      } else {
        fprintf( stderr,"ERROR: increment on key 3: %s code %d\n",
                test_key3, result );
      }

      sleep (0.1);
    }
 
    // GARBAGE COLLECTION 
    fprintf (stderr, "Garbage Collection\n");
    freq_db_gc( db, &gcStats );

    // CHECK COUNTS
    result = freq_db_count( db, &type, test_key1, key_sz1, 2, 0, &count );
    fprintf (stderr, "COUNT: {%d %d %d} last_update_min: %"PRIu64" %s value: " 
                     "%"PRIu64"\n", type.interval_cnt, type.interval_mins,
                     type.interval_bits, count.last_update_min,
                     test_key1, count.value);

    result = freq_db_count( db, &type, test_key3, key_sz3, 129600, 0, &count );
    fprintf (stderr, "COUNT: {%d %d %d} last_update_min: %"PRIu64" %s value: " 
                     "%"PRIu64"\n", type.interval_cnt, type.interval_mins,
                     type.interval_bits, count.last_update_min,
                     test_key3, count.value);

    // CLOSE 
    fprintf (stderr, "CLOSING db..." );
    result = freq_db_close( db );
    if (result != FREQ_DB_SUCCESS) {
      fprintf(stderr,"ERROR: did not properly close  %s.  Code: %d\n",
                     fname,result);
      exit(1);
    } else {
      fprintf (stderr, "CLOSE done %d\n", result);
    }

    //  OPEN 
    fprintf (stderr, "\n\n\nopening db...\n");
    result = freq_db_open( &db, fname, 1024 * 1024 );
    if (result != FREQ_DB_SUCCESS) {
      fprintf(stderr,"ERROR: could not open %s.  Code: %d\n",fname,result);
      exit(1);
    } else {
      fprintf (stderr, "done %d\n", result);
    }

    // INCREMENT key 3
    for ( i = 0; i < nIncrements; i++ ) {
      result = freq_db_increment( db, &type, test_key3, key_sz3, 0 );
      fprintf (stderr, "INCREMENT {%d %d %d}:%s : %d\n",
               type.interval_cnt, type.interval_mins,
               type.interval_bits, test_key3, result );
      sleep (0.1);
    }

    result = freq_db_count( db, &type, test_key1, key_sz1, 2, 0, &count );
    fprintf (stderr, "COUNT: {%d %d %d} last_update_min: %"PRIu64" %s value: " 
                     "%"PRIu64"\n", type.interval_cnt, type.interval_mins,
                     type.interval_bits, count.last_update_min,
                     test_key1, count.value);

    result = freq_db_count( db, &type, test_key3, key_sz3, 129600, 0, &count );
    fprintf (stderr, "COUNT: {%d %d %d} last_update_min: %"PRIu64" %s value: " 
                     "%"PRIu64"\n", type.interval_cnt, type.interval_mins,
                     type.interval_bits, count.last_update_min,
                     test_key3, count.value);

    // CLOSE 
    fprintf (stderr, "CLOSING db..." );
    result = freq_db_close( db );
    if (result != FREQ_DB_SUCCESS) {
      fprintf(stderr,"ERROR: did not properly close  %s.  Code: %d\n",
                     fname,result);
      exit(1);
    } else {
      fprintf (stderr, "CLOSE done %d\n", result);
    }

    return 0;
  }

