#include <assert.h>
#include <string.h>
#include <time.h>

#define NODEBUG

static time_t put_time = 0;

static time_t my_time( time_t *t )
  {
    if ( t != NULL ) *t = put_time;
    return put_time;
  }
#define time my_time

#include "../src/freq.c"

#undef time

/**********************************************************
* Test static methods
**********************************************************/
static void test_interval_get_max(void)
  {
    fprintf( stderr, "test_interval_get_max\n" );

    freq_header_t hdr;

    uint32_t w;
    for ( w = 1; w < 32; w++ )
      {
        hdr.type.interval_bits = w;
        uint32_t max = ( 1 << w ) - 1;
        assert( max == interval_get_max( &hdr ) );
      }
  }


static void test_interval_get_value(void)
  {
    fprintf( stderr, "test_interval_get_value\n" );

    size_t hdr_sz = sizeof( freq_header_t );

    // data size = 25920 buckets * 3 bits / 8 bits = 9720 bytes
    char buff[ hdr_sz + 9720 ];
    freq_header_t *hdr = (freq_header_t*)buff;
    uint8_t *data = (uint8_t*)( buff + hdr_sz );

    hdr->type.interval_bits = 3;
    hdr->type.interval_cnt = 25920;
    hdr->data_sz = 9720;

    // Initialize data array with a binary pattern that repeats
    memset( data, 85, hdr->data_sz );

    // Test that each bucket has the expected value
    uint32_t i;
    for ( i = 0; i < hdr->type.interval_cnt; i++ )
      {
        uint32_t val = interval_get_value( hdr, data, i );
        uint32_t ref = ( i % 2 ) ? 2 : 5;
        assert( ref == val );
      }
  }


static void test_interval_set_value(void)
  {
    fprintf( stderr, "test_interval_set_value\n" );

    size_t hdr_sz = sizeof( freq_header_t );

    char buff[ hdr_sz + 9720 ];
    freq_header_t *hdr = (freq_header_t*)buff;
    uint8_t *data = (uint8_t*)( buff + hdr_sz );

    hdr->type.interval_bits = 3;
    hdr->type.interval_cnt = 25920;
    hdr->data_sz = 9720;

    // Initialize data array with a binary pattern that repeats
    memset( data, 85, hdr->data_sz );

    uint32_t i;
    uint64_t rnd_bckt;
    for ( i = 0; i < 1000; i++ )
      {
        rnd_bckt = random() % hdr->type.interval_cnt;
        uint32_t val = interval_get_value( hdr, data, rnd_bckt );
        if ( val < 7 ) interval_set_value( hdr, data, rnd_bckt, val + 1 );
        uint32_t new_val = interval_get_value( hdr, data, rnd_bckt );
        assert( val + 1 == new_val );
      }
  }


static void test_interval_clear_all_in_range(void)
  {
    fprintf( stderr, "test_interval_clear_all_in_range\n" );

    size_t hdr_sz = sizeof( freq_header_t );

    char buff[ hdr_sz + 9720 ];
    freq_header_t *hdr = (freq_header_t*)buff;
    uint8_t *data = (uint8_t*)( buff + hdr_sz );

    hdr->type.interval_bits = 3;
    hdr->type.interval_cnt = 25920;
    hdr->type.interval_mins = 5;
    hdr->data_sz = 9720;

    // Initialize data array with a binary pattern that repeats
    memset( data, 85, hdr->data_sz );

    uint32_t start_min = 21384000;
    uint32_t end_min = 21384010;

    // This should clear buckets 1 and 2 and leave 0 untouched
    assert( 2 == interval_clear_all_in_range( hdr, data, start_min, end_min ) );
    assert( 5 == interval_get_value( hdr, data, 0 ) );
    assert( 0 == interval_get_value( hdr, data, 1 ) );
    assert( 0 == interval_get_value( hdr, data, 2 ) );

    // This sould clear bucket 0
    assert( 1 == interval_clear_all_in_range( hdr, data, start_min - 5, start_min ) );
    assert( 0 == interval_get_value( hdr, data, 0) );
 
    // Reset first two bytes, which covers first 5 buckets
    memset( data, 85, 2 );

    assert( 5 == interval_get_value( hdr, data, 0 ) );
    assert( 2 == interval_get_value( hdr, data, 1 ) );
    assert( 5 == interval_get_value( hdr, data, 2 ) );
    assert( 2 == interval_get_value( hdr, data, 25919 ) );

    // Now test clearing a range that wraps the array
    assert( 4 == interval_clear_all_in_range( hdr, data, start_min - 10, end_min ) );
    assert( 0 == interval_get_value( hdr, data, 25919 ) );
    assert( 0 == interval_get_value( hdr, data, 0 ) );
    assert( 0 == interval_get_value( hdr, data, 1 ) );
    assert( 0 == interval_get_value( hdr, data, 2 ) );
  }


static void test_freq_increment(void)
  {
    fprintf( stderr, "test_freq_increment\n" );

    char buff[ 20480 ];
    memset( buff, 0, sizeof( buff ) );
    freq_header_t *hdr = (freq_header_t*)buff;
    uint8_t *data = freq_get_data( hdr );

    hdr->type.interval_bits = 3;
    hdr->type.interval_cnt = 25920;
    hdr->type.interval_mins = 5;
    hdr->key_sz = 0;
    hdr->data_sz = 9720;

    memset( data, 0, hdr->data_sz );

    uint32_t put_min, bckt_idx;

    put_min = 21347610;
    put_time = put_min * 60;
    bckt_idx = 18642;  // 21347610 / 5 % 25920 == bckt % hdr->type.interval_cnt

    hdr->last_update_min = put_min;  // Mark as recently updated so no cleraing happens

    // Test that increments happen properly
    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 0 ) );
    assert( 1 == interval_get_value( hdr, data, bckt_idx ) );
    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 0 ) );
    assert( 2 == interval_get_value( hdr, data, bckt_idx ) );
    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 0 ) );
    assert( 3 == interval_get_value( hdr, data, bckt_idx ) );
    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 0 ) );
    assert( 4 == interval_get_value( hdr, data, bckt_idx ) );
    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 0 ) );
    assert( 5 == interval_get_value( hdr, data, bckt_idx ) );
    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 0 ) );
    assert( 6 == interval_get_value( hdr, data, bckt_idx ) );
    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 0 ) );
    assert( 7 == interval_get_value( hdr, data, bckt_idx ) );

    // Test that overflow is reported when a bucket is full
    assert( FREQ_DB_OVERFLOW == freq_increment( hdr, 0 ) );
    assert( 7 == interval_get_value( hdr, data, bckt_idx ) );

    // Test that last_update_min is set properly
    assert( hdr->last_update_min == 21347610 );

    // Test increments, only partially filling a bucket
    put_min = 21347615;
    put_time = put_min * 60;
    bckt_idx = 18643;

    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 0 ) );
    assert( 1 == interval_get_value( hdr, data, bckt_idx ) );
    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 0 ) );
    assert( 2 == interval_get_value( hdr, data, bckt_idx ) );

    // Now test incrementing with an offset
    put_min = 21347620;
    put_time = put_min * 60;

    assert( FREQ_DB_SUCCESS == freq_increment( hdr, 5 ) );
    assert( 3 == interval_get_value( hdr, data, bckt_idx ) );
  }


static void test_freq_count(void)
  {
    fprintf( stderr, "test_freq_count\n" );

    char buff[ 20480 ];
    freq_header_t *hdr = (freq_header_t*)buff;

    hdr->type.interval_bits = 3;
    hdr->type.interval_cnt = 25920;
    hdr->type.interval_mins = 5;
    hdr->key_sz = 0;
    hdr->data_sz = 9720;

    uint8_t *data = freq_get_data( hdr );

    memset( data, 85, hdr->data_sz );

    uint32_t put_min, bckt_idx;

    put_min = 21347610;
    put_time = put_min * 60;
    bckt_idx = 18642;  // 21347610 / 5 % 25920 == bckt % hdr->type.interval_cnt

    freq_count_t count;
    int res;

    // Put last upate just past range of frequency and make sure we get zero back
    hdr->last_update_min = put_min - hdr->type.interval_cnt * hdr->type.interval_mins - 1;
    res = freq_count( hdr, 10, 0, &count );
    assert( FREQ_DB_SUCCESS == res );
    assert( 0 == count.value );
    assert( hdr->last_update_min == count.last_update_min );

    res = freq_count( hdr, hdr->type.interval_cnt * hdr->type.interval_mins, 0, &count ); 
    assert( FREQ_DB_SUCCESS == res );
    assert( 0 == count.value );
    assert( hdr->last_update_min == count.last_update_min );

    // Put range we're interested in just past start of data and verify we get appropriate error
    res = freq_count( hdr, hdr->type.interval_cnt * hdr->type.interval_mins, 5, &count );
    assert( FREQ_DB_SUCCESS == res ); 
    assert( 0 == count.value );

    // Make two most recent buckets stale and verify we get the right count
    hdr->last_update_min = put_min - 6;
    res = freq_count( hdr, 10, 0, &count );
    assert( FREQ_DB_SUCCESS == res );
    assert( 5 == count.value || ( TLOG_DEBUG( "got %"PRIu64" instead of 5", count.value ), 0 ) );
    assert( hdr->last_update_min == count.last_update_min );

    // Make the most recent bucket stale and verify we get the right count
    hdr->last_update_min = put_min - 5;
    res = freq_count( hdr, 10, 0, &count );
    assert( FREQ_DB_SUCCESS == res );
    assert( 7 == count.value || ( TLOG_DEBUG( "got %"PRIu64" instead of 7", count.value ), 0 ) );
    assert( hdr->last_update_min == count.last_update_min );

    // No buckets stale and set position to last minute of current bucket
    // - should only count current bucket and previous bucket
    put_min = 21347609;
    put_time = put_min * 60;
    hdr->last_update_min = put_min;
    res = freq_count( hdr, 10, 0, &count );
    assert( FREQ_DB_SUCCESS == res );
    assert( 7 == count.value || ( TLOG_DEBUG( "got %"PRIu64" instead of 7", count.value ), 0 ) );
    assert( hdr->last_update_min == count.last_update_min );

    // No buckets stale and set position to first minute of current bucket
    // - should count three previous buckets
    put_min = 21347610;
    put_time = put_min * 60;
    hdr->last_update_min = put_min;
    res = freq_count( hdr, 10, 0, &count );
    assert( FREQ_DB_SUCCESS == res );
    assert( 12 == count.value || ( TLOG_DEBUG( "got %"PRIu64" instead of 12", count.value ), 0 ) );
    assert( hdr->last_update_min == count.last_update_min );

    // No buckets stale and set position to middle minute of a bucket at end of bucket array
    // - should return right result and do appropriate array index wrapping
    put_min = 21384000;
    put_time = put_min * 60;
    hdr->last_update_min = put_min;
    res = freq_count( hdr, 10, 0, &count );
    assert( FREQ_DB_SUCCESS == res );
    assert( 12 == count.value || ( TLOG_DEBUG( "got %"PRIu64" instead of 12", count.value ), 0 ) );
    assert( hdr->last_update_min == count.last_update_min );
  }


static void test_freq_merge(void)
  {
    fprintf( stderr, "test_freq_merge\n" );

    char buff1[1024];
    memset( buff1, 0, sizeof( buff1 ) );
    freq_header_t *hdr1 = (freq_header_t*)buff1;

    time_t now = time( NULL );
    time( &now );
    put_time = now;

    uint64_t now_min = MINUTES( now );

    hdr1->type.interval_bits = 4;
    hdr1->type.interval_cnt = 10;
    hdr1->type.interval_mins = 5;
    hdr1->last_update_min = now_min - 10;

    // Set key and key size
    char *key1 = (char*)freq_get_key( hdr1 );
    hdr1->key_sz = snprintf( key1, 64, "merge_test" );

    // Init data size
    hdr1->data_sz = freq_get_data_sz( hdr1 );

    // Init data
    uint8_t *data1 = freq_get_data( hdr1 );
    memset( data1, 0x44, hdr1->data_sz );

    freq_count_t count;
    int res = freq_count( hdr1, 1, 10, &count );
    assert( res == FREQ_DB_SUCCESS );
    assert( count.value == 4 );

    res = freq_count( hdr1, 1, 0, &count );
    assert( res == FREQ_DB_SUCCESS );
    assert( count.value == 0 );

    char buff2[1024];
    memcpy( buff2, buff1, 1024 );

    freq_header_t *hdr2 = (freq_header_t*)buff2;
    hdr2->last_update_min = now_min - 5;

    res = freq_merge( hdr2, hdr1 );
    assert( res == FREQ_DB_SUCCESS );

    res = freq_count( hdr2, 1, 21, &count );
    fprintf( stderr, "count.value = %"PRIu64"\n", count.value );
    assert( res == FREQ_DB_SUCCESS );
    assert( count.value == 8 );

    res = freq_count( hdr2, 1, 6, &count );
    fprintf( stderr, "count.value = %"PRIu64"\n", count.value );
    assert( res == FREQ_DB_SUCCESS );
    assert( count.value == 4 );

    res = freq_count( hdr2, 1, 0, &count );
    fprintf( stderr, "count.value = %"PRIu64"\n", count.value );
    assert( res == FREQ_DB_SUCCESS );
    assert( count.value == 0 );
  }


int main(void)
  {
    test_interval_get_max();
    test_interval_get_value();
    test_interval_set_value();
    test_interval_clear_all_in_range();
    test_freq_increment();
    test_freq_count();
    test_freq_merge();
    return 0;
  }
