#include <assert.h>
#include <inttypes.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>

#include "freq_db.h"
#include "freq_type.h"
#include "freq_count.h"
#include "freq.h"
#include "tlog.h"

#define NFREQS 50000000
#define MAX 32                    // max string length
#define MIN 20			  // min string length
#define NKEYS  100                // num keys to increment 

// This single threaded test will create NFREQ random keys and insert them.
// It will randomly choose NKEYS for count checking and NKEYS for deletion.
// It will go find all NKEYS, then delete the NKEYS pegged for deletion.
// Then, it'll run GC, then go increment and count test the NKEYS to make 
// sure it can still find them and their value is correct
//
// You can use this test to run the system to memory failure.  Just set 
// NFREQS really large and NKEYS small (like 1);
// 
void gen_random(char *s, const int len);

int main (void)
{
  const char *fname = "./freqserver.fdb";
  
  int retCode;
  uint64_t i;
  uint64_t nErrors = 0;
  uint8_t len; 
  float fractionToKeep = (float)NKEYS/NFREQS;	// percent of keys to keep
  uint8_t flag = 0;
  freq_db_gc_stats_t gcStats;

  char currentKey[MAX+1];         // storage for rand key generator
  char *keys[NKEYS];              // array of pointers to keys
  char *deleteKey[NKEYS];         // array ptrs of keys to delete

  uint64_t num_stored_keys = 0;	  // num we've stored off
  uint64_t num_delete_keys = 0;   // num keys we've marked for delete
  uint64_t stored_key_cnt[NKEYS]; // true counts for each stored key
 
  freq_count_t count;
  freq_db_t *db = NULL;
  freq_type_t type;

  srand(time(NULL));

  fprintf (stderr, "STATUS: opening db...");
  retCode = freq_db_open( &db, fname, 1024 * 1024 * 1024 );
  fprintf (stderr, "STATUS: done %d\n", retCode);

  type.interval_cnt = 1;
  type.interval_mins = 129600;
  type.interval_bits = 16;

  for ( i = 0; i < NFREQS; i++ ) {
    // generate a random key length
    // then generate a random key
    len = (uint8_t)((float)rand()*(MAX-MIN)/(float)RAND_MAX  + MIN);
    gen_random(currentKey, len);
    //fprintf(stderr,"making %u length key %s\n",len,currentKey);
    retCode = freq_db_increment( db, &type, currentKey, len, 0);
    if ( retCode != FREQ_DB_CREATED ) {
      nErrors++;
      fprintf(stderr,"ERROR: increment failed\n");
    }
    
    // if we have room for more stored keys
    if (num_stored_keys < NKEYS) {
      // gen random number to see if we keep this one
      flag = ((float)rand()/RAND_MAX < fractionToKeep);
      // if it falls in interval 0-fractionToKeep, we'll keep it.
      if (flag) {
        // go get mem to store it
        //fprintf(stderr,"Storing key %lu: %s\n", num_stored_keys+1,currentKey);
        keys[num_stored_keys] = (char*)malloc(strlen(currentKey)+1);
        if (keys[num_stored_keys] == NULL) {
          fprintf(stderr,"ERROR: TEST malloc failed\n");
        } else {
          strcpy(keys[num_stored_keys], currentKey);
          //fprintf(stderr,"  stored: %s\n",keys[num_stored_keys]);
          stored_key_cnt[num_stored_keys] = 1;
          num_stored_keys++;
        }
      }
    }
     

    // if we have room to store more delete keys
    if (!flag && num_delete_keys < NKEYS) {
      // gen random number to see if we keep this one
      flag = ((float)rand()/RAND_MAX < fractionToKeep);
      // if it falls in interval 0-fractionToKeep, we'll keep it.
      if (flag) {
        // go get mem to store it
        //fprintf(stderr,"Storing key %lu: %s\n", num_stored_keys+1,currentKey);
        deleteKey[num_delete_keys] = (char*)malloc(strlen(currentKey)+1);
        if (deleteKey[num_delete_keys] == NULL) {
          fprintf(stderr,"ERROR: TEST malloc failed\n");
        } else {
          strcpy(deleteKey[num_delete_keys], currentKey);
          num_delete_keys++;
        }
      }
    }
  }

  if (nErrors == 0) {
    fprintf(stderr,"SUCCESS!! incremented all keys. \n");
  } else {
    fprintf(stderr,"%"PRIu64" ERRORS found.",nErrors);
  }
 
  nErrors = 0;
 
  // now go find all stored keys
  fprintf(stderr,"\nSTATUS: Going to look for %"PRIu64" keys\n",num_stored_keys);
  for ( i = 0; i < num_stored_keys; i++ ) {
    count.value = 0;         // reset value
    retCode = freq_db_increment( db, &type, keys[i], strlen(keys[i]),0);
    if (retCode != FREQ_DB_SUCCESS) {
      fprintf(stderr,"ERROR:  could not find key %s\n",keys[i]);
      nErrors++;
    } else {
      stored_key_cnt[i]++;
      retCode = freq_db_count( db, &type, keys[i], strlen(keys[i]) ,2, 0, &count );
      if ( count.value != stored_key_cnt[i] ) {
        fprintf(stderr,"ERROR: count mismatch\n");
        fprintf(stderr,"Key %"PRIu64": %32s - true count: %"PRIu64"  DB count %"PRIu64"\n",
              i,keys[i],stored_key_cnt[i],count.value);
        nErrors++;
      }
    }
  }
  if (nErrors == 0) {
    fprintf(stderr,"SUCCESS!! found all keys.  All had correct count \n");
  } else {
    fprintf(stderr,"%"PRIu64" ERRORS found.",nErrors);
  }
  nErrors = 0;
  
  // now go delete all delete keys
  fprintf(stderr,"\nGoing to delete %"PRIu64" keys\n",num_delete_keys);
  for ( i = 0; i < num_delete_keys; i++ ) {
    retCode = freq_db_delete( db, &type, deleteKey[i], strlen(deleteKey[i]));
    if (retCode != FREQ_DB_SUCCESS) {
      fprintf(stderr,"ERROR:  could not delete key %s\n", deleteKey[i]);
      nErrors++;
    } 
  }
  if (nErrors == 0) {
    fprintf(stderr,"SUCCESS!! deleted specified keys.\n");
  } else {
    fprintf(stderr,"%"PRIu64" ERRORS found.",nErrors);
  }
  nErrors = 0;

  fprintf (stderr, "STATUS: closing db..." );
  retCode = freq_db_close( db );
  fprintf (stderr, "STATUS: done %d\n", retCode );

  fprintf (stderr, "STATUS: opening db...");
  retCode = freq_db_open( &db, fname, 1024 * 1024 );
  fprintf (stderr, "STATUS: done %d\n", retCode);
   
  fprintf (stderr, "STATUS: Garbage Collection\n");
  freq_db_gc( db, &gcStats );

  // now go find all stored keys
  nErrors = 0;
  fprintf(stderr,"\nSTATUS: Going to look for %"PRIu64" keys\n",num_stored_keys);
  for ( i = 0; i < num_stored_keys; i++ ) {
    count.value = 0;         // reset value
    retCode = freq_db_increment( db, &type, keys[i], strlen(keys[i]),0);
    if (retCode != FREQ_DB_SUCCESS) {
      fprintf(stderr,"ERROR:  could not find key %s\n",keys[i]);
      nErrors++;
    } else {
      stored_key_cnt[i]++;
      retCode = freq_db_count( db, &type, keys[i], strlen(keys[i]) ,2, 0, &count );
      if ( count.value != stored_key_cnt[i] ) {
        fprintf(stderr,"ERROR: count mismatch\n");
        fprintf(stderr,"Key %"PRIu64": %32s - true count: %"PRIu64"  DB count %"PRIu64"\n",
              i,keys[i],stored_key_cnt[i],count.value);
        nErrors++;
      }
    }
  }
  if (nErrors == 0) {
    fprintf(stderr,"SUCCESS!! found all keys.  All had correct count \n");
  } else {
    fprintf(stderr,"%"PRIu64" ERRORS found.",nErrors);
  }

  fprintf (stderr, "STATUS: closing db..." );
  retCode = freq_db_close( db );
  fprintf (stderr, "STATUS: done %d\n", retCode );

  return 0;
}


void gen_random(char *s, const int len) {
  static const char alphanum[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
  int i;
  int N = sizeof(alphanum) - 1;

  for (i = 0; i < len; ++i) {
    s[i] = alphanum[(int)((double)rand()/((double)RAND_MAX + 1) * N)];
  }

  s[len] = '\0';
}


